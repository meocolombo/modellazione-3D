from __future__ import annotations

import csv
import json
import math
from pathlib import Path

from archicad import ACConnection


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
PIPELINE = ROOT / "output_berra_v17_ufficiale_pipeline"
INPUT_CSV = PIPELINE / "berra_v18_assi_capriate_primari_da_verificare.csv"

LAYER_NAME = "BERRA_V19_RIF_ASSI_CAPRIATE_DA_VERIFICARE"
STANDBY_LAYER = "BERRA_STANDBY_V19_RIF_ASSI_CAPRIATE_PRECEDENTI"

OUT_CSV = PIPELINE / "berra_v19_assi_capriate_importati.csv"
OUT_JSON = PIPELINE / "berra_v19_assi_capriate_importati_result.json"
OUT_REPORT = PIPELINE / "berra_v19_assi_capriate_importati_report.md"

REFERENCE_Z = 13.15
BEAM_WIDTH = 0.08
BEAM_HEIGHT = 0.08


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def normalize_elements(elements):
    normalized = []
    for element in elements or []:
        if "elementId" in element:
            normalized.append(element)
        elif "guid" in element:
            normalized.append({"elementId": {"guid": element["guid"]}})
    return normalized


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group, hidden=False):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def move_existing_reference_to_standby(commands, types, reference_layer_index, standby_layer_index):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    to_move = []
    for element, detail in zip(elements, details):
        try:
            if int(detail.get("layerIndex", -1)) == int(reference_layer_index):
                to_move.append(element)
        except Exception:
            continue
    if not to_move:
        return {"moved": 0}
    result = tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": int(standby_layer_index)}}
                for element in normalize_elements(to_move)
            ]
        },
    )
    return {"moved": len(to_move), "result": result}


def set_layer(commands, types, elements, target_layer_index):
    elements = normalize_elements(elements)
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": int(target_layer_index)}}
                for element in elements
            ]
        },
    )


def try_set_ids(commands, types, elements, codes):
    updated = 0
    failed = 0
    for element, code in zip(normalize_elements(elements), codes):
        try:
            tapir(
                commands,
                types,
                "SetDetailsOfElements",
                {"elementsWithDetails": [{"elementId": element["elementId"], "details": {"id": code}}]},
            )
            updated += 1
        except Exception:
            failed += 1
    return {"updated": updated, "failed": failed}


def read_axes():
    rows = []
    with INPUT_CSV.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        for row in reader:
            rows.append(
                {
                    "source_id": row["id"],
                    "classe": row.get("classe", "primario"),
                    "orientation": row["orientation"],
                    "length_px": float(row["length_px"]),
                    "x0": float(row["model_x0"]),
                    "y0": float(row["model_y0"]),
                    "x1": float(row["model_x1"]),
                    "y1": float(row["model_y1"]),
                }
            )
    rows.sort(key=lambda item: (-item["length_px"], item["source_id"]))
    return rows


def beam_data(row):
    return {
        "begCoordinate": coord(row["x0"], row["y0"]),
        "endCoordinate": coord(row["x1"], row["y1"]),
        "zCoordinate": float(REFERENCE_Z),
        "width": float(BEAM_WIDTH),
        "height": float(BEAM_HEIGHT),
    }


def length(row):
    return math.hypot(row["x1"] - row["x0"], row["y1"] - row["y0"])


def main():
    conn = ACConnection.connect()
    assert conn
    commands = conn.commands
    types = conn.types

    layer_idx = create_or_get_layer(commands, types, LAYER_NAME, 219, hidden=False)
    standby_idx = create_or_get_layer(commands, types, STANDBY_LAYER, 220, hidden=True)
    standby_result = move_existing_reference_to_standby(commands, types, layer_idx, standby_idx)

    axes = read_axes()
    payload = [beam_data(row) for row in axes]
    codes = [f"BERRA-V19-RIF-CAP-{idx:03d}" for idx, _ in enumerate(axes, start=1)]

    result = tapir(commands, types, "CreateBeams", {"beamsData": payload})
    elements = normalize_elements(result.get("elements", []))
    layer_result = set_layer(commands, types, elements, layer_idx)
    id_result = try_set_ids(commands, types, elements, codes)

    out_rows = []
    for row, code, element in zip(axes, codes, elements):
        out_rows.append(
            {
                "codice_id": code,
                "guid": element["elementId"].get("guid", ""),
                "layer": LAYER_NAME,
                "source_id": row["source_id"],
                "classe": row["classe"],
                "orientation": row["orientation"],
                "x0": round(row["x0"], 4),
                "y0": round(row["y0"], 4),
                "x1": round(row["x1"], 4),
                "y1": round(row["y1"], 4),
                "z": REFERENCE_Z,
                "length_m": round(length(row), 4),
                "width": BEAM_WIDTH,
                "height": BEAM_HEIGHT,
                "status": "riferimento_da_verificare",
            }
        )

    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fieldnames = list(out_rows[0].keys()) if out_rows else ["codice_id"]
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(out_rows)

    result_doc = {
        "layer": LAYER_NAME,
        "standbyLayer": STANDBY_LAYER,
        "referenceZ": REFERENCE_Z,
        "requested": len(payload),
        "created": len(elements),
        "standby": standby_result,
        "layerResult": layer_result,
        "idResult": id_result,
        "outputs": {
            "csv": str(OUT_CSV),
            "report": str(OUT_REPORT),
        },
    }
    OUT_JSON.write_text(json.dumps(result_doc, ensure_ascii=False, indent=2), encoding="utf-8")

    total_length = sum(row["length_m"] for row in out_rows)
    lines = [
        "# Berra V19 - assi capriate di riferimento importati",
        "",
        "Questa passata crea elementi di riferimento, non travi/capriate definitive.",
        "",
        "## Layer",
        "",
        f"- Attivo: `{LAYER_NAME}`",
        f"- Standby precedenti: `{STANDBY_LAYER}`",
        "",
        "## Risultato",
        "",
        f"- Assi richiesti: {len(payload)}",
        f"- Assi creati: {len(elements)}",
        f"- Versioni precedenti spostate in standby: {standby_result.get('moved', 0)}",
        f"- Quota di riferimento: {REFERENCE_Z:.2f} m",
        f"- Lunghezza totale riferimento: {total_length:.2f} m",
        "",
        "## Output",
        "",
        f"- `{OUT_CSV.name}`",
        f"- `{OUT_JSON.name}`",
        "",
        "## Uso",
        "",
        "Apri/mostra il layer V19 in Archicad e verifica quali assi coincidono con le capriate reali.",
        "Gli elementi sono volutamente sottili e su layer dedicato: possono essere nascosti o spostati in standby.",
    ]
    OUT_REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Creati elementi riferimento: {len(elements)} / {len(payload)}")
    print(f"Layer: {LAYER_NAME}")
    print(f"Standby precedenti: {standby_result.get('moved', 0)}")
    print(f"Report: {OUT_REPORT}")


if __name__ == "__main__":
    main()

