from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_V07_STRUTTURA_COPERTURE"
OUT_JSON = Path("berra_v07_struttura_coperture_result.json")
OUT_CSV = Path("berra_v07_struttura_coperture_elementi.csv")
OUT_TXT = Path("berra_v07_struttura_coperture_report.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 170,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_all_with_details_boxes(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    return elements, details, boxes


def count_elements_on_layer(commands, types, layer_index):
    _elements, details, _boxes = get_all_with_details_boxes(commands, types)
    total = 0
    for detail in details:
        try:
            total += int(detail.get("layerIndex", -1)) == int(layer_index)
        except Exception:
            pass
    return total


def get_roof_rows(commands, types):
    layer_names = layers_map(commands, types)
    elements, details, boxes = get_all_with_details_boxes(commands, types)
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Roof":
            continue
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        if layer.startswith("BERRA_V07_") or layer.startswith("BERRA_STANDBY_"):
            continue
        box = box_item.get("boundingBox3D", {})
        x1 = float(box.get("xMin", 0.0))
        x2 = float(box.get("xMax", 0.0))
        y1 = float(box.get("yMin", 0.0))
        y2 = float(box.get("yMax", 0.0))
        z1 = float(box.get("zMin", 0.0))
        z2 = float(box.get("zMax", 0.0))
        area = max(0.0, x2 - x1) * max(0.0, y2 - y1)
        if area < 6.0:
            continue
        rows.append(
            {
                "guid": element.get("elementId", {}).get("guid", ""),
                "type": detail.get("type", ""),
                "layer": layer,
                "old_id": detail.get("id", ""),
                "x1": x1,
                "x2": x2,
                "y1": y1,
                "y2": y2,
                "z1": z1,
                "z2": z2,
                "area": area,
            }
        )
    rows.sort(key=lambda item: (item["y1"], item["x1"], item["guid"]))
    return rows


def beam_data(x1, y1, x2, y2, z, width, height):
    return {
        "begCoordinate": coord(x1, y1),
        "endCoordinate": coord(x2, y2),
        "zCoordinate": float(z),
        "width": float(width),
        "height": float(height),
    }


def add_beam(rows, code, classe, roof, x1, y1, x2, y2, z, width, height, note):
    if math.hypot(x2 - x1, y2 - y1) < 0.75:
        return
    rows.append(
        {
            "code": code,
            "classe": classe,
            "roofGuid": roof["guid"],
            "roofLayer": roof["layer"],
            "roofOldId": roof["old_id"],
            "x1": round(float(x1), 4),
            "y1": round(float(y1), 4),
            "x2": round(float(x2), 4),
            "y2": round(float(y2), 4),
            "z": round(float(z), 4),
            "width": round(float(width), 4),
            "height": round(float(height), 4),
            "note": note,
            "data": beam_data(x1, y1, x2, y2, z, width, height),
        }
    )


def positions_between(start, end, count):
    if count <= 1:
        return [(start + end) / 2.0]
    return [start + (end - start) * (i + 1) / (count + 1) for i in range(count)]


def build_structural_beams(roof_rows):
    rows = []
    counters = Counter()
    for roof_no, roof in enumerate(roof_rows, start=1):
        x1, x2 = roof["x1"], roof["x2"]
        y1, y2 = roof["y1"], roof["y2"]
        z1, z2 = roof["z1"], roof["z2"]
        span_x = max(0.0, x2 - x1)
        span_y = max(0.0, y2 - y1)
        if span_x < 1.2 or span_y < 1.2:
            continue

        margin_x = min(0.45, span_x * 0.12)
        margin_y = min(0.45, span_y * 0.12)
        center_x = (x1 + x2) / 2.0
        center_y = (y1 + y2) / 2.0
        long_is_y = span_y >= span_x
        ridge_z = z2 - 0.12
        purlin_z = z1 + max(0.22, min(0.55, (z2 - z1) * 0.45))
        tie_z = z1 + 0.18
        board_z = z1 + 0.08

        def next_code(prefix):
            counters[prefix] += 1
            return f"BER-V07-{prefix}-{counters[prefix]:03d}"

        if long_is_y:
            # Colmo/terzera principale lungo l'asse maggiore della falda.
            add_beam(
                rows,
                next_code("COL"),
                "colmo-terzera-principale",
                roof,
                center_x,
                y1 + margin_y,
                center_x,
                y2 - margin_y,
                ridge_z,
                0.16,
                0.18,
                f"colmo su copertura {roof_no}",
            )
            for offset in (-span_x * 0.24, span_x * 0.24):
                if abs(offset) > 0.42:
                    add_beam(
                        rows,
                        next_code("TER"),
                        "terzera",
                        roof,
                        center_x + offset,
                        y1 + margin_y,
                        center_x + offset,
                        y2 - margin_y,
                        purlin_z,
                        0.11,
                        0.13,
                        f"terzera laterale su copertura {roof_no}",
                    )
            count = 1 if span_y < 9 else 2 if span_y < 18 else 3
            for y in positions_between(y1 + margin_y, y2 - margin_y, count):
                add_beam(
                    rows,
                    next_code("CAT"),
                    "catena-capriata",
                    roof,
                    x1 + margin_x,
                    y,
                    x2 - margin_x,
                    y,
                    tie_z,
                    0.15,
                    0.16,
                    f"catena di capriata su copertura {roof_no}",
                )
            if span_y >= 10 and span_x >= 3.0:
                for offset in (-span_x * 0.34, span_x * 0.34):
                    add_beam(
                        rows,
                        next_code("ASS"),
                        "assito-indicativo",
                        roof,
                        center_x + offset,
                        y1 + margin_y,
                        center_x + offset,
                        y2 - margin_y,
                        board_z,
                        0.045,
                        0.055,
                        f"linea assito/orditura minuta su copertura {roof_no}",
                    )
        else:
            add_beam(
                rows,
                next_code("COL"),
                "colmo-terzera-principale",
                roof,
                x1 + margin_x,
                center_y,
                x2 - margin_x,
                center_y,
                ridge_z,
                0.16,
                0.18,
                f"colmo su copertura {roof_no}",
            )
            for offset in (-span_y * 0.24, span_y * 0.24):
                if abs(offset) > 0.42:
                    add_beam(
                        rows,
                        next_code("TER"),
                        "terzera",
                        roof,
                        x1 + margin_x,
                        center_y + offset,
                        x2 - margin_x,
                        center_y + offset,
                        purlin_z,
                        0.11,
                        0.13,
                        f"terzera laterale su copertura {roof_no}",
                    )
            count = 1 if span_x < 9 else 2 if span_x < 18 else 3
            for x in positions_between(x1 + margin_x, x2 - margin_x, count):
                add_beam(
                    rows,
                    next_code("CAT"),
                    "catena-capriata",
                    roof,
                    x,
                    y1 + margin_y,
                    x,
                    y2 - margin_y,
                    tie_z,
                    0.15,
                    0.16,
                    f"catena di capriata su copertura {roof_no}",
                )
            if span_x >= 10 and span_y >= 3.0:
                for offset in (-span_y * 0.34, span_y * 0.34):
                    add_beam(
                        rows,
                        next_code("ASS"),
                        "assito-indicativo",
                        roof,
                        x1 + margin_x,
                        center_y + offset,
                        x2 - margin_x,
                        center_y + offset,
                        board_z,
                        0.045,
                        0.055,
                        f"linea assito/orditura minuta su copertura {roof_no}",
                    )
    return rows


def set_elements_layer(commands, types, created_rows, layer_index):
    if not created_rows:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": int(layer_index)}}
                for row in created_rows
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def write_general_ids(commands, types, created_rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created_rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created_rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created_rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def write_outputs(layer_index, roof_rows, created_rows, failures, layer_result, id_result):
    csv_rows = []
    for row in created_rows:
        length = math.hypot(row["x2"] - row["x1"], row["y2"] - row["y1"])
        csv_rows.append(
            {
                "codice_id": row["code"],
                "guid": row["element"]["elementId"]["guid"],
                "layer": LAYER_NAME,
                "classe": row["classe"],
                "roof_guid": row["roofGuid"],
                "roof_layer": row["roofLayer"],
                "x1": row["x1"],
                "y1": row["y1"],
                "x2": row["x2"],
                "y2": row["y2"],
                "z": row["z"],
                "larghezza": row["width"],
                "altezza": row["height"],
                "lunghezza_m": round(length, 4),
                "volume_m3": round(length * row["width"] * row["height"], 4),
                "note": row["note"],
            }
        )

    fields = [
        "codice_id",
        "guid",
        "layer",
        "classe",
        "roof_guid",
        "roof_layer",
        "x1",
        "y1",
        "x2",
        "y2",
        "z",
        "larghezza",
        "altezza",
        "lunghezza_m",
        "volume_m3",
        "note",
    ]
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(csv_rows)

    summary = Counter(row["classe"] for row in created_rows)
    payload = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "roofsRead": len(roof_rows),
        "requested": len(created_rows) + len(failures),
        "created": len(created_rows),
        "failures": failures,
        "summaryByClass": dict(summary),
        "setLayerResult": layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V07 - STRUTTURA COPERTURE",
                "=" * 40,
                f"Layer: {LAYER_NAME} index {layer_index}",
                f"Falde lette: {len(roof_rows)}",
                f"Elementi creati: {len(created_rows)}",
                "Classi:",
                *[f"- {name}: {count}" for name, count in sorted(summary.items())],
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea una prima passata controllata di struttura coperture su layer dedicato.")
        print("Uso: py 62_tapir_v07_struttura_coperture_berra.py APPLICA")
        print("Per rilanciare su layer gia popolato: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)
    existing = count_elements_on_layer(commands, types, layer_index)
    if existing and not force:
        print(f"Layer {LAYER_NAME} gia popolato con {existing} elementi. Nessuna modifica.")
        print("Usa FORZA solo dopo verifica visiva.")
        return

    roof_rows = get_roof_rows(commands, types)
    beam_rows = build_structural_beams(roof_rows)
    if not beam_rows:
        raise SystemExit("Nessuna falda utile trovata per generare la struttura.")

    try:
        tapir(commands, types, "ApplyFavoritesToElementDefaults", {"favorites": ["Trave generica"]})
    except Exception:
        pass

    created_rows = []
    failures = []
    for row in beam_rows:
        try:
            result = tapir(commands, types, "CreateBeams", {"beamsData": [row["data"]]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": row["code"], "error": "nessun elemento restituito", "result": result})
                continue
            new_row = dict(row)
            new_row["element"] = elements[0]
            created_rows.append(new_row)
        except Exception as exc:
            failures.append({"code": row["code"], "error": str(exc)})

    layer_result = set_elements_layer(commands, types, created_rows, layer_index)
    id_result = write_general_ids(commands, types, created_rows)
    write_outputs(layer_index, roof_rows, created_rows, failures, layer_result, id_result)

    print("BERRA V07 struttura coperture applicata.")
    print(f"Falde lette: {len(roof_rows)}")
    print(f"Travi/orditure create: {len(created_rows)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
