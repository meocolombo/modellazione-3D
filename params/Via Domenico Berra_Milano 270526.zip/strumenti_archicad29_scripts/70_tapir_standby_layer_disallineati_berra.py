from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


STANDBY_LAYER = "BERRA_STANDBY_REVISIONE_STRUTTURE_FINITURE"
TARGET_LAYERS = {
    "BERRA_V07_STRUTTURA_COPERTURE",
    "BERRA_V08_FINESTRE_EDICOLE",
    "BERRA_V11_CAPRIATE_NATIVE",
}
SKIP_TYPES = {"BeamSegment", "ColumnSegment"}
OUT_JSON = Path("berra_standby_revisioni_strutture_finiture_result.json")
OUT_TXT = Path("berra_standby_revisioni_strutture_finiture_report.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_standby_layer(commands, types):
    existing = find_layer_index(commands, types, STANDBY_LAYER)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": STANDBY_LAYER,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 190,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, STANDBY_LAYER)
    if created is None:
        raise RuntimeError(f"Layer non creato: {STANDBY_LAYER}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for element, detail in zip(elements, details):
        rows.append(
            {
                "element": element,
                "layer": layers.get(int(detail.get("layerIndex", -999)), ""),
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
            }
        )
    return rows


def move_to_standby(commands, types, rows, standby_index):
    movable = [row for row in rows if row["type"] not in SKIP_TYPES]
    if not movable:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": standby_index}}
                for row in movable
            ]
        },
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Mette in stand-by i layer V07/V08/V11 disallineati, senza cancellarli.")
        print("Uso: py 70_tapir_standby_layer_disallineati_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby_index = create_or_get_standby_layer(commands, types)

    before = get_rows(commands, types)
    to_move = [row for row in before if row["layer"] in TARGET_LAYERS and row["type"] not in SKIP_TYPES]
    move_result = move_to_standby(commands, types, to_move, standby_index)
    after = get_rows(commands, types)

    payload = {
        "standbyLayer": {"name": STANDBY_LAYER, "index": standby_index},
        "targetLayers": sorted(TARGET_LAYERS),
        "movedRequested": len(to_move),
        "movedByLayer": dict(Counter(row["layer"] for row in to_move)),
        "movedByType": dict(Counter(row["type"] for row in to_move)),
        "remainingTargetLayers": {
            layer: sum(1 for row in after if row["layer"] == layer and row["type"] not in SKIP_TYPES)
            for layer in sorted(TARGET_LAYERS)
        },
        "standbyCountAfter": sum(1 for row in after if row["layer"] == STANDBY_LAYER and row["type"] not in SKIP_TYPES),
        "moveResult": move_result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - STAND-BY REVISIONE STRUTTURE/FINITURE",
                "=" * 52,
                f"Layer stand-by: {STANDBY_LAYER} index {standby_index}",
                f"Elementi spostati richiesti: {len(to_move)}",
                "Spostati per layer:",
                *(f"- {layer}: {count}" for layer, count in sorted(payload["movedByLayer"].items())),
                "Spostati per tipo:",
                *(f"- {typ}: {count}" for typ, count in sorted(payload["movedByType"].items())),
                "Residui sui layer bersaglio:",
                *(f"- {layer}: {count}" for layer, count in sorted(payload["remainingTargetLayers"].items())),
                f"Elementi ora in stand-by: {payload['standbyCountAfter']}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Elementi spostati in stand-by: {len(to_move)}")
    print(f"Layer stand-by: {STANDBY_LAYER} index {standby_index}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
