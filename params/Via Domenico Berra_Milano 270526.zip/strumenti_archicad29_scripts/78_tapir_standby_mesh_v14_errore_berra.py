from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


STANDBY_LAYER = "BERRA_STANDBY_REVISIONE_STRUTTURE_FINITURE"
OUT_TXT = Path(r"E:\strumenti-archicad29\berra_standby_mesh_v14_errore_report.txt")
OUT_JSON = Path(r"E:\strumenti-archicad29\berra_standby_mesh_v14_errore_result.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_standby_layer(commands, types):
    existing = find_layer_index(commands, types, STANDBY_LAYER)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": STANDBY_LAYER,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 190,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, STANDBY_LAYER)
    if created is None:
        raise RuntimeError(f"Layer non creato: {STANDBY_LAYER}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Mette in stand-by le Mesh create erroneamente dalla V14.")
        print("Uso: py 78_tapir_standby_mesh_v14_errore_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby_index = create_or_get_standby_layer(commands, types)
    layers = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    rows = []
    for element, detail in zip(elements, details):
        if detail.get("type") != "Mesh":
            continue
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        if layer == STANDBY_LAYER:
            continue
        rows.append({"element": element, "id": detail.get("id", ""), "layer": layer, "type": detail.get("type", "")})

    if rows:
        result = tapir(
            commands,
            types,
            "SetDetailsOfElements",
            {
                "elementsWithDetails": [
                    {"elementId": row["element"]["elementId"], "details": {"layerIndex": standby_index}}
                    for row in rows
                ]
            },
        )
    else:
        result = None

    payload = {
        "standbyLayer": STANDBY_LAYER,
        "standbyIndex": standby_index,
        "moved": len(rows),
        "byLayer": dict(Counter(row["layer"] for row in rows)),
        "ids": [row["id"] for row in rows],
        "result": result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - STAND-BY MESH V14 ERRATE",
                "=" * 42,
                f"Elementi Mesh spostati: {len(rows)}",
                "Per layer origine:",
                *(f"- {layer}: {count}" for layer, count in sorted(payload["byLayer"].items())),
            ]
        ),
        encoding="utf-8",
    )
    print(f"Mesh spostate in stand-by: {len(rows)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
