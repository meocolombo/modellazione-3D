from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


LAYER_STRUCTURE = "BERRA_V12_STRUTTURA_CAMPATE"
LAYER_FINISHES = "BERRA_V12_FINITURE_APERTURE_ASSIALI"
OUT_JSON = Path("berra_v12_strutture_finiture_allineate_result.json")
OUT_CSV = Path("berra_v12_strutture_finiture_allineate_elementi.csv")
OUT_TXT = Path("berra_v12_strutture_finiture_allineate_report.txt")
SKIP_TYPES = {"BeamSegment", "ColumnSegment"}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, layer_name, group_nr):
    existing = find_layer_index(commands, types, layer_name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": layer_name,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group_nr),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, layer_name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {layer_name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_all_rows(commands, types):
    layer_names = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        box = box_item.get("boundingBox3D", {})
        rows.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "type": detail.get("type", ""),
                "old_id": detail.get("id", ""),
                "layer": layer,
                "x1": float(box.get("xMin", 0.0)),
                "x2": float(box.get("xMax", 0.0)),
                "y1": float(box.get("yMin", 0.0)),
                "y2": float(box.get("yMax", 0.0)),
                "z1": float(box.get("zMin", 0.0)),
                "z2": float(box.get("zMax", 0.0)),
            }
        )
    return rows


def count_on_layer(rows, layer_name):
    return sum(1 for row in rows if row["layer"] == layer_name and row["type"] not in SKIP_TYPES)


def positions_between(start, end, count):
    if count <= 1:
        return [(start + end) / 2.0]
    return [start + (end - start) * (i + 1) / (count + 1) for i in range(count)]


def add_beam(rows, code, layer, classe, source, x1, y1, x2, y2, z, width, height, note):
    length = math.hypot(x2 - x1, y2 - y1)
    if length < 0.35:
        return
    rows.append(
        {
            "kind": "Beam",
            "code": code,
            "layer": layer,
            "classe": classe,
            "sourceGuid": source.get("guid", ""),
            "sourceType": source.get("type", ""),
            "sourceLayer": source.get("layer", ""),
            "sourceId": source.get("old_id", ""),
            "x1": round(float(x1), 4),
            "y1": round(float(y1), 4),
            "x2": round(float(x2), 4),
            "y2": round(float(y2), 4),
            "z": round(float(z), 4),
            "width": round(float(width), 4),
            "height": round(float(height), 4),
            "depth": "",
            "note": note,
            "data": {
                "begCoordinate": coord(x1, y1),
                "endCoordinate": coord(x2, y2),
                "zCoordinate": float(z),
                "width": float(width),
                "height": float(height),
            },
        }
    )


def add_column(rows, code, layer, classe, source, x, y, z, height, width, depth, note):
    if height < 0.25:
        return
    rows.append(
        {
            "kind": "Column",
            "code": code,
            "layer": layer,
            "classe": classe,
            "sourceGuid": source.get("guid", ""),
            "sourceType": source.get("type", ""),
            "sourceLayer": source.get("layer", ""),
            "sourceId": source.get("old_id", ""),
            "x1": round(float(x), 4),
            "y1": round(float(y), 4),
            "x2": round(float(x), 4),
            "y2": round(float(y), 4),
            "z": round(float(z), 4),
            "width": round(float(width), 4),
            "height": round(float(height), 4),
            "depth": round(float(depth), 4),
            "note": note,
            "data": {
                "coordinates": point3(x, y, z),
                "height": float(height),
                "width": float(width),
                "depth": float(depth),
            },
        }
    )


def build_structure(rows):
    roof_rows = [
        row for row in rows
        if row["type"] == "Roof"
        and not row["layer"].startswith("BERRA_STANDBY_")
        and max(0.0, row["x2"] - row["x1"]) * max(0.0, row["y2"] - row["y1"]) >= 6.0
    ]
    roof_rows.sort(key=lambda row: (row["y1"], row["x1"], row["guid"]))
    out = []
    counters = Counter()

    def code(prefix):
        counters[prefix] += 1
        return f"BER-V12-{prefix}-{counters[prefix]:03d}"

    for index, roof in enumerate(roof_rows, start=1):
        x1, x2, y1, y2 = roof["x1"], roof["x2"], roof["y1"], roof["y2"]
        span_x = x2 - x1
        span_y = y2 - y1
        if span_x < 1.2 or span_y < 1.2:
            continue
        mx = min(0.32, span_x * 0.10)
        my = min(0.32, span_y * 0.10)
        left, right = x1 + mx, x2 - mx
        bottom, top = y1 + my, y2 - my
        cx = (left + right) / 2.0
        cy = (bottom + top) / 2.0
        z_low = roof["z1"] + 0.10
        z_mid = roof["z1"] + max(0.24, min(0.52, (roof["z2"] - roof["z1"]) * 0.40))
        z_high = roof["z2"] - 0.12
        long_is_y = span_y >= span_x
        long_span = span_y if long_is_y else span_x
        cross_span = span_x if long_is_y else span_y
        campate = max(1, min(8, int(round(long_span / 3.8))))

        note = f"struttura allineata per campate su falda {index}"
        if long_is_y:
            add_beam(out, code("COL"), LAYER_STRUCTURE, "colmo", roof, cx, bottom, cx, top, z_high, 0.12, 0.14, note)
            if cross_span >= 4.0:
                add_beam(out, code("TER"), LAYER_STRUCTURE, "terzera", roof, left + cross_span * 0.25, bottom, left + cross_span * 0.25, top, z_mid, 0.10, 0.12, note)
                add_beam(out, code("TER"), LAYER_STRUCTURE, "terzera", roof, right - cross_span * 0.25, bottom, right - cross_span * 0.25, top, z_mid, 0.10, 0.12, note)
            for y in positions_between(bottom, top, campate):
                add_beam(out, code("CAM"), LAYER_STRUCTURE, "catena-campata", roof, left, y, right, y, z_low, 0.10, 0.12, note)
        else:
            add_beam(out, code("COL"), LAYER_STRUCTURE, "colmo", roof, left, cy, right, cy, z_high, 0.12, 0.14, note)
            if cross_span >= 4.0:
                add_beam(out, code("TER"), LAYER_STRUCTURE, "terzera", roof, left, bottom + cross_span * 0.25, right, bottom + cross_span * 0.25, z_mid, 0.10, 0.12, note)
                add_beam(out, code("TER"), LAYER_STRUCTURE, "terzera", roof, left, top - cross_span * 0.25, right, top - cross_span * 0.25, z_mid, 0.10, 0.12, note)
            for x in positions_between(left, right, campate):
                add_beam(out, code("CAM"), LAYER_STRUCTURE, "catena-campata", roof, x, bottom, x, top, z_low, 0.10, 0.12, note)
    return out


def build_finishes(rows):
    opening_rows = [
        row for row in rows
        if row["type"] in {"Window", "Door"}
        and row["layer"] == "Strutturale - Portante"
        and not row["layer"].startswith("BERRA_STANDBY_")
    ]
    opening_rows.sort(key=lambda row: (row["type"], row["y1"], row["x1"], row["z1"]))
    out = []
    counters = Counter()

    def code(prefix):
        counters[prefix] += 1
        return f"BER-V12-{prefix}-{counters[prefix]:03d}"

    for op in opening_rows:
        x1, x2, y1, y2 = op["x1"], op["x2"], op["y1"], op["y2"]
        z1, z2 = op["z1"], op["z2"]
        dx = x2 - x1
        dy = y2 - y1
        dz = max(0.35, z2 - z1)
        if max(dx, dy) < 0.38:
            continue
        is_window = op["type"] == "Window"
        prefix = "FIN" if is_window else "POR"
        note = "finitura assiale allineata all'apertura esistente"
        pad = 0.06
        w = 0.055 if is_window else 0.075
        h = 0.060 if is_window else 0.085

        if dx >= dy:
            yc = (y1 + y2) / 2.0
            add_beam(out, code(prefix + "-ARC"), LAYER_FINISHES, "architrave", op, x1 - pad, yc, x2 + pad, yc, z2 + 0.02, w, h, note)
            add_column(out, code(prefix + "-SP"), LAYER_FINISHES, "spalla", op, x1 - pad, yc, z1 - 0.02, dz + 0.08, w, max(0.08, dy + 0.04), note)
            add_column(out, code(prefix + "-SP"), LAYER_FINISHES, "spalla", op, x2 + pad, yc, z1 - 0.02, dz + 0.08, w, max(0.08, dy + 0.04), note)
            if is_window:
                add_beam(out, code(prefix + "-DAV"), LAYER_FINISHES, "davanzale", op, x1 - pad, yc, x2 + pad, yc, z1 - 0.05, w, h, note)
        else:
            xc = (x1 + x2) / 2.0
            add_beam(out, code(prefix + "-ARC"), LAYER_FINISHES, "architrave", op, xc, y1 - pad, xc, y2 + pad, z2 + 0.02, w, h, note)
            add_column(out, code(prefix + "-SP"), LAYER_FINISHES, "spalla", op, xc, y1 - pad, z1 - 0.02, dz + 0.08, max(0.08, dx + 0.04), w, note)
            add_column(out, code(prefix + "-SP"), LAYER_FINISHES, "spalla", op, xc, y2 + pad, z1 - 0.02, dz + 0.08, max(0.08, dx + 0.04), w, note)
            if is_window:
                add_beam(out, code(prefix + "-DAV"), LAYER_FINISHES, "davanzale", op, xc, y1 - pad, xc, y2 + pad, z1 - 0.05, w, h, note)
    return out


def create_rows(commands, types, rows):
    created = []
    failures = []
    for row in rows:
        command_name = "CreateBeams" if row["kind"] == "Beam" else "CreateColumns"
        payload_key = "beamsData" if row["kind"] == "Beam" else "columnsData"
        try:
            result = tapir(commands, types, command_name, {payload_key: [row["data"]]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": row["code"], "kind": row["kind"], "error": "nessun elemento restituito", "result": result})
                continue
            new_row = dict(row)
            new_row["element"] = elements[0]
            created.append(new_row)
        except Exception as exc:
            failures.append({"code": row["code"], "kind": row["kind"], "error": str(exc)})
    return created, failures


def set_layers(commands, types, created_rows, layer_indices):
    if not created_rows:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {
                    "elementId": row["element"]["elementId"],
                    "details": {"layerIndex": int(layer_indices[row["layer"]])},
                }
                for row in created_rows
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def write_general_ids(commands, types, created_rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created_rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created_rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created_rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def write_outputs(layer_indices, created_rows, failures, layer_result, id_result):
    fields = [
        "codice_id",
        "guid",
        "layer",
        "tipo",
        "classe",
        "source_type",
        "source_layer",
        "source_id",
        "source_guid",
        "x1",
        "y1",
        "x2",
        "y2",
        "z",
        "larghezza",
        "altezza",
        "profondita",
        "lunghezza_m",
        "volume_stimato_m3",
        "note",
    ]
    csv_rows = []
    for row in created_rows:
        length = math.hypot(row["x2"] - row["x1"], row["y2"] - row["y1"]) if row["kind"] == "Beam" else row["height"]
        depth = row["height"] if row["kind"] == "Beam" else row.get("depth", row["width"])
        volume = length * row["width"] * depth
        csv_rows.append(
            {
                "codice_id": row["code"],
                "guid": row["element"]["elementId"]["guid"],
                "layer": row["layer"],
                "tipo": row["kind"],
                "classe": row["classe"],
                "source_type": row["sourceType"],
                "source_layer": row["sourceLayer"],
                "source_id": row["sourceId"],
                "source_guid": row["sourceGuid"],
                "x1": row["x1"],
                "y1": row["y1"],
                "x2": row["x2"],
                "y2": row["y2"],
                "z": row["z"],
                "larghezza": row["width"],
                "altezza": row["height"],
                "profondita": row["depth"],
                "lunghezza_m": round(length, 4),
                "volume_stimato_m3": round(volume, 5),
                "note": row["note"],
            }
        )
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(csv_rows)

    by_layer = Counter(row["layer"] for row in created_rows)
    by_class = Counter(row["classe"] for row in created_rows)
    by_kind = Counter(row["kind"] for row in created_rows)
    payload = {
        "layers": layer_indices,
        "created": len(created_rows),
        "failures": failures,
        "summaryByLayer": dict(by_layer),
        "summaryByClass": dict(by_class),
        "summaryByKind": dict(by_kind),
        "setLayerResult": layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V12 - STRUTTURE E FINITURE ALLINEATE",
                "=" * 50,
                f"Layer struttura: {LAYER_STRUCTURE} index {layer_indices[LAYER_STRUCTURE]}",
                f"Layer finiture: {LAYER_FINISHES} index {layer_indices[LAYER_FINISHES]}",
                f"Elementi creati: {len(created_rows)}",
                "Per layer:",
                *(f"- {layer}: {count}" for layer, count in sorted(by_layer.items())),
                "Per classe:",
                *(f"- {classe}: {count}" for classe, count in sorted(by_class.items())),
                "Per tipo:",
                *(f"- {kind}: {count}" for kind, count in sorted(by_kind.items())),
                f"Fallimenti: {len(failures)}",
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea V12: struttura per campate e finiture assiali leggere.")
        print("Uso: py 71_tapir_v12_strutture_finiture_allineate_berra.py APPLICA")
        print("Per rilanciare su layer gia popolati: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    structure_index = create_or_get_layer(commands, types, LAYER_STRUCTURE, 191)
    finishes_index = create_or_get_layer(commands, types, LAYER_FINISHES, 192)
    layer_indices = {LAYER_STRUCTURE: structure_index, LAYER_FINISHES: finishes_index}

    model_rows = get_all_rows(commands, types)
    existing = count_on_layer(model_rows, LAYER_STRUCTURE) + count_on_layer(model_rows, LAYER_FINISHES)
    if existing and not force:
        print(f"Layer V12 gia popolati con {existing} elementi. Nessuna modifica.")
        print("Usa FORZA solo dopo verifica visiva.")
        return

    rows = build_structure(model_rows) + build_finishes(model_rows)
    created_rows, failures = create_rows(commands, types, rows)
    layer_result = set_layers(commands, types, created_rows, layer_indices)
    id_result = write_general_ids(commands, types, created_rows)
    write_outputs(layer_indices, created_rows, failures, layer_result, id_result)

    print("BERRA V12 strutture/finiture allineate applicata.")
    print(f"Elementi creati: {len(created_rows)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
