from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import ezdxf
from PIL import Image, ImageDraw


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
DWG_OUT = ROOT / "output_berra_dwg_struttura_110626"
IFC_OUT = ROOT / "output_berra_v17_ufficiale_pipeline"
V20_OUT = ROOT / "output_berra_v20_falde_pln"
V21_OUT = ROOT / "output_berra_v21_calibrazione_dwg"
OUT = ROOT / "output_berra_v22_punti_omologhi"

DWG_SEGMENTS = DWG_OUT / "dwg_struttura_110626_flat_segments.csv"
IFC_ROOF_FACES = IFC_OUT / "berra_v17_ufficiale_ifc_roof_faces.csv"
V20_AXES = V20_OUT / "berra_v20_assi_falde_pln_allineati.csv"
CALIBRATION = V21_OUT / "v21_candidati_calibrazione.csv"


def bbox_points(points):
    return min(p[0] for p in points), min(p[1] for p in points), max(p[0] for p in points), max(p[1] for p in points)


def centroid(b):
    return (b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0


def read_calibration(candidate="D_similitudine_ottimizzata"):
    with CALIBRATION.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            if r["candidate"] == candidate:
                return {
                    "dx": float(r["dx"]),
                    "dy": float(r["dy"]),
                    "rot_deg": float(r["rot_deg"]),
                    "scale": float(r["scale"]) if r["scale"] else 1.0,
                    "sx": float(r["sx"]) if r["sx"] else None,
                    "sy": float(r["sy"]) if r["sy"] else None,
                    "center": None,
                }
    raise RuntimeError(f"Candidato non trovato: {candidate}")


def transform_point(p, t):
    x, y = p
    cx, cy = t["center"]
    x -= cx
    y -= cy
    sx = t["sx"] if t["sx"] is not None else t["scale"]
    sy = t["sy"] if t["sy"] is not None else t["scale"]
    x *= sx
    y *= sy
    a = math.radians(t["rot_deg"])
    ca = math.cos(a)
    sa = math.sin(a)
    xr = x * ca - y * sa
    yr = x * sa + y * ca
    return xr + cx + t["dx"], yr + cy + t["dy"]


def inverse_transform_point(p, t):
    x, y = p
    cx, cy = t["center"]
    x -= cx + t["dx"]
    y -= cy + t["dy"]
    a = math.radians(-t["rot_deg"])
    ca = math.cos(a)
    sa = math.sin(a)
    xr = x * ca - y * sa
    yr = x * sa + y * ca
    sx = t["sx"] if t["sx"] is not None else t["scale"]
    sy = t["sy"] if t["sy"] is not None else t["scale"]
    return xr / sx + cx, yr / sy + cy


def read_dwg_segments():
    rows = []
    with DWG_SEGMENTS.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            length = float(r["length"])
            if length < 0.05:
                continue
            rows.append(
                {
                    "layer": r["layer"],
                    "type": r["type"],
                    "x1": float(r["x1"]),
                    "y1": float(r["y1"]),
                    "x2": float(r["x2"]),
                    "y2": float(r["y2"]),
                    "length": length,
                }
            )
    return rows


def read_ifc_edges():
    edges = []
    vertices = []
    with IFC_ROOF_FACES.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=";")
        for r in reader:
            pts3 = json.loads(r["points"])
            pts = [(float(p[0]), float(p[1])) for p in pts3]
            vertices.extend(pts)
            for a, b in zip(pts, pts[1:] + pts[:1]):
                length = math.hypot(b[0] - a[0], b[1] - a[1])
                if length > 0.05:
                    edges.append({"roof_id": r["roof_id"], "x1": a[0], "y1": a[1], "x2": b[0], "y2": b[1], "length": length})
    # De-duplicate vertices by rounded coordinates.
    uniq = {}
    for x, y in vertices:
        uniq[(round(x, 3), round(y, 3))] = (x, y)
    return edges, list(uniq.values())


def read_v20_axes():
    axes = []
    if not V20_AXES.exists():
        return axes
    with V20_AXES.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f, delimiter=";"):
            x0 = float(r["x0"])
            y0 = float(r["y0"])
            x1 = float(r["x1"])
            y1 = float(r["y1"])
            if math.hypot(x1 - x0, y1 - y0) > 0.05:
                axes.append({"code": r["code"], "x1": x0, "y1": y0, "x2": x1, "y2": y1})
    return axes


def unique_endpoints(segments):
    points = {}
    for s in segments:
        for x, y in [(s["x1"], s["y1"]), (s["x2"], s["y2"])]:
            key = (round(x, 2), round(y, 2))
            points[key] = (x, y)
    return list(points.values())


def nearest_point(target, points, used):
    best = None
    best_score = 1e9
    for p in points:
        key = (round(p[0], 2), round(p[1], 2))
        penalty = 1000 if key in used else 0
        score = math.hypot(p[0] - target[0], p[1] - target[1]) + penalty
        if score < best_score:
            best = p
            best_score = score
    if best is not None:
        used.add((round(best[0], 2), round(best[1], 2)))
    return best


def nearest_ifc_vertex(dwg_point, transformed_vertices):
    best = None
    best_dist = 1e9
    for original, transformed in transformed_vertices:
        d = math.hypot(transformed[0] - dwg_point[0], transformed[1] - dwg_point[1])
        if d < best_dist:
            best = (original, transformed)
            best_dist = d
    return best, best_dist


def render(segments, ifc_edges, v20_axes, anchors, t, path):
    ifc_t = [
        {
            "x1": transform_point((s["x1"], s["y1"]), t)[0],
            "y1": transform_point((s["x1"], s["y1"]), t)[1],
            "x2": transform_point((s["x2"], s["y2"]), t)[0],
            "y2": transform_point((s["x2"], s["y2"]), t)[1],
        }
        for s in ifc_edges
    ]
    v20_t = [
        {
            "x1": transform_point((s["x1"], s["y1"]), t)[0],
            "y1": transform_point((s["x1"], s["y1"]), t)[1],
            "x2": transform_point((s["x2"], s["y2"]), t)[0],
            "y2": transform_point((s["x2"], s["y2"]), t)[1],
        }
        for s in v20_axes
    ]
    pts = [(s["x1"], s["y1"]) for s in segments] + [(s["x2"], s["y2"]) for s in segments]
    pts += [(s["x1"], s["y1"]) for s in ifc_t] + [(s["x2"], s["y2"]) for s in ifc_t]
    b = bbox_points(pts)
    minx, miny, maxx, maxy = b
    w, h = 1800, 2550
    margin = 90
    scale = min((w - margin * 2) / max(maxx - minx, 1e-9), (h - margin * 2) / max(maxy - miny, 1e-9))
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def tx(x, y):
        return int(margin + (x - minx) * scale), int(h - margin - (y - miny) * scale)

    for s in segments:
        layer = s["layer"].lower()
        if "strutturale" in layer or "portante" in layer:
            color = (20, 20, 20)
            width = 2
        else:
            color = (205, 205, 205)
            width = 1
        draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=color, width=width)

    for s in ifc_t:
        draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=(220, 45, 45), width=2)
    for s in v20_t:
        draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=(0, 170, 210), width=2)

    for a in anchors:
        x, y = a["dwg_x"], a["dwg_y"]
        px, py = tx(x, y)
        draw.ellipse([px - 11, py - 11, px + 11, py + 11], fill=(255, 230, 0), outline=(0, 0, 0), width=2)
        draw.text((px + 13, py - 12), a["id"], fill=(0, 0, 0))
        # draw approximate relation to nearest transformed IFC vertex
        mx, my = transform_point((a["model_x_guess"], a["model_y_guess"]), t)
        qx, qy = tx(mx, my)
        draw.line([px, py, qx, qy], fill=(180, 110, 0), width=1)
        draw.ellipse([qx - 5, qy - 5, qx + 5, qy + 5], fill=(220, 45, 45))

    draw.text((margin, 25), "V22 punti omologhi proposti - base DWG + falde V21-D", fill=(0, 0, 0))
    draw.text((margin, 50), "giallo = punto DWG proposto | rosso piccolo = vertice falda piu vicino stimato", fill=(70, 70, 70))
    img.save(path, quality=92)


def make_dxf(segments, ifc_edges, v20_axes, anchors, t, path):
    doc = ezdxf.new("R2018")
    msp = doc.modelspace()
    layer_colors = {
        "V22_DWG_STRUTTURA": 7,
        "V22_DWG_CONTESTO": 8,
        "V22_FALDE_IFC_D": 1,
        "V22_ASSI_V20_D": 4,
        "V22_PUNTI_DWG_PROPOSTI": 2,
        "V22_PUNTI_MODELLO_STIMATI": 1,
    }
    for layer, color in layer_colors.items():
        doc.layers.add(layer, color=color)
    for s in segments:
        layer = "V22_DWG_STRUTTURA" if ("strutturale" in s["layer"].lower() or "portante" in s["layer"].lower()) else "V22_DWG_CONTESTO"
        msp.add_line((s["x1"], s["y1"], 0), (s["x2"], s["y2"], 0), dxfattribs={"layer": layer})
    for s in ifc_edges:
        a = transform_point((s["x1"], s["y1"]), t)
        b = transform_point((s["x2"], s["y2"]), t)
        msp.add_line((a[0], a[1], 0), (b[0], b[1], 0), dxfattribs={"layer": "V22_FALDE_IFC_D"})
    for s in v20_axes:
        a = transform_point((s["x1"], s["y1"]), t)
        b = transform_point((s["x2"], s["y2"]), t)
        msp.add_line((a[0], a[1], 0), (b[0], b[1], 0), dxfattribs={"layer": "V22_ASSI_V20_D"})
    for a in anchors:
        msp.add_circle((a["dwg_x"], a["dwg_y"], 0), radius=0.35, dxfattribs={"layer": "V22_PUNTI_DWG_PROPOSTI"})
        msp.add_text(a["id"], dxfattribs={"layer": "V22_PUNTI_DWG_PROPOSTI", "height": 0.65}).set_placement((a["dwg_x"] + 0.45, a["dwg_y"] + 0.45, 0))
        mx, my = transform_point((a["model_x_guess"], a["model_y_guess"]), t)
        msp.add_circle((mx, my, 0), radius=0.18, dxfattribs={"layer": "V22_PUNTI_MODELLO_STIMATI"})
        msp.add_line((a["dwg_x"], a["dwg_y"], 0), (mx, my, 0), dxfattribs={"layer": "V22_PUNTI_MODELLO_STIMATI"})
    doc.saveas(path)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    dwg = read_dwg_segments()
    structural = [s for s in dwg if "strutturale" in s["layer"].lower() or "portante" in s["layer"].lower()]
    ifc_edges, ifc_vertices = read_ifc_edges()
    v20_axes = read_v20_axes()
    tr = read_calibration()
    ifc_bbox = bbox_points(ifc_vertices)
    tr["center"] = centroid(ifc_bbox)

    dwg_bbox = bbox_points([(s["x1"], s["y1"]) for s in structural] + [(s["x2"], s["y2"]) for s in structural])
    minx, miny, maxx, maxy = dwg_bbox
    targets = [
        ("P01", "corpo nord alto - spigolo sinistro", 0.42, 0.94),
        ("P02", "corpo nord alto - spigolo destro", 0.56, 0.94),
        ("P03", "corte superiore - angolo sinistro", 0.33, 0.67),
        ("P04", "corte superiore - angolo destro", 0.72, 0.67),
        ("P05", "corte centrale - angolo basso sinistro", 0.35, 0.49),
        ("P06", "corte centrale - angolo basso destro", 0.70, 0.49),
        ("P07", "ala lunga sinistra - estremo basso", 0.25, 0.08),
        ("P08", "ala lunga destra - estremo basso", 0.84, 0.07),
        ("P09", "lato destro rastremato - nodo superiore", 0.91, 0.74),
        ("P10", "portico centrale - nodo sinistro", 0.42, 0.58),
        ("P11", "portico centrale - nodo destro", 0.72, 0.58),
        ("P12", "corpo laterale sinistro alto", 0.20, 0.78),
    ]

    endpoints = unique_endpoints(structural)
    transformed_vertices = [(p, transform_point(p, tr)) for p in ifc_vertices]
    used = set()
    anchors = []
    for pid, desc, nx, ny in targets:
        target = (minx + nx * (maxx - minx), miny + ny * (maxy - miny))
        p = nearest_point(target, endpoints, used)
        if p is None:
            continue
        match, dist = nearest_ifc_vertex(p, transformed_vertices)
        model_guess = match[0] if match else inverse_transform_point(p, tr)
        anchors.append(
            {
                "id": pid,
                "descrizione": desc,
                "dwg_x": p[0],
                "dwg_y": p[1],
                "model_x_guess": model_guess[0],
                "model_y_guess": model_guess[1],
                "distanza_stima_m": dist,
                "attendibilita": "buona" if dist <= 0.75 else "da_verificare" if dist <= 1.5 else "debole",
            }
        )

    with (OUT / "v22_punti_omologhi_proposti.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["id", "descrizione", "dwg_x", "dwg_y", "model_x_guess", "model_y_guess", "distanza_stima_m", "attendibilita"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(anchors)

    render(dwg, ifc_edges, v20_axes, anchors, tr, OUT / "v22_punti_omologhi_proposti.png")
    make_dxf(dwg, ifc_edges, v20_axes, anchors, tr, OUT / "v22_punti_omologhi_assistiti.dxf")

    report = [
        "# V22 punti omologhi assistiti",
        "",
        "Questa uscita serve per scegliere punti affidabili tra DWG struttura e modello. Non modifica Archicad.",
        "",
        "## Lettura",
        "",
        "- punti gialli: spigoli DWG proposti",
        "- punti rossi piccoli: vertice falda piu vicino stimato con la calibrazione V21-D",
        "- linea sottile: distanza tra proposta DWG e vertice modello stimato",
        "",
        "## Punti proposti",
        "",
    ]
    for a in anchors:
        report.append(
            f"- {a['id']} `{a['descrizione']}`: DWG ({a['dwg_x']:.3f}, {a['dwg_y']:.3f}), "
            f"modello stimato ({a['model_x_guess']:.3f}, {a['model_y_guess']:.3f}), "
            f"distanza {a['distanza_stima_m']:.3f} m, {a['attendibilita']}"
        )
    report.extend(
        [
            "",
            "## Output",
            "",
            "- `v22_punti_omologhi_proposti.png`",
            "- `v22_punti_omologhi_assistiti.dxf`",
            "- `v22_punti_omologhi_proposti.csv`",
            "",
            "## Passo successivo",
            "",
            "Usare solo i punti con spigoli reali riconoscibili in entrambe le basi. I punti marcati `debole` non devono guidare una trasformazione finale.",
        ]
    )
    (OUT / "v22_punti_omologhi_report.md").write_text("\n".join(report), encoding="utf-8")
    print(f"Creati {len(anchors)} punti omologhi proposti")
    print(OUT)


if __name__ == "__main__":
    main()
