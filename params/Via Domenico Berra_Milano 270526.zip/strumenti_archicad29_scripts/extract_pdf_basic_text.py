from __future__ import annotations

import re
import sys
import zlib
from pathlib import Path


def pdf_unescape(text: str) -> str:
    out = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        i += 1
        if i >= len(text):
            break
        esc = text[i]
        i += 1
        table = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f", "\\": "\\", "(": ")", ")": ")"}
        if esc in table:
            out.append(table[esc])
        elif esc in "01234567":
            octal = esc
            for _ in range(2):
                if i < len(text) and text[i] in "01234567":
                    octal += text[i]
                    i += 1
            try:
                out.append(chr(int(octal, 8)))
            except Exception:
                pass
        else:
            out.append(esc)
    return "".join(out)


def decode_pdf_bytes(raw: bytes) -> str:
    for encoding in ("utf-8", "latin-1"):
        try:
            return raw.decode(encoding, errors="ignore")
        except Exception:
            pass
    return raw.decode("latin-1", errors="ignore")


def extract_streams(data: bytes) -> list[bytes]:
    streams = []
    for match in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
        stream = match.group(1)
        header_start = max(0, match.start() - 800)
        header = data[header_start : match.start()]
        if b"/FlateDecode" in header:
            try:
                stream = zlib.decompress(stream)
            except Exception:
                try:
                    stream = zlib.decompress(stream.strip())
                except Exception:
                    pass
        streams.append(stream)
    return streams


def extract_text_from_stream(stream: bytes) -> str:
    text = decode_pdf_bytes(stream)
    chunks = []
    # Literal strings shown with Tj/TJ operators.
    for literal in re.findall(r"\((?:\\.|[^\\()])*\)\s*Tj", text, re.S):
        value = literal.rsplit(")", 1)[0][1:]
        chunks.append(pdf_unescape(value))
    for array in re.findall(r"\[(.*?)\]\s*TJ", text, re.S):
        values = re.findall(r"\((?:\\.|[^\\()])*\)", array, re.S)
        line = "".join(pdf_unescape(v[1:-1]) for v in values)
        if line.strip():
            chunks.append(line)
    # Hex strings, often UTF-16BE or one-byte encoded.
    for hex_value in re.findall(r"<([0-9A-Fa-f\s]{4,})>\s*Tj", text):
        compact = re.sub(r"\s+", "", hex_value)
        try:
            raw = bytes.fromhex(compact)
        except Exception:
            continue
        for enc in ("utf-16-be", "latin-1"):
            decoded = raw.decode(enc, errors="ignore").replace("\x00", "")
            if decoded.strip():
                chunks.append(decoded)
                break
    return "\n".join(chunks)


def main() -> None:
    if len(sys.argv) < 3:
        print("Uso: python extract_pdf_basic_text.py input.pdf output.txt")
        raise SystemExit(2)
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    data = src.read_bytes()
    streams = extract_streams(data)
    pages = len(re.findall(rb"/Type\s*/Page\b", data))
    parts = []
    for i, stream in enumerate(streams, start=1):
        text = extract_text_from_stream(stream)
        if text.strip():
            parts.append(f"--- stream {i} ---\n{text}")
    report = [
        f"PDF: {src}",
        f"Dimensione byte: {len(data)}",
        f"Pagine stimate: {pages}",
        f"Stream letti: {len(streams)}",
        "",
        "\n\n".join(parts) if parts else "Nessun testo estraibile con metodo base.",
    ]
    dst.write_text("\n".join(report), encoding="utf-8")
    print(dst)


if __name__ == "__main__":
    main()
