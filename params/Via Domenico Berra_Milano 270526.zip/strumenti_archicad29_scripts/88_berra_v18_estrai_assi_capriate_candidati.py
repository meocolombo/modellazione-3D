from __future__ import annotations

import ast
import csv
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageOps


try:
    import ezdxf
except Exception:  # pragma: no cover
    ezdxf = None


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
BASE = Path(r"E:\Project_berra_Prova 04 100626\CARTELLA BERRA_100626\COSTRUZIONE_100625")
PIPELINE = ROOT / "output_berra_v17_ufficiale_pipeline"

FACES_CSV = PIPELINE / "berra_v17_ufficiale_ifc_roof_faces.csv"
PLAN_CAPRIATE = BASE / r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\PLANIMETRIA CAPRIATE.jpg"

OUT_CSV = PIPELINE / "berra_v18_assi_capriate_candidati.csv"
OUT_PRIMARY_CSV = PIPELINE / "berra_v18_assi_capriate_primari_da_verificare.csv"
OUT_DXF = PIPELINE / "berra_v18_assi_capriate_candidati.dxf"
OUT_PNG = PIPELINE / "berra_v18_assi_capriate_candidati.png"
OUT_REPORT = PIPELINE / "berra_v18_assi_capriate_candidati_report.md"


# Same candidate alignment selected in V17, variant B.
CROP = {
    "x0": 680,
    "y0": 680,
    "x1": 1785,
    "y1": 3355,
}


@dataclass
class Segment:
    orientation: str
    x0: int
    y0: int
    x1: int
    y1: int

    @property
    def length_px(self) -> float:
        return math.hypot(self.x1 - self.x0, self.y1 - self.y0)


def parse_points(value: str) -> list[tuple[float, float, float]]:
    data = ast.literal_eval(value)
    return [(float(x), float(y), float(z)) for x, y, z in data]


def read_model_bbox() -> dict[str, float]:
    xs: list[float] = []
    ys: list[float] = []
    zs: list[float] = []
    with FACES_CSV.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        for row in reader:
            for x, y, z in parse_points(row["points"]):
                xs.append(x)
                ys.append(y)
                zs.append(z)
    return {
        "min_x": min(xs),
        "max_x": max(xs),
        "min_y": min(ys),
        "max_y": max(ys),
        "min_z": min(zs),
        "max_z": max(zs),
    }


def raster_to_model(px: float, py: float, bbox: dict[str, float]) -> tuple[float, float]:
    nx = (px - CROP["x0"]) / (CROP["x1"] - CROP["x0"])
    ny = (py - CROP["y0"]) / (CROP["y1"] - CROP["y0"])
    x = bbox["min_x"] + nx * (bbox["max_x"] - bbox["min_x"])
    y = bbox["min_y"] + ny * (bbox["max_y"] - bbox["min_y"])
    return x, y


def structural_mask(image: Image.Image) -> np.ndarray:
    rgb = np.asarray(image.convert("RGB"))
    r = rgb[:, :, 0].astype(np.int16)
    g = rgb[:, :, 1].astype(np.int16)
    b = rgb[:, :, 2].astype(np.int16)
    gray = (0.299 * r + 0.587 * g + 0.114 * b)

    dark = gray < 178
    green_annotation = (g > r + 18) & (g > b + 18)
    red_crop = (r > 180) & (g < 100) & (b < 100)

    mask = dark & ~green_annotation & ~red_crop
    return mask


def runs_in_bool(row: np.ndarray, min_len: int) -> list[tuple[int, int]]:
    runs: list[tuple[int, int]] = []
    start: int | None = None
    for idx, value in enumerate(row):
        if value and start is None:
            start = idx
        elif not value and start is not None:
            if idx - start >= min_len:
                runs.append((start, idx - 1))
            start = None
    if start is not None and len(row) - start >= min_len:
        runs.append((start, len(row) - 1))
    return runs


def merge_horizontal(raw: list[Segment]) -> list[Segment]:
    raw = sorted(raw, key=lambda s: (s.y0, s.x0))
    merged: list[Segment] = []
    for seg in raw:
        matched = False
        for idx, cur in enumerate(merged):
            if abs(seg.y0 - cur.y0) <= 3 and not (seg.x1 < cur.x0 - 8 or seg.x0 > cur.x1 + 8):
                merged[idx] = Segment("H", min(cur.x0, seg.x0), int(round((cur.y0 + seg.y0) / 2)), max(cur.x1, seg.x1), int(round((cur.y1 + seg.y1) / 2)))
                matched = True
                break
        if not matched:
            merged.append(seg)
    return merged


def merge_vertical(raw: list[Segment]) -> list[Segment]:
    raw = sorted(raw, key=lambda s: (s.x0, s.y0))
    merged: list[Segment] = []
    for seg in raw:
        matched = False
        for idx, cur in enumerate(merged):
            if abs(seg.x0 - cur.x0) <= 3 and not (seg.y1 < cur.y0 - 8 or seg.y0 > cur.y1 + 8):
                merged[idx] = Segment("V", int(round((cur.x0 + seg.x0) / 2)), min(cur.y0, seg.y0), int(round((cur.x1 + seg.x1) / 2)), max(cur.y1, seg.y1))
                matched = True
                break
        if not matched:
            merged.append(seg)
    return merged


def extract_segments(mask: np.ndarray) -> list[Segment]:
    h, w = mask.shape
    raw_h: list[Segment] = []
    raw_v: list[Segment] = []

    for y in range(h):
        for x0, x1 in runs_in_bool(mask[y, :], min_len=42):
            raw_h.append(Segment("H", x0, y, x1, y))

    for x in range(w):
        for y0, y1 in runs_in_bool(mask[:, x], min_len=42):
            raw_v.append(Segment("V", x, y0, x, y1))

    merged = merge_horizontal(raw_h) + merge_vertical(raw_v)

    # Drop page/frame leftovers and very long lot-border lines. The aim is capriate/roof candidates.
    useful: list[Segment] = []
    for seg in merged:
        if seg.length_px < 55:
            continue
        if seg.length_px > 760:
            continue
        if seg.x0 < 8 or seg.y0 < 8 or seg.x1 > w - 8 or seg.y1 > h - 8:
            continue
        useful.append(seg)
    return useful


def write_outputs(segments: list[Segment], bbox: dict[str, float], image_crop: Image.Image) -> None:
    rows: list[dict[str, object]] = []
    for idx, seg in enumerate(segments, start=1):
        abs_x0 = CROP["x0"] + seg.x0
        abs_y0 = CROP["y0"] + seg.y0
        abs_x1 = CROP["x0"] + seg.x1
        abs_y1 = CROP["y0"] + seg.y1
        mx0, my0 = raster_to_model(abs_x0, abs_y0, bbox)
        mx1, my1 = raster_to_model(abs_x1, abs_y1, bbox)
        if seg.length_px >= 220:
            classe = "primario"
        elif seg.length_px >= 110:
            classe = "secondario"
        else:
            classe = "dettaglio"
        rows.append(
            {
                "id": f"BERRA-V18-CAP-AX-{idx:03d}",
                "classe": classe,
                "orientation": seg.orientation,
                "raster_x0": abs_x0,
                "raster_y0": abs_y0,
                "raster_x1": abs_x1,
                "raster_y1": abs_y1,
                "model_x0": round(mx0, 4),
                "model_y0": round(my0, 4),
                "model_x1": round(mx1, 4),
                "model_y1": round(my1, 4),
                "length_px": round(seg.length_px, 2),
                "status": "candidato_da_verificare",
                "source": "PLANIMETRIA CAPRIATE.jpg",
            }
        )

    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()) if rows else ["id"], delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    primary_rows = [row for row in rows if row.get("classe") == "primario"]
    with OUT_PRIMARY_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()) if rows else ["id"], delimiter=";")
        writer.writeheader()
        writer.writerows(primary_rows)

    preview = image_crop.convert("RGB")
    draw = ImageDraw.Draw(preview, "RGBA")
    for seg in segments:
        color = (230, 70, 30, 210) if seg.orientation == "H" else (30, 110, 230, 210)
        draw.line([seg.x0, seg.y0, seg.x1, seg.y1], fill=color, width=3)
    preview.thumbnail((1300, 1800), Image.Resampling.LANCZOS)
    preview.save(OUT_PNG, quality=92)

    if ezdxf is not None and rows:
        doc = ezdxf.new("R2010")
        doc.layers.add("BERRA_V18_ASSI_CAPRIATE_CANDIDATI", color=30)
        msp = doc.modelspace()
        for row in rows:
            msp.add_line(
                (float(row["model_x0"]), float(row["model_y0"]), 0.0),
                (float(row["model_x1"]), float(row["model_y1"]), 0.0),
                dxfattribs={"layer": "BERRA_V18_ASSI_CAPRIATE_CANDIDATI"},
            )
        doc.saveas(OUT_DXF)

    lines = [
        "# Berra V18 - assi capriate candidati",
        "",
        "Questa passata non modifica Archicad.",
        "",
        "## Input",
        "",
        f"- `{PLAN_CAPRIATE}`",
        f"- `{FACES_CSV.name}`",
        "",
        "## Output",
        "",
        f"- `{OUT_CSV.name}`",
        f"- `{OUT_PRIMARY_CSV.name}`",
        f"- `{OUT_PNG.name}`",
    ]
    if ezdxf is not None:
        lines.append(f"- `{OUT_DXF.name}`")
    lines.extend(
        [
            "",
            "## Conteggio",
            "",
            f"- Segmenti candidati: {len(segments)}",
            f"- Assi primari da verificare: {sum(1 for row in rows if row['classe'] == 'primario')}",
            f"- Assi secondari: {sum(1 for row in rows if row['classe'] == 'secondario')}",
            f"- Linee di dettaglio: {sum(1 for row in rows if row['classe'] == 'dettaglio')}",
            f"- Orizzontali: {sum(1 for s in segments if s.orientation == 'H')}",
            f"- Verticali: {sum(1 for s in segments if s.orientation == 'V')}",
            "",
            "## Nota",
            "",
            "Questi segmenti sono candidati: includono assi e linee tecniche della tavola.",
            "Devono essere filtrati e verificati visivamente prima di diventare travi/capriate BIM.",
        ]
    )
    OUT_REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    PIPELINE.mkdir(parents=True, exist_ok=True)
    bbox = read_model_bbox()
    image = ImageOps.exif_transpose(Image.open(PLAN_CAPRIATE)).convert("RGB")
    crop = image.crop((CROP["x0"], CROP["y0"], CROP["x1"], CROP["y1"]))
    mask = structural_mask(crop)
    segments = extract_segments(mask)
    write_outputs(segments, bbox, crop)

    print(f"Creato: {OUT_CSV}")
    print(f"Creato: {OUT_PRIMARY_CSV}")
    print(f"Creato: {OUT_PNG}")
    if ezdxf is not None:
        print(f"Creato: {OUT_DXF}")
    print(f"Creato: {OUT_REPORT}")
    print(f"Segmenti candidati: {len(segments)}")


if __name__ == "__main__":
    main()
