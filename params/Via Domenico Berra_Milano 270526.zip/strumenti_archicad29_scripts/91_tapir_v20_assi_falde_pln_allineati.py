from __future__ import annotations

import csv
import json
import math
from pathlib import Path

from archicad import ACConnection


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
OUT_DIR = ROOT / "output_berra_v20_falde_pln"
OUT_DIR.mkdir(parents=True, exist_ok=True)

LAYER_NAME = "BERRA_V20_RIF_ASSI_FALDE_PLN_ALLINEATI"
STANDBY_LAYER = "BERRA_STANDBY_V20_RIF_ASSI_FALDE_PRECEDENTI"

OUT_CSV = OUT_DIR / "berra_v20_assi_falde_pln_allineati.csv"
OUT_JSON = OUT_DIR / "berra_v20_assi_falde_pln_allineati_result.json"
OUT_REPORT = OUT_DIR / "berra_v20_assi_falde_pln_allineati_report.md"

BEAM_WIDTH = 0.07
BEAM_HEIGHT = 0.07
Z_OFFSET = 0.35


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def normalize_elements(elements):
    normalized = []
    for element in elements or []:
        if "elementId" in element:
            normalized.append(element)
        elif "guid" in element:
            normalized.append({"elementId": {"guid": element["guid"]}})
    return normalized


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group, hidden=False):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def move_existing_to_standby(commands, types, source_idx, standby_idx):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    to_move = []
    for element, detail in zip(elements, details):
        try:
            if int(detail.get("layerIndex", -1)) == int(source_idx):
                to_move.append(element)
        except Exception:
            continue
    normalized = normalize_elements(to_move)
    if not normalized:
        return {"moved": 0}
    result = tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": int(standby_idx)}}
                for element in normalized
            ]
        },
    )
    return {"moved": len(normalized), "result": result}


def get_active_roofs(commands, types):
    layer_names = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    roofs = []
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Roof":
            continue
        try:
            layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        except Exception:
            layer = ""
        if layer.startswith("BERRA_STANDBY_"):
            continue
        box = box_item.get("boundingBox3D", {})
        x_min = float(box.get("xMin", 0.0))
        x_max = float(box.get("xMax", 0.0))
        y_min = float(box.get("yMin", 0.0))
        y_max = float(box.get("yMax", 0.0))
        z_min = float(box.get("zMin", 0.0))
        z_max = float(box.get("zMax", 0.0))
        span_x = x_max - x_min
        span_y = y_max - y_min
        if span_x < 2.0 or span_y < 2.0:
            continue
        roofs.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "id": detail.get("id", ""),
                "layer": layer,
                "xMin": x_min,
                "xMax": x_max,
                "yMin": y_min,
                "yMax": y_max,
                "zMin": z_min,
                "zMax": z_max,
                "spanX": span_x,
                "spanY": span_y,
            }
        )
    roofs.sort(key=lambda item: (item["yMin"], item["xMin"], item["guid"]))
    return roofs


def line_for_roof(roof, index):
    x_min, x_max = roof["xMin"], roof["xMax"]
    y_min, y_max = roof["yMin"], roof["yMax"]
    span_x, span_y = roof["spanX"], roof["spanY"]
    margin_x = min(0.75, span_x * 0.12)
    margin_y = min(0.75, span_y * 0.12)
    z = roof["zMax"] + Z_OFFSET

    # This is deliberately a control axis, not a truss. It is constrained inside the
    # roof bounding box, so it must visually follow the PLN before any final modelling.
    if span_x >= span_y:
        x0, x1 = x_min + margin_x, x_max - margin_x
        y0 = y1 = (y_min + y_max) / 2.0
        orientation = "X"
    else:
        y0, y1 = y_min + margin_y, y_max - margin_y
        x0 = x1 = (x_min + x_max) / 2.0
        orientation = "Y"
    return {
        "code": f"BERRA-V20-ROOF-AX-{index:03d}",
        "roofGuid": roof["guid"],
        "roofId": roof["id"],
        "roofLayer": roof["layer"],
        "orientation": orientation,
        "x0": round(x0, 4),
        "y0": round(y0, 4),
        "x1": round(x1, 4),
        "y1": round(y1, 4),
        "z": round(z, 4),
        "length": round(math.hypot(x1 - x0, y1 - y0), 4),
        "data": {
            "begCoordinate": coord(x0, y0),
            "endCoordinate": coord(x1, y1),
            "zCoordinate": float(z),
            "width": BEAM_WIDTH,
            "height": BEAM_HEIGHT,
        },
    }


def set_layer(commands, types, elements, target_idx):
    normalized = normalize_elements(elements)
    if not normalized:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": int(target_idx)}}
                for element in normalized
            ]
        },
    )


def try_set_ids(commands, types, elements, codes):
    updated = 0
    failed = 0
    for element, code in zip(normalize_elements(elements), codes):
        try:
            tapir(
                commands,
                types,
                "SetDetailsOfElements",
                {"elementsWithDetails": [{"elementId": element["elementId"], "details": {"id": code}}]},
            )
            updated += 1
        except Exception:
            failed += 1
    return {"updated": updated, "failed": failed}


def main():
    conn = ACConnection.connect()
    assert conn
    commands = conn.commands
    types = conn.types

    layer_idx = create_or_get_layer(commands, types, LAYER_NAME, 222, hidden=False)
    standby_idx = create_or_get_layer(commands, types, STANDBY_LAYER, 223, hidden=True)
    standby = move_existing_to_standby(commands, types, layer_idx, standby_idx)

    roofs = get_active_roofs(commands, types)
    axes = [line_for_roof(roof, idx) for idx, roof in enumerate(roofs, start=1)]
    payload = [axis["data"] for axis in axes]
    codes = [axis["code"] for axis in axes]

    result = tapir(commands, types, "CreateBeams", {"beamsData": payload}) if payload else {"elements": []}
    elements = normalize_elements(result.get("elements", []))
    layer_result = set_layer(commands, types, elements, layer_idx)
    id_result = try_set_ids(commands, types, elements, codes)

    rows = []
    for axis, element in zip(axes, elements):
        rows.append(
            {
                "code": axis["code"],
                "guid": element["elementId"].get("guid", ""),
                "layer": LAYER_NAME,
                "roofGuid": axis["roofGuid"],
                "roofId": axis["roofId"],
                "roofLayer": axis["roofLayer"],
                "orientation": axis["orientation"],
                "x0": axis["x0"],
                "y0": axis["y0"],
                "x1": axis["x1"],
                "y1": axis["y1"],
                "z": axis["z"],
                "length": axis["length"],
                "status": "asse_falda_pln_da_verificare",
            }
        )
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fieldnames = list(rows[0].keys()) if rows else ["code"]
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    result_doc = {
        "layer": LAYER_NAME,
        "standbyLayer": STANDBY_LAYER,
        "activeRoofs": len(roofs),
        "requested": len(payload),
        "created": len(elements),
        "standby": standby,
        "idResult": id_result,
        "layerResult": layer_result,
    }
    OUT_JSON.write_text(json.dumps(result_doc, ensure_ascii=False, indent=2), encoding="utf-8")

    OUT_REPORT.write_text(
        "\n".join(
            [
                "# Berra V20 - assi falde PLN allineati",
                "",
                "Questa passata crea assi di controllo generati dalla geometria reale delle falde nel PLN.",
                "Non sono capriate definitive e non derivano dalla calibrazione raster errata.",
                "",
                f"- Layer: `{LAYER_NAME}`",
                f"- Layer standby: `{STANDBY_LAYER}`",
                f"- Falde attive lette: {len(roofs)}",
                f"- Assi creati: {len(elements)}",
                f"- Precedenti V20 spostati in standby: {standby.get('moved', 0)}",
                "",
                "Uso: verificare se questi assi seguono correttamente l'edificio. Solo dopo si procede con capriate vere.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"Falde attive: {len(roofs)}")
    print(f"Assi V20 creati: {len(elements)}")
    print(f"Report: {OUT_REPORT}")


if __name__ == "__main__":
    main()

