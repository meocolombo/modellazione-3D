from __future__ import annotations

from html import escape
from pathlib import Path

from archicad import ACConnection


OUT_SVG = Path("berra_v03_topdown_controllo.svg")
OUT_TXT = Path("berra_v03_topdown_controllo.txt")
STANDBY_LAYER = "BERRA_BIM_V03_STANDBY_PRECEDENTI"


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    layer_names = layers_map(commands, types)
    rows = []
    for el, detail, box_item in zip(elements, details, boxes):
        box = box_item.get("boundingBox3D", {})
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        rows.append(
            {
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
                "layer": layer,
                "xMin": float(box.get("xMin", 0.0)),
                "xMax": float(box.get("xMax", 0.0)),
                "yMin": float(box.get("yMin", 0.0)),
                "yMax": float(box.get("yMax", 0.0)),
            }
        )
    return rows


def color(row):
    layer = row["layer"]
    typ = row["type"]
    if layer == STANDBY_LAYER:
        return None
    if layer.startswith("BERRA_BIM_V03_04"):
        return "#9b4f2f", 0.40
    if layer.startswith("BERRA_BIM_V03_05"):
        return "#2f5f9b", 0.45
    if layer.startswith("BERRA_BIM_V03_06"):
        return "#6d4a8e", 0.50
    if layer.startswith("BERRA_BIM_V03_07") or layer.startswith("BERRA_BIM_V03_08"):
        return "#4f7d45", 0.42
    if layer.startswith("BERRA_BIM_V03_09"):
        return "#a06a2a", 0.50
    if typ == "Roof":
        return "#c77d51", 0.32
    if typ == "Wall":
        return "#6c6259", 0.28
    if typ == "Slab":
        return "#b9b2a5", 0.18
    return None


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    rows = get_rows(conn.commands, conn.types)
    draw_rows = [r for r in rows if color(r) and (r["xMax"] - r["xMin"]) > 0.02 and (r["yMax"] - r["yMin"]) > 0.02]
    x_min = min(r["xMin"] for r in draw_rows)
    x_max = max(r["xMax"] for r in draw_rows)
    y_min = min(r["yMin"] for r in draw_rows)
    y_max = max(r["yMax"] for r in draw_rows)
    width = 1300
    height = 900
    pad = 35
    scale = min((width - 2 * pad) / (x_max - x_min), (height - 2 * pad) / (y_max - y_min))

    def sx(x):
        return pad + (x - x_min) * scale

    def sy(y):
        return height - pad - (y - y_min) * scale

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#f5f2ea"/>',
        '<text x="35" y="30" font-family="Arial" font-size="18" fill="#2b2925">Via Berra V03 - controllo top-down</text>',
    ]
    for row in sorted(draw_rows, key=lambda r: (0 if r["type"] in ("Wall", "Slab", "Roof") else 1, r["layer"])):
        col, opacity = color(row)
        x = sx(row["xMin"])
        y = sy(row["yMax"])
        w = max(1.0, (row["xMax"] - row["xMin"]) * scale)
        h = max(1.0, (row["yMax"] - row["yMin"]) * scale)
        stroke = "#2b2925" if row["layer"].startswith("BERRA_BIM_V03_") else "none"
        parts.append(
            f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" fill="{col}" fill-opacity="{opacity}" stroke="{stroke}" stroke-width="0.35"/>'
        )
    legend = [
        ("Base muri/solai/tetti", "#6c6259"),
        ("Strutture tetto V03", "#9b4f2f"),
        ("Aperture/decori V03", "#2f5f9b"),
        ("Loggiati/portali V03", "#6d4a8e"),
        ("Verde/arredi V03", "#4f7d45"),
        ("Proxy Blender/camini", "#a06a2a"),
    ]
    lx, ly = 35, height - 150
    for i, (label, col) in enumerate(legend):
        yy = ly + i * 20
        parts.append(f'<rect x="{lx}" y="{yy}" width="13" height="13" fill="{col}" fill-opacity="0.55"/>')
        parts.append(f'<text x="{lx + 20}" y="{yy + 11}" font-family="Arial" font-size="12" fill="#2b2925">{escape(label)}</text>')
    parts.append("</svg>")
    OUT_SVG.write_text("\n".join(parts), encoding="utf-8")

    visible_counts = {}
    for row in rows:
        if row["layer"] == STANDBY_LAYER:
            continue
        visible_counts[row["layer"]] = visible_counts.get(row["layer"], 0) + 1
    OUT_TXT.write_text(
        "\n".join(
            ["Layer visibili conteggiati nella tavola:", *[f"- {k}: {v}" for k, v in sorted(visible_counts.items(), key=lambda item: (-item[1], item[0]))]]
        ),
        encoding="utf-8",
    )
    print(f"Creato: {OUT_SVG}")
    print(f"Creato: {OUT_TXT}")


if __name__ == "__main__":
    main()
