from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "output_berra_falde_ifc_pipeline"
FACES_CSV = OUT_DIR / "berra_v15_falde_filtrate.csv"
GUIDES_CSV = OUT_DIR / "berra_v15_guide_strutturali_falde.csv"
OUT_PNG = OUT_DIR / "berra_v15_guide_strutturali_topdown.png"


def read_faces():
    faces = []
    with FACES_CSV.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            faces.append(json.loads(row["points"]))
    return faces


def read_guides():
    guides = []
    with GUIDES_CSV.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            guides.append(
                {
                    "role": row["role"],
                    "p1": (float(row["x1"]), float(row["y1"])),
                    "p2": (float(row["x2"]), float(row["y2"])),
                }
            )
    return guides


def main():
    faces = read_faces()
    guides = read_guides()
    points = [(p[0], p[1]) for face in faces for p in face]
    points.extend([g["p1"] for g in guides])
    points.extend([g["p2"] for g in guides])
    min_x = min(p[0] for p in points)
    max_x = max(p[0] for p in points)
    min_y = min(p[1] for p in points)
    max_y = max(p[1] for p in points)
    margin = 60
    width = 1800
    scale = (width - margin * 2) / max(max_x - min_x, max_y - min_y, 1.0)
    height = int((max_y - min_y) * scale + margin * 2)

    def xy(p):
        return (
            int(round(margin + (p[0] - min_x) * scale)),
            int(round(margin + (max_y - p[1]) * scale)),
        )

    image = Image.new("RGB", (width, height), "#f6f4ee")
    draw = ImageDraw.Draw(image, "RGBA")

    for face in faces:
        draw.polygon([xy((p[0], p[1])) for p in face], fill=(187, 111, 78, 35), outline=(85, 68, 55, 180))

    colors = {
        "assito_travicelli_falda": (0, 168, 200, 115),
        "arcarecci_correnti_falda": (47, 158, 68, 150),
        "capriate_linea_controllo": (217, 72, 15, 190),
    }
    widths = {
        "assito_travicelli_falda": 1,
        "arcarecci_correnti_falda": 2,
        "capriate_linea_controllo": 3,
    }
    for guide in guides:
        draw.line([xy(guide["p1"]), xy(guide["p2"])], fill=colors[guide["role"]], width=widths[guide["role"]])

    image.save(OUT_PNG)
    print(OUT_PNG)


if __name__ == "__main__":
    main()
