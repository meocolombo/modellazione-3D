from __future__ import annotations

import csv
import math
from collections import Counter, defaultdict
from pathlib import Path

import ezdxf
from PIL import Image, ImageDraw


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
OUT = ROOT / "output_berra_dwg_struttura_110626"
DXF = OUT / "268_BERRA_10_BACKUP_PRIMA_AI_V03_from_dwg.dxf"


def add_point(bbox: list[float | None], x: float, y: float) -> None:
    bbox[0] = x if bbox[0] is None else min(bbox[0], x)
    bbox[1] = y if bbox[1] is None else min(bbox[1], y)
    bbox[2] = x if bbox[2] is None else max(bbox[2], x)
    bbox[3] = y if bbox[3] is None else max(bbox[3], y)


def layer_of(entity, parent_layer: str | None) -> str:
    layer = str(getattr(entity.dxf, "layer", "") or "")
    if layer in {"", "0"} and parent_layer:
        return parent_layer
    return layer or "0"


def iter_flat_entities(entity, parent_layer: str | None = None, depth: int = 0):
    eff_layer = layer_of(entity, parent_layer)
    etype = entity.dxftype()
    if etype in {"INSERT", "DIMENSION"}:
        try:
            for child in entity.virtual_entities():
                yield from iter_flat_entities(child, eff_layer, depth + 1)
            return
        except Exception:
            pass
    yield entity, eff_layer, depth


def iter_hatch_points(entity):
    try:
        for path in entity.paths:
            if hasattr(path, "vertices"):
                for item in path.vertices:
                    if len(item) >= 2:
                        yield (float(item[0]), float(item[1]))
            if hasattr(path, "edges"):
                for edge in path.edges:
                    if edge.EDGE_TYPE == "LineEdge":
                        yield (float(edge.start[0]), float(edge.start[1]))
                        yield (float(edge.end[0]), float(edge.end[1]))
                    elif edge.EDGE_TYPE == "ArcEdge":
                        cx, cy = edge.center
                        radius = float(edge.radius)
                        start = math.radians(float(edge.start_angle))
                        end = math.radians(float(edge.end_angle))
                        if end < start:
                            end += math.tau
                        for i in range(12):
                            a = start + (end - start) * i / 11
                            yield (float(cx) + radius * math.cos(a), float(cy) + radius * math.sin(a))
    except Exception:
        return


def iter_points(entity):
    etype = entity.dxftype()
    if etype == "LINE":
        yield (float(entity.dxf.start.x), float(entity.dxf.start.y))
        yield (float(entity.dxf.end.x), float(entity.dxf.end.y))
    elif etype == "LWPOLYLINE":
        for p in entity.get_points("xy"):
            yield (float(p[0]), float(p[1]))
    elif etype == "POLYLINE":
        for v in entity.vertices:
            loc = v.dxf.location
            yield (float(loc.x), float(loc.y))
    elif etype in {"CIRCLE", "ARC"}:
        center = entity.dxf.center
        radius = float(entity.dxf.radius)
        if etype == "ARC":
            start = math.radians(float(entity.dxf.start_angle))
            end = math.radians(float(entity.dxf.end_angle))
            if end < start:
                end += math.tau
            steps = max(12, int(abs(end - start) / math.tau * 64))
            for i in range(steps + 1):
                a = start + (end - start) * i / steps
                yield (float(center.x) + radius * math.cos(a), float(center.y) + radius * math.sin(a))
        else:
            for i in range(72):
                a = math.tau * i / 72
                yield (float(center.x) + radius * math.cos(a), float(center.y) + radius * math.sin(a))
    elif etype in {"TEXT", "MTEXT", "POINT"}:
        p = entity.dxf.insert if hasattr(entity.dxf, "insert") else entity.dxf.location
        yield (float(p.x), float(p.y))
    elif etype == "SPLINE":
        for p in entity.control_points:
            yield (float(p[0]), float(p[1]))
    elif etype == "HATCH":
        yield from iter_hatch_points(entity)


def iter_segments(entity):
    etype = entity.dxftype()
    if etype == "LINE":
        a = (float(entity.dxf.start.x), float(entity.dxf.start.y))
        b = (float(entity.dxf.end.x), float(entity.dxf.end.y))
        yield a, b
        return
    pts = list(iter_points(entity))
    if len(pts) < 2:
        return
    closed = etype in {"CIRCLE", "HATCH"} or (etype == "LWPOLYLINE" and bool(entity.closed))
    for a, b in zip(pts, pts[1:]):
        yield a, b
    if closed:
        yield pts[-1], pts[0]


def color_for_layer(layer: str) -> tuple[int, int, int]:
    low = layer.lower()
    if "strutturale" in low or "portante" in low:
        return (35, 35, 35)
    if "finiture" in low or "aperture" in low:
        return (0, 150, 190)
    if "verde" in low or "arredi" in low:
        return (35, 145, 55)
    if "quotatura" in low:
        return (170, 80, 20)
    if "marker" in low:
        return (180, 0, 0)
    return (110, 110, 110)


def render_preview(segments, path: Path, bbox: tuple[float, float, float, float]) -> None:
    minx, miny, maxx, maxy = bbox
    w, h = 1800, 2600
    margin = 90
    sx = (w - margin * 2) / max(maxx - minx, 1e-9)
    sy = (h - margin * 2) / max(maxy - miny, 1e-9)
    s = min(sx, sy)
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def tx(p: tuple[float, float]) -> tuple[int, int]:
        x = margin + (p[0] - minx) * s
        y = h - margin - (p[1] - miny) * s
        return int(round(x)), int(round(y))

    # draw long/main geometry first, small details later
    for seg in sorted(segments, key=lambda r: r["length"], reverse=True):
        c = color_for_layer(seg["layer"])
        width = 3 if seg["length"] > 2.0 else 1
        draw.line([tx((seg["x1"], seg["y1"])), tx((seg["x2"], seg["y2"]))], fill=c, width=width)

    draw.rectangle([margin, margin, w - margin, h - margin], outline=(220, 220, 220), width=1)
    draw.text((margin, 22), "DWG struttura 110626 - blocchi risolti", fill=(0, 0, 0))
    draw.text((margin, 46), f"bbox: {minx:.3f},{miny:.3f} -> {maxx:.3f},{maxy:.3f}", fill=(80, 80, 80))
    img.save(path, quality=92)


def main() -> None:
    doc = ezdxf.readfile(DXF)
    msp = doc.modelspace()

    flat_counts = Counter()
    layer_counts = Counter()
    layer_lengths = defaultdict(float)
    total_bbox: list[float | None] = [None, None, None, None]
    layer_bbox: dict[str, list[float | None]] = defaultdict(lambda: [None, None, None, None])
    segments = []

    for src in msp:
        for entity, layer, depth in iter_flat_entities(src):
            etype = entity.dxftype()
            flat_counts[etype] += 1
            layer_counts[layer] += 1
            for x, y in iter_points(entity):
                add_point(total_bbox, x, y)
                add_point(layer_bbox[layer], x, y)
            for a, b in iter_segments(entity):
                length = math.hypot(b[0] - a[0], b[1] - a[1])
                if length <= 1e-8:
                    continue
                layer_lengths[layer] += length
                segments.append(
                    {
                        "layer": layer,
                        "type": etype,
                        "depth": depth,
                        "x1": a[0],
                        "y1": a[1],
                        "x2": b[0],
                        "y2": b[1],
                        "length": length,
                        "angle_deg": math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])),
                    }
                )

    bbox_tuple = tuple(float(v) for v in total_bbox if v is not None)
    if len(bbox_tuple) != 4:
        raise RuntimeError("Nessuna geometria risolta dai blocchi")

    with (OUT / "dwg_struttura_110626_flat_layers.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["layer", "flat_entity_count", "segment_length", "min_x", "min_y", "max_x", "max_y"])
        for layer, count in layer_counts.most_common():
            bb = layer_bbox[layer]
            writer.writerow(
                [
                    layer,
                    count,
                    f"{layer_lengths[layer]:.6f}",
                    f"{bb[0]:.6f}" if bb[0] is not None else "",
                    f"{bb[1]:.6f}" if bb[1] is not None else "",
                    f"{bb[2]:.6f}" if bb[2] is not None else "",
                    f"{bb[3]:.6f}" if bb[3] is not None else "",
                ]
            )

    with (OUT / "dwg_struttura_110626_flat_segments.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["layer", "type", "depth", "x1", "y1", "x2", "y2", "length", "angle_deg"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(segments)

    with (OUT / "dwg_struttura_110626_flat_entity_counts.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["entity_type", "count"])
        for etype, count in flat_counts.most_common():
            writer.writerow([etype, count])

    render_preview(segments, OUT / "dwg_struttura_110626_flat_preview.png", bbox_tuple)

    minx, miny, maxx, maxy = bbox_tuple
    report = [
        "# DWG struttura 110626 - blocchi risolti",
        "",
        f"File sorgente: `{DXF.name}`",
        f"Entita risolte dai blocchi: {sum(flat_counts.values())}",
        f"Layer effettivi: {len(layer_counts)}",
        f"Segmenti estratti: {len(segments)}",
        "",
        "## Estensione geometrica risolta",
        "",
        f"- min X: {minx:.3f}",
        f"- min Y: {miny:.3f}",
        f"- max X: {maxx:.3f}",
        f"- max Y: {maxy:.3f}",
        f"- larghezza: {maxx - minx:.3f}",
        f"- altezza: {maxy - miny:.3f}",
        "",
        "## Layer principali",
        "",
    ]
    for layer, count in layer_counts.most_common(20):
        report.append(f"- `{layer}`: {count} entita risolte, lunghezza segmenti {layer_lengths[layer]:.2f}")
    report.extend(
        [
            "",
            "## Lettura preliminare",
            "",
            "Il file e composto quasi interamente da blocchi INSERT. La preview flat e quindi il riferimento corretto per verificare l'allineamento.",
            "Non sono state fatte modifiche al modello Archicad.",
        ]
    )
    (OUT / "dwg_struttura_110626_flat_report.md").write_text("\n".join(report), encoding="utf-8")

    print(f"Entita risolte: {sum(flat_counts.values())}")
    print(f"Layer: {len(layer_counts)} | Segmenti: {len(segments)}")
    print(f"BBox flat: {minx:.3f},{miny:.3f} -> {maxx:.3f},{maxy:.3f}")


if __name__ == "__main__":
    main()
