param(
    [Parameter(Mandatory = $true)][string]$PdfPath,
    [Parameter(Mandatory = $true)][string]$OutDir,
    [int]$MaxPages = 5,
    [double]$Scale = 2.0
)

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

Add-Type -AssemblyName System.Runtime.WindowsRuntime

function Await-WinRtTask($AsyncOp, $ResultType) {
    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and
            $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
        })[0]
    $generic = $asTask.MakeGenericMethod($ResultType)
    $task = $generic.Invoke($null, @($AsyncOp))
    $task.Wait()
    return $task.Result
}

function Await-WinRtAction($AsyncAction) {
    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and
            $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'
        })[0]
    $task = $asTask.Invoke($null, @($AsyncAction))
    $task.Wait()
}

[Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Pdf.PdfPageRenderOptions, Windows.Data.Pdf, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.Buffer, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.InputStreamOptions, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.IBuffer, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
$file = Await-WinRtTask ([Windows.Storage.StorageFile]::GetFileFromPathAsync($PdfPath)) ([Windows.Storage.StorageFile])
$doc = Await-WinRtTask ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
$count = [Math]::Min($MaxPages, [int]$doc.PageCount)

for ($i = 0; $i -lt $count; $i++) {
    $page = $doc.GetPage([uint32]$i)
    try {
        $stream = [Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
        $opts = [Windows.Data.Pdf.PdfPageRenderOptions]::new()
        $opts.DestinationWidth = [uint32]([Math]::Max(1, $page.Size.Width * $Scale))
        $opts.DestinationHeight = [uint32]([Math]::Max(1, $page.Size.Height * $Scale))
        Await-WinRtAction ($page.RenderToStreamAsync($stream, $opts))
        $stream.Seek(0) | Out-Null

        $outPath = Join-Path $OutDir ("CM_TETTO_winrt_pagina_{0:D2}.png" -f ($i + 1))
        $size = [uint32]$stream.Size
        $input = $stream.GetInputStreamAt(0)
        $buffer = [Windows.Storage.Streams.Buffer]::new($size)
        $readBuffer = Await-WinRtTask ($input.ReadAsync($buffer, $size, [Windows.Storage.Streams.InputStreamOptions]::None)) ([Windows.Storage.Streams.IBuffer])
        $reader = [Windows.Storage.Streams.DataReader]::FromBuffer($readBuffer)
        $bytes = New-Object byte[] ([int]$readBuffer.Length)
        $reader.ReadBytes($bytes)
        [System.IO.File]::WriteAllBytes($outPath, $bytes)
        Write-Output $outPath
    }
    finally {
        $page.Dispose()
    }
}
