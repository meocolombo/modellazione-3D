from __future__ import annotations

import csv
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import ezdxf
import ifcopenshell
from shapely.geometry import LineString, MultiLineString, Polygon


ROOT = Path(__file__).resolve().parents[1]
SOURCE_IFC = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(r"E:\strumenti-archicad29\berra_export_falde_correnti.ifc")
SOURCE_FACES = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(r"E:\strumenti-archicad29\berra_ifc_roof_faces.csv")
OUT_DIR = Path(sys.argv[3]) if len(sys.argv) > 3 else ROOT / "output_berra_falde_ifc_pipeline"
OUT_GUIDES_CSV = OUT_DIR / "berra_v15_guide_strutturali_falde.csv"
OUT_FACES_CSV = OUT_DIR / "berra_v15_falde_filtrate.csv"
OUT_PLANES_JSON = OUT_DIR / "berra_v15_falde_filtrate.json"
OUT_DXF = OUT_DIR / "berra_v15_guide_strutturali_falde.dxf"
OUT_SVG = OUT_DIR / "berra_v15_guide_strutturali_topdown.svg"
OUT_REPORT = OUT_DIR / "berra_v15_pipeline_report.txt"

RAFTER_SPACING = 0.90
PURLIN_SPACING = 1.60
TRUSS_SPACING = 4.00
MIN_FACE_AREA = 2.0
MIN_NORMAL_Z = 0.25


@dataclass(frozen=True)
class Face:
    roof_id: str
    roof_guid: str
    face_no: int
    points: tuple[tuple[float, float, float], ...]
    normal: tuple[float, float, float]
    area: float


@dataclass(frozen=True)
class Guide:
    role: str
    roof_id: str
    face_no: int
    index: int
    p1: tuple[float, float, float]
    p2: tuple[float, float, float]
    length: float


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def norm(a):
    length = math.sqrt(dot(a, a))
    if length <= 1e-12:
        return (0.0, 0.0, 0.0)
    return (a[0] / length, a[1] / length, a[2] / length)


def length3(a, b):
    return math.sqrt(dot(sub(a, b), sub(a, b)))


def polygon_area_3d(points):
    if len(points) < 3:
        return 0.0
    base = points[0]
    total = (0.0, 0.0, 0.0)
    for i in range(1, len(points) - 1):
        total = add(total, cross(sub(points[i], base), sub(points[i + 1], base)))
    return 0.5 * math.sqrt(dot(total, total))


def face_normal(points):
    if len(points) < 3:
        return (0.0, 0.0, 0.0)
    base = points[0]
    for i in range(1, len(points) - 1):
        n = cross(sub(points[i], base), sub(points[i + 1], base))
        if dot(n, n) > 1e-9:
            n = norm(n)
            return n if n[2] >= 0 else mul(n, -1.0)
    return (0.0, 0.0, 0.0)


def basis_from_normal(n):
    z_axis = (0.0, 0.0, 1.0)
    contour = cross(n, z_axis)
    if dot(contour, contour) <= 1e-10:
        contour = (1.0, 0.0, 0.0)
    contour = norm(contour)
    fall = cross(contour, n)
    fall = norm(fall)
    if fall[2] > 0:
        fall = mul(fall, -1.0)
    return contour, fall


def read_faces_from_csv(path: Path):
    faces: list[Face] = []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            points = tuple(tuple(float(v) for v in p) for p in json.loads(row["points"]))
            n = face_normal(points)
            area = polygon_area_3d(points)
            if n[2] < MIN_NORMAL_Z or area < MIN_FACE_AREA:
                continue
            faces.append(
                Face(
                    roof_id=row["roof_id"],
                    roof_guid=row["roof_guid"],
                    face_no=int(row["face_no"]),
                    points=points,
                    normal=n,
                    area=area,
                )
            )
    return faces


def validate_ifc(path: Path):
    if not path.exists():
        return {"exists": False, "roof_count": 0, "ber_base_cop": 0}
    model = ifcopenshell.open(str(path))
    roofs = model.by_type("IfcRoof")
    return {
        "exists": True,
        "schema": model.schema,
        "roof_count": len(roofs),
        "ber_base_cop": sum(1 for r in roofs if str(getattr(r, "Name", "") or "").startswith("BER-BASE-COP")),
    }


def project_point(origin, u_axis, v_axis, p):
    rel = sub(p, origin)
    return (dot(rel, u_axis), dot(rel, v_axis))


def unproject_point(origin, u_axis, v_axis, uv):
    return add(add(origin, mul(u_axis, uv[0])), mul(v_axis, uv[1]))


def split_intersection_segments(geometry):
    if geometry.is_empty:
        return []
    if isinstance(geometry, LineString):
        coords = list(geometry.coords)
        if len(coords) >= 2:
            return [(coords[0], coords[-1])]
        return []
    if isinstance(geometry, MultiLineString):
        out = []
        for line in geometry.geoms:
            coords = list(line.coords)
            if len(coords) >= 2:
                out.append((coords[0], coords[-1]))
        return out
    if hasattr(geometry, "geoms"):
        out = []
        for item in geometry.geoms:
            out.extend(split_intersection_segments(item))
        return out
    return []


def make_guides_for_face(face: Face):
    origin = face.points[0]
    u_axis, v_axis = basis_from_normal(face.normal)
    poly_uv = [project_point(origin, u_axis, v_axis, p) for p in face.points]
    z_min = min(p[2] for p in face.points)
    z_max = max(p[2] for p in face.points)
    polygon = Polygon(poly_uv)
    if not polygon.is_valid:
        polygon = polygon.buffer(0)
    if polygon.is_empty or polygon.area < MIN_FACE_AREA * 0.2:
        return []

    min_u, min_v, max_u, max_v = polygon.bounds
    guides: list[Guide] = []

    def add_family(role: str, spacing: float, along_v: bool):
        if along_v:
            start = math.ceil(min_u / spacing) * spacing
            end = max_u
        else:
            start = math.ceil(min_v / spacing) * spacing
            end = max_v
        value = start
        idx = 1
        while value <= end + 1e-6:
            if along_v:
                raw = LineString([(value, min_v - 2.0), (value, max_v + 2.0)])
            else:
                raw = LineString([(min_u - 2.0, value), (max_u + 2.0, value)])
            for p1_uv, p2_uv in split_intersection_segments(polygon.intersection(raw)):
                p1 = unproject_point(origin, u_axis, v_axis, p1_uv)
                p2 = unproject_point(origin, u_axis, v_axis, p2_uv)
                seg_len = length3(p1, p2)
                in_z_range = (
                    z_min - 0.20 <= p1[2] <= z_max + 0.20
                    and z_min - 0.20 <= p2[2] <= z_max + 0.20
                )
                if seg_len >= 0.60 and in_z_range:
                    guides.append(Guide(role, face.roof_id, face.face_no, idx, p1, p2, seg_len))
                    idx += 1
            value += spacing

    add_family("assito_travicelli_falda", RAFTER_SPACING, along_v=True)
    add_family("arcarecci_correnti_falda", PURLIN_SPACING, along_v=False)
    add_family("capriate_linea_controllo", TRUSS_SPACING, along_v=True)
    return guides


def write_faces(faces: list[Face]):
    with OUT_FACES_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "roof_id",
            "roof_guid",
            "face_no",
            "area",
            "normal_x",
            "normal_y",
            "normal_z",
            "points",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        for face in faces:
            writer.writerow(
                {
                    "roof_id": face.roof_id,
                    "roof_guid": face.roof_guid,
                    "face_no": face.face_no,
                    "area": round(face.area, 4),
                    "normal_x": round(face.normal[0], 6),
                    "normal_y": round(face.normal[1], 6),
                    "normal_z": round(face.normal[2], 6),
                    "points": json.dumps([[round(v, 4) for v in p] for p in face.points]),
                }
            )
    OUT_PLANES_JSON.write_text(
        json.dumps(
            [
                {
                    "roof_id": f.roof_id,
                    "roof_guid": f.roof_guid,
                    "face_no": f.face_no,
                    "area": f.area,
                    "normal": f.normal,
                    "points": f.points,
                }
                for f in faces
            ],
            indent=2,
        ),
        encoding="utf-8",
    )


def write_guides(guides: list[Guide]):
    with OUT_GUIDES_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "id",
            "role",
            "roof_id",
            "face_no",
            "index",
            "x1",
            "y1",
            "z1",
            "x2",
            "y2",
            "z2",
            "length",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        for i, guide in enumerate(guides, 1):
            writer.writerow(
                {
                    "id": f"BERRA-V15-{i:04d}",
                    "role": guide.role,
                    "roof_id": guide.roof_id,
                    "face_no": guide.face_no,
                    "index": guide.index,
                    "x1": round(guide.p1[0], 4),
                    "y1": round(guide.p1[1], 4),
                    "z1": round(guide.p1[2], 4),
                    "x2": round(guide.p2[0], 4),
                    "y2": round(guide.p2[1], 4),
                    "z2": round(guide.p2[2], 4),
                    "length": round(guide.length, 4),
                }
            )


def write_dxf(faces: list[Face], guides: list[Guide]):
    doc = ezdxf.new("R2010")
    doc.layers.add("BERRA_V15_FALDE_CONTORNI", color=8)
    doc.layers.add("BERRA_V15_ASSITO_TRAVICELLI", color=4)
    doc.layers.add("BERRA_V15_ARCARECCI_CORRENTI", color=3)
    doc.layers.add("BERRA_V15_CAPRIATE_CONTROLLO", color=1)
    msp = doc.modelspace()
    for face in faces:
        pts = list(face.points) + [face.points[0]]
        msp.add_polyline3d(pts, dxfattribs={"layer": "BERRA_V15_FALDE_CONTORNI"})
    layer_by_role = {
        "assito_travicelli_falda": "BERRA_V15_ASSITO_TRAVICELLI",
        "arcarecci_correnti_falda": "BERRA_V15_ARCARECCI_CORRENTI",
        "capriate_linea_controllo": "BERRA_V15_CAPRIATE_CONTROLLO",
    }
    for guide in guides:
        msp.add_polyline3d([guide.p1, guide.p2], dxfattribs={"layer": layer_by_role[guide.role]})
    doc.saveas(OUT_DXF)


def write_svg(faces: list[Face], guides: list[Guide]):
    all_points = [p for f in faces for p in f.points] + [p for g in guides for p in (g.p1, g.p2)]
    min_x = min(p[0] for p in all_points)
    max_x = max(p[0] for p in all_points)
    min_y = min(p[1] for p in all_points)
    max_y = max(p[1] for p in all_points)
    width = 1400
    margin = 40
    span_x = max(max_x - min_x, 1.0)
    span_y = max(max_y - min_y, 1.0)
    scale = (width - margin * 2) / max(span_x, span_y)
    height = int(span_y * scale + margin * 2)

    def xy(p):
        x = margin + (p[0] - min_x) * scale
        y = margin + (max_y - p[1]) * scale
        return x, y

    style = {
        "assito_travicelli_falda": "#00a8c8",
        "arcarecci_correnti_falda": "#2f9e44",
        "capriate_linea_controllo": "#d9480f",
    }
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#f6f4ee"/>',
    ]
    for face in faces:
        points = " ".join(f"{xy(p)[0]:.1f},{xy(p)[1]:.1f}" for p in face.points)
        parts.append(f'<polygon points="{points}" fill="#c77b5a" fill-opacity="0.16" stroke="#6b4f3f" stroke-width="1"/>')
    for guide in guides:
        x1, y1 = xy(guide.p1)
        x2, y2 = xy(guide.p2)
        parts.append(
            f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="{style[guide.role]}" stroke-width="0.8" opacity="0.75"/>'
        )
    parts.append("</svg>")
    OUT_SVG.write_text("\n".join(parts), encoding="utf-8")


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    ifc_status = validate_ifc(SOURCE_IFC)
    if not SOURCE_FACES.exists():
        raise SystemExit(f"File facce non trovato: {SOURCE_FACES}")
    faces = read_faces_from_csv(SOURCE_FACES)
    guides: list[Guide] = []
    for face in faces:
        guides.extend(make_guides_for_face(face))

    write_faces(faces)
    write_guides(guides)
    write_dxf(faces, guides)
    write_svg(faces, guides)

    counts: dict[str, int] = {}
    lengths: dict[str, float] = {}
    for guide in guides:
        counts[guide.role] = counts.get(guide.role, 0) + 1
        lengths[guide.role] = lengths.get(guide.role, 0.0) + guide.length

    lines = [
        "BERRA V15 - PIPELINE FALDE IFC E GUIDE STRUTTURALI",
        "=" * 56,
        f"IFC: {SOURCE_IFC}",
        f"IFC presente: {ifc_status.get('exists')}",
        f"Schema IFC: {ifc_status.get('schema', '')}",
        f"IfcRoof totali: {ifc_status.get('roof_count', 0)}",
        f"IfcRoof BER-BASE-COP: {ifc_status.get('ber_base_cop', 0)}",
        f"CSV facce origine: {SOURCE_FACES}",
        f"Falde filtrate: {len(faces)}",
        f"Guide generate: {len(guides)}",
        "",
        "Quantita guida per ruolo:",
    ]
    for role in sorted(counts):
        lines.append(f"- {role}: {counts[role]} elementi guida, {lengths[role]:.2f} m lineari")
    lines.extend(
        [
            "",
            "Output:",
            f"- {OUT_FACES_CSV}",
            f"- {OUT_GUIDES_CSV}",
            f"- {OUT_DXF}",
            f"- {OUT_SVG}",
            "",
            "Nota operativa:",
            "Questi output NON modificano il modello Archicad. Servono per verificare",
            "le falde correnti e trasformare solo dopo le guide corrette in elementi BIM.",
        ]
    )
    OUT_REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(OUT_REPORT)
    print(f"Falde: {len(faces)}")
    print(f"Guide: {len(guides)}")


if __name__ == "__main__":
    main()
