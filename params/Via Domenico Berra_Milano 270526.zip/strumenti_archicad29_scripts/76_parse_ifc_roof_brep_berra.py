from __future__ import annotations

import csv
import json
import math
import re
import sys
from pathlib import Path


IFC_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(r"E:\strumenti-archicad29\berra_export_falde_correnti.ifc")
OUT_DIR = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(r"E:\strumenti-archicad29")
OUT_PREFIX = sys.argv[3] if len(sys.argv) > 3 else "berra_ifc_roof"
OUT_CSV = OUT_DIR / f"{OUT_PREFIX}_faces.csv"
OUT_SUMMARY = OUT_DIR / f"{OUT_PREFIX}_summary.csv"
OUT_JSON = OUT_DIR / f"{OUT_PREFIX}_faces.json"
OUT_TXT = OUT_DIR / f"{OUT_PREFIX}_report.txt"


def split_args(text: str):
    out = []
    cur = []
    depth = 0
    in_str = False
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "'":
            in_str = not in_str
            cur.append(ch)
        elif not in_str and ch == "(":
            depth += 1
            cur.append(ch)
        elif not in_str and ch == ")":
            depth -= 1
            cur.append(ch)
        elif not in_str and ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    if cur:
        out.append("".join(cur).strip())
    return out


def parse_entity(line: str):
    left, right = line.split("=", 1)
    ident = left.strip()
    m = re.match(r"([A-Z0-9_]+)\((.*)\);?$", right.strip())
    if not m:
        return ident, "", []
    return ident, m.group(1), split_args(m.group(2))


def strip_string(value: str):
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1]
    return value


def refs(value: str):
    return re.findall(r"#\d+", value)


def numbers(value: str):
    return [float(item) for item in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", value)]


def vec_add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def vec_sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def vec_mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def norm(a):
    length = math.sqrt(dot(a, a))
    if length <= 1e-12:
        return (0.0, 0.0, 0.0)
    return (a[0] / length, a[1] / length, a[2] / length)


def mat_identity():
    return (
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    )


def mat_mul(a, b):
    rows = []
    for i in range(4):
        row = []
        for j in range(4):
            row.append(sum(a[i][k] * b[k][j] for k in range(4)))
        rows.append(tuple(row))
    return tuple(rows)


def mat_apply(m, p):
    x, y, z = p
    return (
        m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3],
        m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3],
        m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3],
    )


class IfcIndex:
    def __init__(self, path: Path):
        self.path = path
        self.raw = {}
        self.kind = {}
        self.args = {}
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if not line.startswith("#") or "=" not in line:
                continue
            ident, kind, args = parse_entity(line)
            self.raw[ident] = line.strip()
            self.kind[ident] = kind
            self.args[ident] = args
        self._placement_cache = {}

    def point(self, ident):
        vals = numbers(self.args[ident][0])
        vals = vals + [0.0] * (3 - len(vals))
        return tuple(vals[:3])

    def direction(self, ident):
        vals = numbers(self.args[ident][0])
        vals = vals + [0.0] * (3 - len(vals))
        return norm(tuple(vals[:3]))

    def axis2placement3d(self, ident):
        args = self.args[ident]
        location = self.point(args[0])
        axis = (0.0, 0.0, 1.0)
        ref = (1.0, 0.0, 0.0)
        if len(args) > 1 and args[1].startswith("#"):
            axis = self.direction(args[1])
        if len(args) > 2 and args[2].startswith("#"):
            ref = self.direction(args[2])
        z_axis = norm(axis)
        x_axis = norm(vec_sub(ref, vec_mul(z_axis, dot(ref, z_axis))))
        if dot(x_axis, x_axis) <= 1e-12:
            x_axis = (1.0, 0.0, 0.0)
        y_axis = norm(cross(z_axis, x_axis))
        return (
            (x_axis[0], y_axis[0], z_axis[0], location[0]),
            (x_axis[1], y_axis[1], z_axis[1], location[1]),
            (x_axis[2], y_axis[2], z_axis[2], location[2]),
            (0.0, 0.0, 0.0, 1.0),
        )

    def placement_matrix(self, ident):
        if ident in self._placement_cache:
            return self._placement_cache[ident]
        args = self.args[ident]
        parent = args[0] if args and args[0].startswith("#") else None
        relative = args[1] if len(args) > 1 and args[1].startswith("#") else None
        parent_m = self.placement_matrix(parent) if parent else mat_identity()
        local_m = self.axis2placement3d(relative) if relative else mat_identity()
        result = mat_mul(parent_m, local_m)
        self._placement_cache[ident] = result
        return result

    def product_representation_refs(self, shape_ident):
        refs_out = []
        for rep_ident in refs(self.raw.get(shape_ident, "")):
            if rep_ident == shape_ident:
                continue
            if self.kind.get(rep_ident) == "IFCSHAPEREPRESENTATION":
                refs_out.extend(
                    [r for r in refs(self.raw[rep_ident]) if r != rep_ident and self.kind.get(r) in {"IFCFACETEDBREP"}]
                )
        return refs_out

    def brep_faces(self, brep_ident):
        shell_refs = [r for r in refs(self.raw.get(brep_ident, "")) if r != brep_ident]
        if not shell_refs:
            return []
        shell = shell_refs[-1]
        face_refs = [r for r in refs(self.raw.get(shell, "")) if r != shell and self.kind.get(r) == "IFCFACE"]
        faces = []
        for face_ref in face_refs:
            bound_refs = [
                r
                for r in refs(self.raw.get(face_ref, ""))
                if r != face_ref and self.kind.get(r) in {"IFCFACEOUTERBOUND", "IFCFACEBOUND"}
            ]
            if not bound_refs:
                continue
            loop_refs = [r for r in refs(self.raw.get(bound_refs[0], "")) if self.kind.get(r) == "IFCPOLYLOOP"]
            if not loop_refs:
                continue
            point_refs = [r for r in refs(self.raw.get(loop_refs[0], "")) if self.kind.get(r) == "IFCCARTESIANPOINT"]
            points = [self.point(point_ref) for point_ref in point_refs]
            if len(points) >= 3:
                faces.append(points)
        return faces


def face_normal(points):
    if len(points) < 3:
        return (0.0, 0.0, 0.0)
    base = points[0]
    for i in range(1, len(points) - 1):
        n = cross(vec_sub(points[i], base), vec_sub(points[i + 1], base))
        if dot(n, n) > 1e-9:
            return norm(n)
    return (0.0, 0.0, 0.0)


def bbox(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    zs = [p[2] for p in points]
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    index = IfcIndex(IFC_PATH)
    roof_products = []
    for ident, kind in index.kind.items():
        if kind != "IFCROOF":
            continue
        args = index.args[ident]
        name = strip_string(args[2]) if len(args) > 2 else ""
        if not name.startswith("BER-BASE-COP"):
            continue
        placement = args[5] if len(args) > 5 and args[5].startswith("#") else None
        shape = args[6] if len(args) > 6 and args[6].startswith("#") else None
        guid = strip_string(args[7]) if len(args) > 7 else ""
        roof_products.append((ident, name, guid, placement, shape))

    face_rows = []
    summary_rows = []
    for product_ident, name, guid, placement, shape in roof_products:
        transform = index.placement_matrix(placement) if placement else mat_identity()
        breps = index.product_representation_refs(shape) if shape else []
        all_points = []
        face_no = 0
        for brep in breps:
            for local_face in index.brep_faces(brep):
                world_points_mm = [mat_apply(transform, point) for point in local_face]
                world_points_m = [(p[0] / 1000.0, p[1] / 1000.0, p[2] / 1000.0) for p in world_points_mm]
                all_points.extend(world_points_m)
                n = face_normal(world_points_m)
                x1, x2, y1, y2, z1, z2 = bbox(world_points_m)
                face_no += 1
                face_rows.append(
                    {
                        "roof_id": name,
                        "roof_guid": guid,
                        "ifc_id": product_ident,
                        "face_no": face_no,
                        "point_count": len(world_points_m),
                        "normal_x": round(n[0], 6),
                        "normal_y": round(n[1], 6),
                        "normal_z": round(n[2], 6),
                        "xMin": round(x1, 4),
                        "xMax": round(x2, 4),
                        "yMin": round(y1, 4),
                        "yMax": round(y2, 4),
                        "zMin": round(z1, 4),
                        "zMax": round(z2, 4),
                        "points": json.dumps([[round(v, 4) for v in p] for p in world_points_m]),
                    }
                )
        if all_points:
            x1, x2, y1, y2, z1, z2 = bbox(all_points)
            summary_rows.append(
                {
                    "roof_id": name,
                    "roof_guid": guid,
                    "ifc_id": product_ident,
                    "face_count": face_no,
                    "xMin": round(x1, 4),
                    "xMax": round(x2, 4),
                    "yMin": round(y1, 4),
                    "yMax": round(y2, 4),
                    "zMin": round(z1, 4),
                    "zMax": round(z2, 4),
                }
            )

    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "roof_id",
            "roof_guid",
            "ifc_id",
            "face_no",
            "point_count",
            "normal_x",
            "normal_y",
            "normal_z",
            "xMin",
            "xMax",
            "yMin",
            "yMax",
            "zMin",
            "zMax",
            "points",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(face_rows)
    with OUT_SUMMARY.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["roof_id", "roof_guid", "ifc_id", "face_count", "xMin", "xMax", "yMin", "yMax", "zMin", "zMax"]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(summary_rows)
    OUT_JSON.write_text(json.dumps({"faces": face_rows, "summary": summary_rows}, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - IFC ROOF BREP",
                "=" * 24,
                f"IFC: {IFC_PATH}",
                f"Coperture BER-BASE-COP: {len(roof_products)}",
                f"Coperture con geometria: {len(summary_rows)}",
                f"Facce estratte: {len(face_rows)}",
                f"CSV facce: {OUT_CSV}",
                f"CSV riepilogo: {OUT_SUMMARY}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Coperture: {len(summary_rows)}")
    print(f"Facce: {len(face_rows)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
