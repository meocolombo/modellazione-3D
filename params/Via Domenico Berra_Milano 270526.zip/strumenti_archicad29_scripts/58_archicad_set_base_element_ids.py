from __future__ import annotations

import csv
import sys
from pathlib import Path

from archicad import ACConnection


MAPPING = Path("berra_base_codici_id_mapping.csv")
OUT_TXT = Path("berra_base_set_element_ids_report.txt")


def get_attr(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def prop_nonlocalized_name(prop_name):
    value = get_attr(prop_name, "nonLocalizedName")
    if value:
        return str(value)
    value = get_attr(prop_name, "nonLocalizedPropertyId")
    if value:
        return str(value)
    return ""


def element_guid(element):
    element_id = get_attr(element, "elementId", None)
    guid = get_attr(element_id, "guid", None)
    if guid:
        return str(guid).upper()
    if isinstance(element, dict):
        return str(element.get("elementId", {}).get("guid", "")).upper()
    return ""


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Scrive la proprieta' General_ElementID usando berra_base_codici_id_mapping.csv.")
        print("Uso: py 58_archicad_set_base_element_ids.py APPLICA")
        return

    if not MAPPING.exists():
        raise SystemExit(f"Mapping non trovato: {MAPPING}")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    acc = conn.commands
    types = conn.types

    mapping = {}
    with MAPPING.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            guid = (row.get("guid") or "").strip().upper()
            code = (row.get("codice_id") or "").strip()
            if guid and code:
                mapping[guid] = code

    property_names = acc.GetAllPropertyNames()
    property_ids = acc.GetPropertyIds(property_names)
    target_prop_id = None
    names_seen = []
    for prop_name, prop_id in zip(property_names, property_ids):
        nonlocalized = prop_nonlocalized_name(prop_name)
        if nonlocalized:
            names_seen.append(nonlocalized)
        if nonlocalized == "General_ElementID":
            target_prop_id = get_attr(prop_id, "propertyId", prop_id)
            break
    if target_prop_id is None:
        OUT_TXT.write_text(
            "Proprieta' BuiltIn General_ElementID non trovata.\n"
            + "Prime proprieta':\n"
            + "\n".join(names_seen[:80]),
            encoding="utf-8",
        )
        raise SystemExit("Proprieta BuiltIn General_ElementID non trovata.")

    elements = acc.GetAllElements()
    changes = []
    matched = 0
    for element in elements:
        guid = element_guid(element)
        code = mapping.get(guid)
        if not code:
            continue
        matched += 1
        changes.append(types.ElementPropertyValue(element.elementId, target_prop_id, types.NormalStringPropertyValue(code)))

    if not changes:
        OUT_TXT.write_text("Nessun elemento del mapping trovato nel modello aperto.", encoding="utf-8")
        print("Nessun elemento del mapping trovato nel modello aperto.")
        return

    results = acc.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = []
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed.append(text)

    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA BASE - SCRITTURA GENERAL_ELEMENTID",
                "=" * 42,
                f"Mapping letti: {len(mapping)}",
                f"Elementi trovati nel modello: {matched}",
                f"Modifiche richieste: {len(changes)}",
                f"Risultati OK apparenti: {ok}",
                f"Risultati falliti: {len(failed)}",
                "",
                "Primi errori:",
                *failed[:20],
            ]
        ),
        encoding="utf-8",
    )
    print(f"Mapping letti: {len(mapping)}")
    print(f"Elementi trovati: {matched}")
    print(f"OK apparenti: {ok}")
    print(f"Falliti: {len(failed)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
