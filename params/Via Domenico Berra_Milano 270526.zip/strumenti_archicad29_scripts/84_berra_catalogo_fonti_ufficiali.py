from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps


BASE = Path(r"E:\Project_berra_Prova 04 100626\CARTELLA BERRA_100626\COSTRUZIONE_100625")
OUT_DIR = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526\output_berra_v03_falde_ifc_pipeline")
OUT_CSV = OUT_DIR / "inventario_UFFICIALE_E_costruzione_100625.csv"
OUT_MD = OUT_DIR / "catalogo_fonti_ufficiali_berra.md"
SHEETS_DIR = OUT_DIR / "contact_sheets_fonti_ufficiali"


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}
VIDEO_EXTS = {".mov", ".mp4", ".avi"}
MODEL_EXTS = {".ifc", ".3ds", ".obj", ".mtl", ".kmz", ".pln", ".bpn"}

KEY_FOLDERS = [
    ("planimetrie", BASE / "02_PLANIMETRIE"),
    ("planimetrie_dettaglio", BASE / "04_fOTO" / "PLANIMETRIE DETTAGLIO"),
    ("capriate_travi", BASE / "03_SEZIONI DETTAGLI" / "CAPRIATE TRAVI"),
    ("facciata_strada", BASE / "04_fOTO" / "FACCIATA SU STRADA 01"),
    ("primo_portico", BASE / "04_fOTO" / "PRIMO PORTICO"),
    ("secondo_portico_giardino", BASE / "04_fOTO" / "SECONDO PORTICO CON GIARDINO"),
    ("tetti", BASE / "04_fOTO" / "TETTI"),
    ("giardino", BASE / "04_fOTO" / "VARIE GIARDINO 02"),
]


def safe_rel(path: Path) -> str:
    try:
        return str(path.relative_to(BASE))
    except ValueError:
        return str(path)


def inventory_files():
    rows = []
    for path in sorted(BASE.rglob("*")):
        if not path.is_file():
            continue
        rows.append(
            {
                "full_path": str(path),
                "relative_path": safe_rel(path),
                "directory": safe_rel(path.parent),
                "name": path.name,
                "extension": path.suffix.lower(),
                "length": path.stat().st_size,
                "last_write_time": path.stat().st_mtime,
            }
        )
    return rows


def write_inventory(rows):
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["full_path", "relative_path", "directory", "name", "extension", "length", "last_write_time"],
            delimiter=";",
        )
        writer.writeheader()
        writer.writerows(rows)


def thumb(path: Path, size=(220, 165)):
    image = Image.open(path)
    image = ImageOps.exif_transpose(image)
    image.thumbnail(size, Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", size, "white")
    x = (size[0] - image.width) // 2
    y = (size[1] - image.height) // 2
    canvas.paste(image.convert("RGB"), (x, y))
    return canvas


def make_contact_sheet(label: str, folder: Path, max_images=48):
    images = [p for p in sorted(folder.rglob("*")) if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    if not images:
        return None, 0
    SHEETS_DIR.mkdir(parents=True, exist_ok=True)
    shown = images[:max_images]
    cell_w, cell_h = 240, 215
    cols = 4
    rows = (len(shown) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell_w, rows * cell_h + 38), "#f4f1e8")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    draw.text((12, 12), label, fill="#241f1a", font=font)
    for idx, path in enumerate(shown):
        col = idx % cols
        row = idx // cols
        x = col * cell_w + 10
        y = row * cell_h + 42
        try:
            image = thumb(path)
            sheet.paste(image, (x, y))
        except Exception:
            draw.rectangle([x, y, x + 220, y + 165], outline="red")
            draw.text((x + 8, y + 70), "errore immagine", fill="red", font=font)
        name = path.name[:34]
        draw.text((x, y + 170), name, fill="#241f1a", font=font)
    out = SHEETS_DIR / f"{label}.jpg"
    sheet.save(out, quality=88)
    return out, len(images)


def write_markdown(rows, sheets):
    by_ext = defaultdict(int)
    by_dir = defaultdict(int)
    for row in rows:
        by_ext[row["extension"]] += 1
        by_dir[row["directory"]] += 1

    technical = [
        row
        for row in rows
        if row["extension"] in {".pdf", ".bmp", ".png"}
        or any(token in row["name"].casefold() for token in ["plan", "sezion", "capri", "travi", "tetto", "catast", "portico"])
    ]
    photos = [row for row in rows if row["extension"] in IMAGE_EXTS]
    models = [row for row in rows if row["extension"] in MODEL_EXTS]
    videos = [row for row in rows if row["extension"] in VIDEO_EXTS]

    lines = [
        "# Berra - catalogo fonti ufficiali E",
        "",
        f"Cartella fonte: `{BASE}`",
        "",
        "## Regola di lavoro",
        "",
        "Questa cartella E e la fonte ufficiale per planimetrie, sezioni, dettagli, foto, texture e modello esistente.",
        "La cartella Z va trattata solo come copia di appoggio o riscontro.",
        "",
        "## Riepilogo",
        "",
        f"- File totali: {len(rows)}",
        f"- Immagini/foto: {len(photos)}",
        f"- PDF/tecnici selezionati: {len(technical)}",
        f"- Modelli/export: {len(models)}",
        f"- Video: {len(videos)}",
        "",
        "## Estensioni",
        "",
    ]
    for ext, count in sorted(by_ext.items(), key=lambda item: (-item[1], item[0])):
        lines.append(f"- `{ext or '[senza estensione]'}`: {count}")

    lines.extend(["", "## Contact sheet", ""])
    for label, path, count in sheets:
        rel = path.relative_to(OUT_DIR)
        lines.append(f"- {label}: {count} immagini -> [{rel.as_posix()}]({rel.as_posix()})")

    lines.extend(["", "## Fonti tecniche da usare prima di modellare", ""])
    for row in technical:
        lines.append(f"- `{row['relative_path']}`")

    lines.extend(["", "## Modelli/export disponibili", ""])
    for row in models:
        lines.append(f"- `{row['relative_path']}`")

    lines.extend(["", "## Cartelle foto principali", ""])
    for directory, count in sorted(by_dir.items(), key=lambda item: (-item[1], item[0])):
        if "04_fOTO" in directory or "CAPRIATE TRAVI" in directory or "02_PLANIMETRIE" in directory:
            lines.append(f"- `{directory}`: {count} file")

    lines.extend(
        [
            "",
            "## Checklist BIM derivata dalle fonti",
            "",
            "- Planimetrie corrette: verificare piano terreno, primo piano, piano sottotetto e cantine.",
            "- Portici/loggiati: usare foto PRIMO PORTICO e SECONDO PORTICO CON GIARDINO.",
            "- Struttura tetto: usare CAPRIATE TRAVI, TETTI e sezioni/dettagli PDF.",
            "- Facciata su strada: usare FACCIATA SU STRADA 01 per finestre, contorni, portale, modanature, gronde e pluviali.",
            "- Giardino/corti: usare VARIE GIARDINO 02 e planimetrie dettaglio.",
            "- Texture: ricavare materiali da foto locali prima di cercare riferimenti web generici.",
        ]
    )
    OUT_MD.write_text("\n".join(lines), encoding="utf-8")


def main():
    rows = inventory_files()
    write_inventory(rows)
    sheets = []
    for label, folder in KEY_FOLDERS:
        if not folder.exists():
            continue
        path, count = make_contact_sheet(label, folder)
        if path:
            sheets.append((label, path, count))
    write_markdown(rows, sheets)
    print(OUT_MD)
    print(f"File inventariati: {len(rows)}")
    print(f"Contact sheets: {len(sheets)}")


if __name__ == "__main__":
    main()
