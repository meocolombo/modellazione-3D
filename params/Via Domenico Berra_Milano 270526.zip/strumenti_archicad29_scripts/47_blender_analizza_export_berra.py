from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import bpy
from mathutils import Vector


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()


def import_model(path: Path):
    suffix = path.suffix.lower()
    if suffix == ".dae":
        bpy.ops.wm.collada_import(filepath=str(path))
    elif suffix == ".obj":
        bpy.ops.wm.obj_import(filepath=str(path))
    elif suffix == ".3ds":
        # Blender 4.x may not ship a 3DS importer in every installation.
        bpy.ops.import_scene.autodesk_3ds(filepath=str(path))
    else:
        raise ValueError(f"Formato non gestito: {path}")


def world_bbox(obj):
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    xs = [c.x for c in corners]
    ys = [c.y for c in corners]
    zs = [c.z for c in corners]
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)


def mesh_stats(obj):
    if obj.type != "MESH":
        return {"vertices": 0, "polygons": 0}
    return {"vertices": len(obj.data.vertices), "polygons": len(obj.data.polygons)}


def material_names(obj):
    if not hasattr(obj.data, "materials"):
        return []
    return [mat.name for mat in obj.data.materials if mat]


def classify(obj, bbox):
    mats = " ".join(material_names(obj)).casefold()
    name = obj.name.casefold()
    zmin, zmax = bbox[4], bbox[5]
    height = zmax - zmin
    if "tegola" in mats or "roof" in name or "tetto" in mats or "copertura" in mats:
        return "copertura"
    if "vetro" in mats or "glass" in mats:
        return "vetro"
    if "shell" in mats:
        return "shell"
    if zmax > 5.0 and height < 1.5:
        return "copertura_probabile"
    if height > 3.0:
        return "muro/facciata"
    if zmax < 0.8:
        return "suolo/solaio"
    return "altro"


def rects_svg(rows, out_svg):
    draw = [row for row in rows if row["xMax"] > row["xMin"] and row["yMax"] > row["yMin"]]
    if not draw:
        return
    x_min = min(row["xMin"] for row in draw)
    x_max = max(row["xMax"] for row in draw)
    y_min = min(row["yMin"] for row in draw)
    y_max = max(row["yMax"] for row in draw)
    width, height, pad = 1500, 950, 40
    scale = min((width - pad * 2) / (x_max - x_min), (height - pad * 2) / (y_max - y_min))

    def sx(x):
        return pad + (x - x_min) * scale

    def sy(y):
        return height - pad - (y - y_min) * scale

    colors = {
        "copertura": "#a8573a",
        "copertura_probabile": "#c1784b",
        "muro/facciata": "#8a8178",
        "suolo/solaio": "#687d52",
        "vetro": "#5082a8",
        "shell": "#b07a53",
        "altro": "#777777",
    }
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#f5f2ea"/>',
        '<text x="40" y="28" font-family="Arial" font-size="18" fill="#26231f">Export Archicad V02 - lettura top-down da KMZ/DAE</text>',
    ]
    for row in sorted(draw, key=lambda r: (r["class"], r["zMax"])):
        col = colors.get(row["class"], "#777")
        x = sx(row["xMin"])
        y = sy(row["yMax"])
        w = max(0.75, (row["xMax"] - row["xMin"]) * scale)
        h = max(0.75, (row["yMax"] - row["yMin"]) * scale)
        opacity = 0.46 if "copertura" in row["class"] else 0.22
        parts.append(f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" fill="{col}" fill-opacity="{opacity}" stroke="#26231f" stroke-width="0.25"/>')
    lx, ly = 40, height - 160
    for idx, (label, col) in enumerate(colors.items()):
        yy = ly + idx * 20
        parts.append(f'<rect x="{lx}" y="{yy}" width="13" height="13" fill="{col}" fill-opacity="0.60"/>')
        parts.append(f'<text x="{lx + 20}" y="{yy + 11}" font-family="Arial" font-size="12" fill="#26231f">{label}</text>')
    parts.append("</svg>")
    out_svg.write_text("\n".join(parts), encoding="utf-8")


def detect_courts(rows):
    # Heuristic: corti come grandi vuoti rettangolari interni non coperti, ricavate
    # dalla distribuzione dei bounding box a terra/coperture. Serve per report,
    # non modifica il modello.
    roof_like = [r for r in rows if "copertura" in r["class"]]
    if not roof_like:
        return []
    x_min = min(r["xMin"] for r in roof_like)
    x_max = max(r["xMax"] for r in roof_like)
    y_min = min(r["yMin"] for r in roof_like)
    y_max = max(r["yMax"] for r in roof_like)
    nx, ny = 80, 120
    grid = [[False for _ in range(ny)] for _ in range(nx)]
    for r in roof_like:
        ix1 = max(0, min(nx - 1, int((r["xMin"] - x_min) / (x_max - x_min) * nx)))
        ix2 = max(0, min(nx - 1, int((r["xMax"] - x_min) / (x_max - x_min) * nx)))
        iy1 = max(0, min(ny - 1, int((r["yMin"] - y_min) / (y_max - y_min) * ny)))
        iy2 = max(0, min(ny - 1, int((r["yMax"] - y_min) / (y_max - y_min) * ny)))
        for ix in range(ix1, ix2 + 1):
            for iy in range(iy1, iy2 + 1):
                grid[ix][iy] = True

    seen = set()
    components = []
    for ix in range(1, nx - 1):
        for iy in range(1, ny - 1):
            if grid[ix][iy] or (ix, iy) in seen:
                continue
            stack = [(ix, iy)]
            seen.add((ix, iy))
            cells = []
            touches_boundary = False
            while stack:
                cx, cy = stack.pop()
                cells.append((cx, cy))
                if cx in (0, nx - 1) or cy in (0, ny - 1):
                    touches_boundary = True
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nb = (cx + dx, cy + dy)
                    if nb in seen:
                        continue
                    if nb[0] < 0 or nb[0] >= nx or nb[1] < 0 or nb[1] >= ny:
                        continue
                    if grid[nb[0]][nb[1]]:
                        continue
                    seen.add(nb)
                    stack.append(nb)
            if touches_boundary or len(cells) < 20:
                continue
            min_ix, max_ix = min(c[0] for c in cells), max(c[0] for c in cells)
            min_iy, max_iy = min(c[1] for c in cells), max(c[1] for c in cells)
            components.append(
                {
                    "cells": len(cells),
                    "xMin": x_min + min_ix / nx * (x_max - x_min),
                    "xMax": x_min + (max_ix + 1) / nx * (x_max - x_min),
                    "yMin": y_min + min_iy / ny * (y_max - y_min),
                    "yMax": y_min + (max_iy + 1) / ny * (y_max - y_min),
                }
            )
    return sorted(components, key=lambda c: c["cells"], reverse=True)[:8]


def main():
    if len(sys.argv) < 3:
        print("Uso: blender --background --python 47_blender_analizza_export_berra.py -- <model.dae|model.3ds> <out_dir>")
        return
    model_path = Path(sys.argv[-2])
    out_dir = Path(sys.argv[-1])
    out_dir.mkdir(parents=True, exist_ok=True)
    clear_scene()
    import_model(model_path)

    rows = []
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH":
            continue
        bbox = world_bbox(obj)
        stats = mesh_stats(obj)
        item = {
            "name": obj.name,
            "type": obj.type,
            "class": classify(obj, bbox),
            "materials": ", ".join(material_names(obj)),
            "xMin": bbox[0],
            "xMax": bbox[1],
            "yMin": bbox[2],
            "yMax": bbox[3],
            "zMin": bbox[4],
            "zMax": bbox[5],
            "vertices": stats["vertices"],
            "polygons": stats["polygons"],
        }
        rows.append(item)

    csv_path = out_dir / f"{model_path.stem}_blender_objects.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()) if rows else ["name"])
        writer.writeheader()
        writer.writerows(rows)

    ext = {
        "xMin": min((r["xMin"] for r in rows), default=0.0),
        "xMax": max((r["xMax"] for r in rows), default=0.0),
        "yMin": min((r["yMin"] for r in rows), default=0.0),
        "yMax": max((r["yMax"] for r in rows), default=0.0),
        "zMin": min((r["zMin"] for r in rows), default=0.0),
        "zMax": max((r["zMax"] for r in rows), default=0.0),
    }
    counts = Counter(r["class"] for r in rows)
    material_counts = Counter()
    for row in rows:
        for mat in [m.strip() for m in row["materials"].split(",") if m.strip()]:
            material_counts[mat] += 1
    courts = detect_courts(rows)

    summary = {
        "source": str(model_path),
        "objects": len(rows),
        "classes": dict(counts),
        "extents": ext,
        "topMaterials": dict(material_counts.most_common(20)),
        "detectedCourtsHeuristic": courts,
    }
    json_path = out_dir / f"{model_path.stem}_blender_summary.json"
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    txt_path = out_dir / f"{model_path.stem}_blender_summary.txt"
    txt_path.write_text(
        "\n".join(
            [
                f"Sorgente: {model_path}",
                f"Oggetti mesh: {len(rows)}",
                "Classi:",
                *(f"- {name}: {count}" for name, count in counts.most_common()),
                "Estensione:",
                *(f"- {key}: {value:.3f}" for key, value in ext.items()),
                "Materiali principali:",
                *(f"- {name}: {count}" for name, count in material_counts.most_common(20)),
                "Corti/vuoti interni euristici:",
                *(f"- X {c['xMin']:.2f}..{c['xMax']:.2f}, Y {c['yMin']:.2f}..{c['yMax']:.2f}, celle {c['cells']}" for c in courts),
            ]
        ),
        encoding="utf-8",
    )
    rects_svg(rows, out_dir / f"{model_path.stem}_topdown_bbox.svg")
    print(f"Creato: {csv_path}")
    print(f"Creato: {json_path}")
    print(f"Creato: {txt_path}")


if __name__ == "__main__":
    main()
