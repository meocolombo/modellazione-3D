from __future__ import annotations

import ast
import csv
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
BASE = Path(r"E:\Project_berra_Prova 04 100626\CARTELLA BERRA_100626\COSTRUZIONE_100625")
PIPELINE = ROOT / "output_berra_v17_ufficiale_pipeline"

FACES_CSV = PIPELINE / "berra_v17_ufficiale_ifc_roof_faces.csv"
PLAN_CAPRIATE = BASE / r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\PLANIMETRIA CAPRIATE.jpg"

OUT_TEMPLATE = PIPELINE / "berra_v17_punti_omologhi_template.csv"
OUT_REPORT = PIPELINE / "berra_v17_overlay_capriate_ifc_report.md"


# Crop operativo stimato sul raster ufficiale PLANIMETRIA CAPRIATE.
# Non e una registrazione finale: serve a produrre overlay candidati per scelta visiva.
# Coordinate in pixel del file originale 2481 x 3508.
ROUGH_CROP = {
    "x0": 680,
    "y0": 680,
    "x1": 1785,
    "y1": 3355,
}


def parse_points(value: str) -> list[tuple[float, float, float]]:
    data = ast.literal_eval(value)
    return [(float(x), float(y), float(z)) for x, y, z in data]


def read_faces() -> list[dict[str, object]]:
    faces: list[dict[str, object]] = []
    with FACES_CSV.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        for row in reader:
            points = parse_points(row["points"])
            area = row.get("area")
            if not area:
                area_value = polygon_area_xy(points)
            else:
                area_value = float(area)
            faces.append(
                {
                    "roof_id": row["roof_id"],
                    "face_no": int(row["face_no"]),
                    "area": area_value,
                    "points": points,
                }
            )
    return faces


def polygon_area_xy(points: list[tuple[float, float, float]]) -> float:
    if len(points) < 3:
        return 0.0
    area = 0.0
    for idx, (x0, y0, _) in enumerate(points):
        x1, y1, _ = points[(idx + 1) % len(points)]
        area += x0 * y1 - x1 * y0
    return abs(area) * 0.5


def model_bbox(faces: list[dict[str, object]]) -> dict[str, float]:
    xs: list[float] = []
    ys: list[float] = []
    zs: list[float] = []
    for face in faces:
        for x, y, z in face["points"]:  # type: ignore[index]
            xs.append(x)
            ys.append(y)
            zs.append(z)
    return {
        "min_x": min(xs),
        "max_x": max(xs),
        "min_y": min(ys),
        "max_y": max(ys),
        "min_z": min(zs),
        "max_z": max(zs),
    }


def map_point(
    x: float,
    y: float,
    bbox: dict[str, float],
    crop: dict[str, int],
    *,
    flip_x: bool,
    invert_y: bool,
) -> tuple[float, float]:
    w = crop["x1"] - crop["x0"]
    h = crop["y1"] - crop["y0"]
    nx = (x - bbox["min_x"]) / (bbox["max_x"] - bbox["min_x"])
    ny = (y - bbox["min_y"]) / (bbox["max_y"] - bbox["min_y"])
    if flip_x:
        nx = 1.0 - nx
    if invert_y:
        ny = 1.0 - ny
    return crop["x0"] + nx * w, crop["y0"] + ny * h


def draw_overlay(
    image: Image.Image,
    faces: list[dict[str, object]],
    bbox: dict[str, float],
    name: str,
    *,
    flip_x: bool,
    invert_y: bool,
) -> Path:
    canvas = image.convert("RGBA")
    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    crop = ROUGH_CROP
    draw.rectangle([crop["x0"], crop["y0"], crop["x1"], crop["y1"]], outline=(255, 0, 0, 220), width=8)

    for face in faces:
        pts = face["points"]  # type: ignore[index]
        poly = [map_point(x, y, bbox, crop, flip_x=flip_x, invert_y=invert_y) for x, y, _ in pts]
        area = float(face["area"])
        width = 2 if area < 45 else 4
        draw.line(poly + [poly[0]], fill=(0, 125, 255, 210), width=width)

    # Mark model bbox corners, useful for reading orientation.
    corners = [
        (bbox["min_x"], bbox["min_y"], "minX/minY"),
        (bbox["max_x"], bbox["min_y"], "maxX/minY"),
        (bbox["max_x"], bbox["max_y"], "maxX/maxY"),
        (bbox["min_x"], bbox["max_y"], "minX/maxY"),
    ]
    for x, y, label in corners:
        px, py = map_point(x, y, bbox, crop, flip_x=flip_x, invert_y=invert_y)
        draw.ellipse([px - 10, py - 10, px + 10, py + 10], fill=(255, 140, 0, 230))
        draw.text((px + 14, py - 12), label, fill=(255, 140, 0, 255))

    composed = Image.alpha_composite(canvas, overlay).convert("RGB")
    composed.thumbnail((1200, 1700), Image.Resampling.LANCZOS)
    out = PIPELINE / f"berra_v17_overlay_capriate_ifc_{name}.jpg"
    composed.save(out, quality=92)
    return out


def write_template() -> None:
    rows = [
        {
            "point_id": "P01",
            "descrizione": "spigolo riconoscibile alto/sinistra del corpo costruito",
            "raster_x_px": "",
            "raster_y_px": "",
            "model_x_m": "",
            "model_y_m": "",
            "note": "da compilare dopo scelta overlay",
        },
        {
            "point_id": "P02",
            "descrizione": "spigolo alto/destra su via Domenico Berra",
            "raster_x_px": "",
            "raster_y_px": "",
            "model_x_m": "",
            "model_y_m": "",
            "note": "da compilare dopo scelta overlay",
        },
        {
            "point_id": "P03",
            "descrizione": "angolo corte interna superiore",
            "raster_x_px": "",
            "raster_y_px": "",
            "model_x_m": "",
            "model_y_m": "",
            "note": "da compilare dopo scelta overlay",
        },
        {
            "point_id": "P04",
            "descrizione": "angolo corte interna inferiore",
            "raster_x_px": "",
            "raster_y_px": "",
            "model_x_m": "",
            "model_y_m": "",
            "note": "da compilare dopo scelta overlay",
        },
    ]
    with OUT_TEMPLATE.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    PIPELINE.mkdir(parents=True, exist_ok=True)
    faces = read_faces()
    bbox = model_bbox(faces)
    image = ImageOps.exif_transpose(Image.open(PLAN_CAPRIATE))

    outputs = [
        draw_overlay(image, faces, bbox, "A_x_norm_y_invert", flip_x=False, invert_y=True),
        draw_overlay(image, faces, bbox, "B_x_norm_y_norm", flip_x=False, invert_y=False),
        draw_overlay(image, faces, bbox, "C_x_flip_y_invert", flip_x=True, invert_y=True),
        draw_overlay(image, faces, bbox, "D_x_flip_y_norm", flip_x=True, invert_y=False),
    ]
    write_template()

    lines = [
        "# Berra V17 - overlay planimetria capriate / falde IFC",
        "",
        "Questa passata non modifica Archicad.",
        "",
        "## Scopo",
        "",
        "Produrre quattro overlay candidati tra la planimetria ufficiale delle capriate e le falde V03 IFC.",
        "La variante che coincide meglio va usata per compilare i punti omologhi e generare una trasformazione affine controllata.",
        "",
        "## Crop operativo",
        "",
        f"- x0={ROUGH_CROP['x0']}, y0={ROUGH_CROP['y0']}, x1={ROUGH_CROP['x1']}, y1={ROUGH_CROP['y1']}",
        "",
        "## Output",
        "",
    ]
    for out in outputs:
        lines.append(f"- `{out.name}`")
    lines.append(f"- `{OUT_TEMPLATE.name}`")
    lines.extend(
        [
            "",
            "## Prossimo passo",
            "",
            "Scegliere l'overlay piu coerente, poi compilare almeno quattro punti omologhi.",
            "Solo dopo si generano assi capriate/travi da importare in Archicad.",
        ]
    )
    OUT_REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Creato: {OUT_REPORT}")
    for out in outputs:
        print(f"Overlay: {out}")
    print(f"Template: {OUT_TEMPLATE}")


if __name__ == "__main__":
    main()
