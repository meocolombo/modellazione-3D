from __future__ import annotations

import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()


def material(name, color):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = color
    return mat


def assign(obj, mat):
    obj.data.materials.append(mat)
    return obj


def cube(name, loc, scale, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    assign(obj, mat)
    return obj


def cylinder(name, loc, radius, depth, mat, vertices=32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    obj = bpy.context.object
    obj.name = name
    assign(obj, mat)
    return obj


def beam_between(name, p1, p2, thickness, mat):
    v1 = Vector(p1)
    v2 = Vector(p2)
    delta = v2 - v1
    length = delta.length
    if length <= 0.001:
        return None
    mid = (v1 + v2) / 2.0
    bpy.ops.mesh.primitive_cube_add(size=1, location=mid)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = (thickness, thickness, length)
    obj.rotation_euler = delta.to_track_quat("Z", "Y").to_euler()
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    assign(obj, mat)
    return obj


def new_collection(name):
    col = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(col)
    return col


def move_to_collection(obj, col):
    for old in obj.users_collection:
        old.objects.unlink(obj)
    col.objects.link(obj)


def selected_export(col, path):
    bpy.ops.object.select_all(action="DESELECT")
    for obj in col.objects:
        obj.select_set(True)
    if col.objects:
        bpy.context.view_layer.objects.active = col.objects[0]
    try:
        bpy.ops.wm.obj_export(filepath=str(path.with_suffix(".obj")), export_selected_objects=True)
    except Exception as exc:
        print(f"OBJ non esportato per {col.name}: {exc}")
    try:
        bpy.ops.wm.collada_export(filepath=str(path.with_suffix(".dae")), selected=True)
    except Exception as exc:
        print(f"DAE non esportato per {col.name}: {exc}")


def make_truss(mat_wood, mat_metal):
    col = new_collection("BER_V03_capriata_modulo")
    objs = []
    points = [(-2.50, 0, 0), (0, 0, 1.15), (2.50, 0, 0)]
    for i, (a, b) in enumerate(((points[0], points[1]), (points[1], points[2]), (points[0], points[2])), start=1):
        objs.append(beam_between(f"capriata_corrente_{i:02d}", a, b, 0.12, mat_wood))
    for x in (-1.65, -0.85, 0.0, 0.85, 1.65):
        top_z = 1.15 * (1 - abs(x) / 2.50)
        objs.append(beam_between(f"capriata_montante_{x:.2f}", (x, 0, 0.0), (x, 0, top_z), 0.08, mat_wood))
    for i, (a, b) in enumerate(((-1.65, -0.85), (-0.85, 0.0), (0.0, 0.85), (0.85, 1.65)), start=1):
        za = 1.15 * (1 - abs(a) / 2.50)
        zb = 1.15 * (1 - abs(b) / 2.50)
        objs.append(beam_between(f"capriata_diagonale_{i:02d}", (a, 0, 0.03), (b, 0, zb - 0.05), 0.07, mat_wood))
    objs.append(cube("capriata_piastra_sinistra", (-2.55, 0, -0.06), (0.34, 0.18, 0.05), mat_metal))
    objs.append(cube("capriata_piastra_destra", (2.55, 0, -0.06), (0.34, 0.18, 0.05), mat_metal))
    for obj in filter(None, objs):
        move_to_collection(obj, col)
    return col


def make_arch_portal(mat_stone):
    col = new_collection("BER_V03_portale_arco")
    objs = [
        cube("portale_piedritto_sx", (-1.15, 0, 1.10), (0.34, 0.42, 2.20), mat_stone),
        cube("portale_piedritto_dx", (1.15, 0, 1.10), (0.34, 0.42, 2.20), mat_stone),
        cube("portale_soglia", (0, 0, 0.05), (2.75, 0.50, 0.10), mat_stone),
    ]
    radius = 1.15
    for i in range(9):
        angle = math.radians(180 - i * 180 / 8)
        x = math.cos(angle) * radius
        z = 2.15 + math.sin(angle) * 0.75
        obj = cube(f"portale_concio_{i+1:02d}", (x, 0, z), (0.28, 0.44, 0.20), mat_stone)
        obj.rotation_euler[1] = -angle
        objs.append(obj)
    for obj in objs:
        move_to_collection(obj, col)
    return col


def make_chimney(mat_brick, mat_stone):
    col = new_collection("BER_V03_camino")
    objs = [
        cube("camino_fusto", (0, 0, 0.55), (0.42, 0.42, 1.10), mat_brick),
        cube("camino_cappello", (0, 0, 1.18), (0.62, 0.62, 0.14), mat_stone),
        cube("camino_comignolo_sx", (-0.10, 0, 1.34), (0.12, 0.12, 0.22), mat_brick),
        cube("camino_comignolo_dx", (0.10, 0, 1.34), (0.12, 0.12, 0.22), mat_brick),
    ]
    for obj in objs:
        move_to_collection(obj, col)
    return col


def make_well(mat_stone, mat_metal):
    col = new_collection("BER_V03_pozzo")
    objs = [
        cylinder("pozzo_base", (0, 0, 0.10), 0.58, 0.20, mat_stone, 40),
        cylinder("pozzo_anello", (0, 0, 0.55), 0.46, 0.68, mat_stone, 40),
        beam_between("pozzo_montante_sx", (-0.46, 0, 0.85), (-0.46, 0, 1.55), 0.07, mat_metal),
        beam_between("pozzo_montante_dx", (0.46, 0, 0.85), (0.46, 0, 1.55), 0.07, mat_metal),
        beam_between("pozzo_traverso", (-0.55, 0, 1.55), (0.55, 0, 1.55), 0.07, mat_metal),
    ]
    for obj in filter(None, objs):
        move_to_collection(obj, col)
    return col


def make_bench(mat_wood, mat_metal):
    col = new_collection("BER_V03_panchina")
    objs = [
        cube("panchina_seduta", (0, 0, 0.45), (1.80, 0.36, 0.10), mat_wood),
        cube("panchina_schienale", (0, -0.20, 0.82), (1.80, 0.10, 0.55), mat_wood),
        cube("panchina_piede_sx", (-0.65, 0.03, 0.22), (0.10, 0.42, 0.42), mat_metal),
        cube("panchina_piede_dx", (0.65, 0.03, 0.22), (0.10, 0.42, 0.42), mat_metal),
    ]
    for obj in objs:
        move_to_collection(obj, col)
    return col


def make_railing(mat_metal):
    col = new_collection("BER_V03_ringhiera_ballatoio")
    objs = []
    for i, x in enumerate([v * 0.45 for v in range(-5, 6)], start=1):
        objs.append(cube(f"ringhiera_montante_{i:02d}", (x, 0, 0.55), (0.045, 0.045, 1.10), mat_metal))
    objs.extend([
        beam_between("ringhiera_corrimano", (-2.35, 0, 1.12), (2.35, 0, 1.12), 0.055, mat_metal),
        beam_between("ringhiera_traverso", (-2.35, 0, 0.60), (2.35, 0, 0.60), 0.045, mat_metal),
        cube("ballatoio_lastra", (0, 0.18, 0.03), (5.00, 0.86, 0.06), mat_metal),
    ])
    for obj in filter(None, objs):
        move_to_collection(obj, col)
    return col


def main():
    out_dir = Path(sys.argv[-1]) if len(sys.argv) > 1 and not sys.argv[-1].endswith(".py") else Path("output_berra_blender_parts")
    out_dir.mkdir(parents=True, exist_ok=True)
    clear_scene()

    mat_wood = material("legno_rovere_scuro", (0.43, 0.25, 0.13, 1.0))
    mat_brick = material("laterizio_cotto", (0.66, 0.28, 0.18, 1.0))
    mat_stone = material("pietra_chiara", (0.70, 0.66, 0.57, 1.0))
    mat_metal = material("ferro_scuro", (0.08, 0.08, 0.075, 1.0))

    collections = [
        make_truss(mat_wood, mat_metal),
        make_arch_portal(mat_stone),
        make_chimney(mat_brick, mat_stone),
        make_well(mat_stone, mat_metal),
        make_bench(mat_wood, mat_metal),
        make_railing(mat_metal),
    ]

    blend_path = out_dir / "BER_V03_libreria_asset_blender.blend"
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    for col in collections:
        selected_export(col, out_dir / col.name)

    manifest = out_dir / "README_asset_blender_berra.txt"
    manifest.write_text(
        "\n".join(
            [
                "Asset Blender modulari per Via Berra V03",
                "=" * 42,
                "File principale: BER_V03_libreria_asset_blender.blend",
                "Esportazioni: OBJ e DAE per ogni collezione, se il formato e' disponibile in Blender.",
                "",
                "Asset:",
                "- BER_V03_capriata_modulo: modulo capriata lignea",
                "- BER_V03_portale_arco: portale con piedritti e conci",
                "- BER_V03_camino: camino/copertura",
                "- BER_V03_pozzo: pozzo da corte",
                "- BER_V03_panchina: seduta esterna",
                "- BER_V03_ringhiera_ballatoio: ringhiera/ballatoio modulare",
                "",
                "Uso consigliato: importare gli OBJ/DAE in Archicad come oggetti o usarli come riferimento per oggetti GSM/locali. Nel PLN V03 gli elementi computabili restano creati con Tapir come travi, solai e morph.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Creato: {blend_path}")
    print(f"Cartella asset: {out_dir}")


if __name__ == "__main__":
    main()
