from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_V08_FINESTRE_EDICOLE"
OUT_JSON = Path("berra_v08_finestre_edicole_result.json")
OUT_CSV = Path("berra_v08_finestre_edicole_elementi.csv")
OUT_TXT = Path("berra_v08_finestre_edicole_report.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 171,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_model_rows(commands, types):
    layer_names = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        typ = detail.get("type", "")
        if typ not in ("Window", "Door"):
            continue
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        box = box_item.get("boundingBox3D", {})
        x1 = float(box.get("xMin", 0.0))
        x2 = float(box.get("xMax", 0.0))
        y1 = float(box.get("yMin", 0.0))
        y2 = float(box.get("yMax", 0.0))
        z1 = float(box.get("zMin", 0.0))
        z2 = float(box.get("zMax", 0.0))
        if max(x2 - x1, y2 - y1) < 0.28 or z2 - z1 < 0.35:
            continue
        rows.append(
            {
                "guid": element.get("elementId", {}).get("guid", ""),
                "type": typ,
                "layer": layer,
                "old_id": detail.get("id", ""),
                "x1": x1,
                "x2": x2,
                "y1": y1,
                "y2": y2,
                "z1": z1,
                "z2": z2,
            }
        )
    rows.sort(key=lambda item: (item["type"], item["y1"], item["x1"], item["z1"]))
    return rows


def count_elements_on_layer(commands, types, layer_index):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    total = 0
    for detail in details:
        try:
            total += int(detail.get("layerIndex", -1)) == int(layer_index)
        except Exception:
            pass
    return total


def add_box(rows, code, classe, source, x, y, z, sx, sy, sz, note):
    if sx <= 0.005 or sy <= 0.005 or sz <= 0.005:
        return
    rows.append(
        {
            "code": code,
            "classe": classe,
            "sourceGuid": source["guid"],
            "sourceType": source["type"],
            "sourceId": source["old_id"],
            "sourceLayer": source["layer"],
            "x": round(float(x), 4),
            "y": round(float(y), 4),
            "z": round(float(z), 4),
            "sizeX": round(float(sx), 4),
            "sizeY": round(float(sy), 4),
            "sizeZ": round(float(sz), 4),
            "note": note,
            "data": {"basePoint": point3(x, y, z), "size": dim3(sx, sy, sz)},
        }
    )


def build_frame_morphs(opening_rows):
    rows = []
    counters = Counter()
    for opening in opening_rows:
        x1, x2 = opening["x1"], opening["x2"]
        y1, y2 = opening["y1"], opening["y2"]
        z1, z2 = opening["z1"], opening["z2"]
        sx = x2 - x1
        sy = y2 - y1
        sz = z2 - z1
        if sz <= 0:
            continue

        typ = opening["type"]
        prefix = "FED" if typ == "Window" else "POR"
        counters[prefix] += 1
        base = f"BER-V08-{prefix}-{counters[prefix]:03d}"

        # Cornici leggere: attraversano leggermente lo spessore della parete,
        # cosi restano leggibili anche sulle facciate non perfettamente allineate.
        pad = 0.08 if typ == "Window" else 0.12
        frame = 0.07 if typ == "Window" else 0.12
        depth_pad = 0.08
        top_extra = 0.12 if typ == "Window" else 0.20

        if sx >= sy:
            # Facciata con apertura sviluppata lungo X.
            y = y1 - depth_pad * 0.5
            depth = max(0.12, sy + depth_pad)
            add_box(rows, f"{base}-S", "spalla-sinistra", opening, x1 - pad, y, z1 - pad, frame, depth, sz + 2 * pad, "spalla cornice")
            add_box(rows, f"{base}-D", "spalla-destra", opening, x2 + pad - frame, y, z1 - pad, frame, depth, sz + 2 * pad, "spalla cornice")
            add_box(rows, f"{base}-A", "architrave", opening, x1 - pad, y, z2 + pad * 0.2, sx + 2 * pad, depth, frame + top_extra, "architrave/edicola")
            if typ == "Window":
                add_box(rows, f"{base}-B", "davanzale", opening, x1 - pad, y, z1 - pad, sx + 2 * pad, depth, frame, "davanzale")
        else:
            # Facciata con apertura sviluppata lungo Y.
            x = x1 - depth_pad * 0.5
            depth = max(0.12, sx + depth_pad)
            add_box(rows, f"{base}-S", "spalla-sinistra", opening, x, y1 - pad, z1 - pad, depth, frame, sz + 2 * pad, "spalla cornice")
            add_box(rows, f"{base}-D", "spalla-destra", opening, x, y2 + pad - frame, z1 - pad, depth, frame, sz + 2 * pad, "spalla cornice")
            add_box(rows, f"{base}-A", "architrave", opening, x, y1 - pad, z2 + pad * 0.2, depth, sy + 2 * pad, frame + top_extra, "architrave/edicola")
            if typ == "Window":
                add_box(rows, f"{base}-B", "davanzale", opening, x, y1 - pad, z1 - pad, depth, sy + 2 * pad, frame, "davanzale")
    return rows


def set_elements_layer(commands, types, created_rows, layer_index):
    if not created_rows:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": int(layer_index)}}
                for row in created_rows
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def write_general_ids(commands, types, created_rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created_rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created_rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created_rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def write_outputs(layer_index, opening_rows, created_rows, failures, layer_result, id_result):
    fields = [
        "codice_id",
        "guid",
        "layer",
        "classe",
        "sorgente_tipo",
        "sorgente_id",
        "sorgente_guid",
        "x",
        "y",
        "z",
        "sizeX",
        "sizeY",
        "sizeZ",
        "volume_m3",
        "note",
    ]
    csv_rows = []
    for row in created_rows:
        csv_rows.append(
            {
                "codice_id": row["code"],
                "guid": row["element"]["elementId"]["guid"],
                "layer": LAYER_NAME,
                "classe": row["classe"],
                "sorgente_tipo": row["sourceType"],
                "sorgente_id": row["sourceId"],
                "sorgente_guid": row["sourceGuid"],
                "x": row["x"],
                "y": row["y"],
                "z": row["z"],
                "sizeX": row["sizeX"],
                "sizeY": row["sizeY"],
                "sizeZ": row["sizeZ"],
                "volume_m3": round(row["sizeX"] * row["sizeY"] * row["sizeZ"], 5),
                "note": row["note"],
            }
        )
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(csv_rows)

    summary = Counter(row["classe"] for row in created_rows)
    source_summary = Counter(row["sourceType"] for row in created_rows)
    payload = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "openingsRead": len(opening_rows),
        "requested": len(created_rows) + len(failures),
        "created": len(created_rows),
        "failures": failures,
        "summaryByClass": dict(summary),
        "summaryBySourceType": dict(source_summary),
        "setLayerResult": layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V08 - FINESTRE ED EDICOLE",
                "=" * 40,
                f"Layer: {LAYER_NAME} index {layer_index}",
                f"Aperture lette: {len(opening_rows)}",
                f"Elementi creati: {len(created_rows)}",
                "Classi:",
                *[f"- {name}: {count}" for name, count in sorted(summary.items())],
                "Sorgenti:",
                *[f"- {name}: {count}" for name, count in sorted(source_summary.items())],
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea cornici/edicole leggere su finestre e porte esistenti.")
        print("Uso: py 63_tapir_v08_finestre_edicole_berra.py APPLICA")
        print("Per rilanciare su layer gia popolato: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)
    existing = count_elements_on_layer(commands, types, layer_index)
    if existing and not force:
        print(f"Layer {LAYER_NAME} gia popolato con {existing} elementi. Nessuna modifica.")
        print("Usa FORZA solo dopo verifica visiva.")
        return

    opening_rows = get_model_rows(commands, types)
    morph_rows = build_frame_morphs(opening_rows)
    if not morph_rows:
        raise SystemExit("Nessuna apertura utile trovata.")

    created_rows = []
    failures = []
    for row in morph_rows:
        try:
            result = tapir(commands, types, "CreateMorphs", {"morphsData": [row["data"]]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": row["code"], "error": "nessun elemento restituito", "result": result})
                continue
            new_row = dict(row)
            new_row["element"] = elements[0]
            created_rows.append(new_row)
        except Exception as exc:
            failures.append({"code": row["code"], "error": str(exc)})

    layer_result = set_elements_layer(commands, types, created_rows, layer_index)
    id_result = write_general_ids(commands, types, created_rows)
    write_outputs(layer_index, opening_rows, created_rows, failures, layer_result, id_result)

    print("BERRA V08 finestre/edicole applicata.")
    print(f"Aperture lette: {len(opening_rows)}")
    print(f"Elementi cornice creati: {len(created_rows)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
