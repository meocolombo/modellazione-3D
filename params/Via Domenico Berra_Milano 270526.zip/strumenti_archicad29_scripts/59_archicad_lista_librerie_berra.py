from __future__ import annotations

import csv
from pathlib import Path

from archicad import ACConnection


OUT_CSV = Path("berra_librerie_object_parts.csv")
OUT_TXT = Path("berra_librerie_object_parts.txt")
KEYWORDS = (
    "albero",
    "tree",
    "plant",
    "pianta",
    "arbusto",
    "shrub",
    "bench",
    "panchina",
    "sedia",
    "chair",
    "lamp",
    "pozzo",
    "well",
    "truss",
    "capriat",
    "trave",
    "beam",
    "rafter",
    "purlin",
    "joist",
    "wood",
    "legno",
    "tetto",
    "roof",
    "structure",
    "strutt",
    "assito",
)


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    libs = tapir(commands, types, "GetLibraries")
    parts = tapir(commands, types, "GetAvailableLibraryParts", {"filterByTypeId": "Object"})
    rows = parts.get("libraryParts", [])
    matches = []
    for row in rows:
        text = " ".join(str(row.get(key, "")) for key in ("documentName", "fileName", "typeId")).casefold()
        if any(keyword in text for keyword in KEYWORDS):
            matches.append(row)

    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["documentName", "fileName", "typeId", "index", "guid"], delimiter=";")
        writer.writeheader()
        for row in matches:
            writer.writerow(
                {
                    "documentName": row.get("documentName", ""),
                    "fileName": row.get("fileName", ""),
                    "typeId": row.get("typeId", ""),
                    "index": row.get("index", ""),
                    "guid": row.get("guid", ""),
                }
            )

    lines = [
        "BERRA - PARTI LIBRERIA OBJECT",
        "=" * 30,
        f"Librerie caricate: {len(libs.get('libraries', []))}",
        f"Object parts totali: {len(rows)}",
        f"Object parts filtrate: {len(matches)}",
        "",
        "Librerie:",
    ]
    for lib in libs.get("libraries", []):
        lines.append(f"- {lib.get('name')} | {lib.get('type')} | available={lib.get('available')} | {lib.get('path')}")
    lines.append("")
    lines.append("Candidati:")
    for row in matches[:200]:
        lines.append(f"- {row.get('documentName')} | {row.get('fileName')} | {row.get('typeId')}")
    OUT_TXT.write_text("\n".join(lines), encoding="utf-8")

    print(f"Librerie caricate: {len(libs.get('libraries', []))}")
    print(f"Object parts totali: {len(rows)}")
    print(f"Object parts filtrate: {len(matches)}")
    print(f"Creati: {OUT_TXT}, {OUT_CSV}")


if __name__ == "__main__":
    main()
