from __future__ import annotations

import csv
import json
import struct
import sys
from pathlib import Path


SRC = Path(r"Z:\268_Via Berra Milano\3d e piante via berra\268_BERRA_10_BACKUP_PRIMA_AI_V02.3ds")
OUT_DIR = Path(r"E:\strumenti-archicad29")

CHUNK_MAIN = 0x4D4D
CHUNK_OBJMESH = 0x3D3D
CHUNK_OBJBLOCK = 0x4000
CHUNK_TRIMESH = 0x4100
CHUNK_VERTLIST = 0x4110
CHUNK_FACELIST = 0x4120
CHUNK_MAPCOORDS = 0x4140
CHUNK_LOCALAXIS = 0x4160


def read_cstring(data: bytes, pos: int, end: int):
    out = []
    while pos < end and data[pos] != 0:
        out.append(data[pos])
        pos += 1
    return bytes(out).decode("latin-1", errors="replace"), min(pos + 1, end)


def chunks(data: bytes, start: int, end: int):
    pos = start
    while pos + 6 <= end:
        chunk_id, length = struct.unpack_from("<HI", data, pos)
        if length < 6:
            break
        chunk_end = min(pos + length, end)
        yield chunk_id, pos + 6, chunk_end
        pos += length


def parse_vertices(data: bytes, start: int, end: int):
    if start + 2 > end:
        return []
    count = struct.unpack_from("<H", data, start)[0]
    pos = start + 2
    vertices = []
    for _ in range(count):
        if pos + 12 > end:
            break
        vertices.append(struct.unpack_from("<fff", data, pos))
        pos += 12
    return vertices


def parse_faces(data: bytes, start: int, end: int):
    if start + 2 > end:
        return []
    count = struct.unpack_from("<H", data, start)[0]
    pos = start + 2
    faces = []
    for _ in range(count):
        if pos + 8 > end:
            break
        a, b, c, flags = struct.unpack_from("<HHHH", data, pos)
        faces.append((a, b, c, flags))
        pos += 8
    return faces


def parse_axis(data: bytes, start: int, end: int):
    if start + 48 > end:
        return None
    values = struct.unpack_from("<12f", data, start)
    return {
        "xAxis": values[0:3],
        "yAxis": values[3:6],
        "zAxis": values[6:9],
        "origin": values[9:12],
    }


def parse_trimesh(data: bytes, start: int, end: int):
    vertices = []
    faces = []
    axis = None
    for chunk_id, payload_start, chunk_end in chunks(data, start, end):
        if chunk_id == CHUNK_VERTLIST:
            vertices = parse_vertices(data, payload_start, chunk_end)
        elif chunk_id == CHUNK_FACELIST:
            faces = parse_faces(data, payload_start, chunk_end)
        elif chunk_id == CHUNK_LOCALAXIS:
            axis = parse_axis(data, payload_start, chunk_end)
    return vertices, faces, axis


def parse_object(data: bytes, start: int, end: int):
    name, pos = read_cstring(data, start, end)
    item = {"name": name, "vertices": [], "faces": [], "axis": None}
    for chunk_id, payload_start, chunk_end in chunks(data, pos, end):
        if chunk_id == CHUNK_TRIMESH:
            vertices, faces, axis = parse_trimesh(data, payload_start, chunk_end)
            item["vertices"] = vertices
            item["faces"] = faces
            item["axis"] = axis
    return item


def walk(data: bytes, start: int, end: int):
    found = []
    for chunk_id, payload_start, chunk_end in chunks(data, start, end):
        if chunk_id == CHUNK_OBJBLOCK:
            found.append(parse_object(data, payload_start, chunk_end))
        else:
            found.extend(walk(data, payload_start, chunk_end))
    return found


def classify(row):
    name = row["name"].lower()
    dx = row["dx"]
    dy = row["dy"]
    dz = row["dz"]
    if any(token in name for token in ("roof", "tetto", "cop", "falda", "tile", "tegola")):
        return "copertura_nome"
    if dz < 0.35 and max(dx, dy) > 3.0:
        return "piano_sottile"
    if dz > 1.0 and max(dx, dy) > 3.0:
        return "volume_verticale"
    if min(dx, dy) < 0.8 and max(dx, dy) > 2.0:
        return "lineare"
    return "altro"


def bbox(vertices):
    xs = [v[0] for v in vertices]
    ys = [v[1] for v in vertices]
    zs = [v[2] for v in vertices]
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)


def fmt(value):
    return round(float(value), 5)


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else SRC
    out_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else OUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    data = src.read_bytes()
    objects = [obj for obj in walk(data, 0, len(data)) if obj["vertices"]]
    rows = []
    for obj in objects:
        x1, x2, y1, y2, z1, z2 = bbox(obj["vertices"])
        row = {
            "name": obj["name"],
            "vertexCount": len(obj["vertices"]),
            "faceCount": len(obj["faces"]),
            "xMin": fmt(x1),
            "xMax": fmt(x2),
            "yMin": fmt(y1),
            "yMax": fmt(y2),
            "zMin": fmt(z1),
            "zMax": fmt(z2),
            "dx": fmt(x2 - x1),
            "dy": fmt(y2 - y1),
            "dz": fmt(z2 - z1),
            "axisOrigin": obj["axis"]["origin"] if obj["axis"] else "",
        }
        row["class"] = classify(row)
        rows.append(row)

    rows.sort(key=lambda row: (row["class"], row["zMin"], row["yMin"], row["xMin"], row["name"]))
    csv_path = out_dir / "berra_3ds_chunk_objects.csv"
    json_path = out_dir / "berra_3ds_chunk_objects.json"
    txt_path = out_dir / "berra_3ds_chunk_report.txt"
    fields = [
        "name",
        "class",
        "vertexCount",
        "faceCount",
        "xMin",
        "xMax",
        "yMin",
        "yMax",
        "zMin",
        "zMax",
        "dx",
        "dy",
        "dz",
        "axisOrigin",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
    json_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    by_class = {}
    for row in rows:
        by_class[row["class"]] = by_class.get(row["class"], 0) + 1
    txt_path.write_text(
        "\n".join(
            [
                "BERRA - ANALISI 3DS A CHUNK",
                "=" * 34,
                f"File: {src}",
                f"Oggetti con vertici: {len(rows)}",
                "Classi:",
                *(f"- {key}: {value}" for key, value in sorted(by_class.items())),
                f"CSV: {csv_path}",
                f"JSON: {json_path}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Oggetti con vertici: {len(rows)}")
    print(f"Report: {txt_path}")


if __name__ == "__main__":
    main()
