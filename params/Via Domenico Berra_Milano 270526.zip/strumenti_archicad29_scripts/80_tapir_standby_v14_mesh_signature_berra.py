from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


STANDBY_LAYER = "BERRA_STANDBY_REVISIONE_STRUTTURE_FINITURE"
SOURCE_LAYER = "Sito e Paesaggio - Terreno"
ID_PATTERN = re.compile(r"^TER\s*-\s*\d{3}$")
OUT_TXT = Path(r"E:\strumenti-archicad29\berra_standby_v14_mesh_signature_report.txt")
OUT_JSON = Path(r"E:\strumenti-archicad29\berra_standby_v14_mesh_signature_result.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_standby_layer(commands, types):
    existing = find_layer_index(commands, types, STANDBY_LAYER)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": STANDBY_LAYER,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 190,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, STANDBY_LAYER)
    if created is None:
        raise RuntimeError(f"Layer non creato: {STANDBY_LAYER}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Mette in stand-by solo le mesh con firma V14: Mesh, TER - nnn, layer terreno, zMin 5.3.")
        print("Uso: py 80_tapir_standby_v14_mesh_signature_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby_index = create_or_get_standby_layer(commands, types)
    layers = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])

    matched = []
    scanned_meshes = 0
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Mesh":
            continue
        scanned_meshes += 1
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        elem_id = str(detail.get("id", ""))
        box = box_item.get("boundingBox3D", {})
        z_min = round(float(box.get("zMin", 9999.0)), 3)
        z_max = float(box.get("zMax", 0.0))
        if layer != SOURCE_LAYER:
            continue
        if not ID_PATTERN.match(elem_id):
            continue
        if abs(z_min - 5.3) > 0.001:
            continue
        if z_max < 8.0:
            continue
        matched.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "id": elem_id,
                "layer": layer,
                "box": {key: round(float(box.get(key, 0.0)), 4) for key in ("xMin", "xMax", "yMin", "yMax", "zMin", "zMax")},
            }
        )

    if matched:
        result = tapir(
            commands,
            types,
            "SetDetailsOfElements",
            {
                "elementsWithDetails": [
                    {"elementId": row["element"]["elementId"], "details": {"layerIndex": standby_index}}
                    for row in matched
                ]
            },
        )
    else:
        result = None

    payload = {
        "signature": {
            "type": "Mesh",
            "layer": SOURCE_LAYER,
            "idPattern": ID_PATTERN.pattern,
            "zMin": 5.3,
            "zMaxMinimum": 8.0,
        },
        "scannedMeshes": scanned_meshes,
        "matchedMoved": len(matched),
        "byLayer": dict(Counter(row["layer"] for row in matched)),
        "standbyLayer": STANDBY_LAYER,
        "standbyIndex": standby_index,
        "matched": [{key: value for key, value in row.items() if key != "element"} for row in matched],
        "result": result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - STAND-BY V14 MESH SIGNATURE",
                "=" * 44,
                f"Mesh controllate: {scanned_meshes}",
                f"Mesh con firma V14 spostate: {len(matched)}",
                "Firma usata:",
                f"- tipo: Mesh",
                f"- layer: {SOURCE_LAYER}",
                f"- ID: TER - nnn",
                f"- zMin: 5.3",
                f"- zMax minimo: 8.0",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Mesh V14 spostate in stand-by: {len(matched)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
