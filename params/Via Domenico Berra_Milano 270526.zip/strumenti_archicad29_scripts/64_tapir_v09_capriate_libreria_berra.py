from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_V09_CAPRIATE_LIBRERIA"
OUT_JSON = Path("berra_v09_capriate_libreria_result.json")
OUT_CSV = Path("berra_v09_capriate_libreria_elementi.csv")
OUT_TXT = Path("berra_v09_capriate_libreria_report.txt")
LIBRARY_PART = "Capriata Storica"


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 172,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_roof_rows(commands, types):
    layer_names = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Roof":
            continue
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        if layer.startswith("BERRA_STANDBY_"):
            continue
        box = box_item.get("boundingBox3D", {})
        x1 = float(box.get("xMin", 0.0))
        x2 = float(box.get("xMax", 0.0))
        y1 = float(box.get("yMin", 0.0))
        y2 = float(box.get("yMax", 0.0))
        z1 = float(box.get("zMin", 0.0))
        z2 = float(box.get("zMax", 0.0))
        span_x = x2 - x1
        span_y = y2 - y1
        if span_x < 4.5 or span_y < 7.0:
            continue
        # L'oggetto libreria non viene ruotato dal bridge: lo usiamo solo dove
        # la capriata puo svilupparsi sull'asse X della falda.
        if span_y < span_x:
            continue
        rows.append(
            {
                "guid": element.get("elementId", {}).get("guid", ""),
                "layer": layer,
                "old_id": detail.get("id", ""),
                "x1": x1,
                "x2": x2,
                "y1": y1,
                "y2": y2,
                "z1": z1,
                "z2": z2,
                "spanX": span_x,
                "spanY": span_y,
            }
        )
    rows.sort(key=lambda item: (item["y1"], item["x1"], item["guid"]))
    return rows


def count_elements_on_layer(commands, types, layer_index):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    count = 0
    for detail in details:
        try:
            count += int(detail.get("layerIndex", -1)) == int(layer_index)
        except Exception:
            pass
    return count


def positions_between(start, end, count):
    if count <= 1:
        return [(start + end) / 2.0]
    return [start + (end - start) * (i + 1) / (count + 1) for i in range(count)]


def build_capriate(roof_rows):
    rows = []
    number = 0
    for roof_index, roof in enumerate(roof_rows, start=1):
        x1, x2 = roof["x1"], roof["x2"]
        y1, y2 = roof["y1"], roof["y2"]
        span_x = roof["spanX"]
        span_y = roof["spanY"]
        margin_x = min(0.65, span_x * 0.10)
        margin_y = min(0.85, span_y * 0.10)
        usable_x = max(1.0, span_x - 2 * margin_x)
        # Una capriata ogni campata principale, ma senza affollare il modello.
        count = 1 if span_y < 13.0 else 2 if span_y < 24.0 else 3
        for y in positions_between(y1 + margin_y, y2 - margin_y, count):
            number += 1
            z_base = roof["z1"] + 0.22
            height = max(0.90, min(2.40, (roof["z2"] - roof["z1"]) * 0.55))
            rows.append(
                {
                    "code": f"BER-V09-CAP-{number:03d}",
                    "roofGuid": roof["guid"],
                    "roofLayer": roof["layer"],
                    "roofOldId": roof["old_id"],
                    "libraryPartName": LIBRARY_PART,
                    "x": round((x1 + x2) / 2.0, 4),
                    "y": round(float(y), 4),
                    "z": round(float(z_base), 4),
                    "sizeX": round(float(usable_x), 4),
                    "sizeY": 0.45,
                    "sizeZ": round(float(height), 4),
                    "note": f"capriata storica indicativa su falda {roof_index}",
                    "data": {
                        "libraryPartName": LIBRARY_PART,
                        "coordinates": point3((x1 + x2) / 2.0, y, z_base),
                        "dimensions": dim3(usable_x, 0.45, height),
                    },
                }
            )
    return rows


def set_elements_layer(commands, types, created_rows, layer_index):
    if not created_rows:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": int(layer_index)}}
                for row in created_rows
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def write_general_ids(commands, types, created_rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created_rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created_rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created_rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def write_outputs(layer_index, roof_rows, created_rows, failures, layer_result, id_result):
    fields = [
        "codice_id",
        "guid",
        "layer",
        "libraryPartName",
        "roof_guid",
        "roof_layer",
        "x",
        "y",
        "z",
        "sizeX",
        "sizeY",
        "sizeZ",
        "note",
    ]
    csv_rows = []
    for row in created_rows:
        csv_rows.append(
            {
                "codice_id": row["code"],
                "guid": row["element"]["elementId"]["guid"],
                "layer": LAYER_NAME,
                "libraryPartName": row["libraryPartName"],
                "roof_guid": row["roofGuid"],
                "roof_layer": row["roofLayer"],
                "x": row["x"],
                "y": row["y"],
                "z": row["z"],
                "sizeX": row["sizeX"],
                "sizeY": row["sizeY"],
                "sizeZ": row["sizeZ"],
                "note": row["note"],
            }
        )
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(csv_rows)

    payload = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "roofRowsUsed": len(roof_rows),
        "requested": len(created_rows) + len(failures),
        "created": len(created_rows),
        "failures": failures,
        "setLayerResult": layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V09 - CAPRIATE DI LIBRERIA",
                "=" * 40,
                f"Layer: {LAYER_NAME} index {layer_index}",
                f"Falde utilizzate: {len(roof_rows)}",
                f"Capriate create: {len(created_rows)}",
                f"Fallimenti: {len(failures)}",
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea capriate storiche di libreria sulle falde compatibili.")
        print("Uso: py 64_tapir_v09_capriate_libreria_berra.py APPLICA")
        print("Per rilanciare su layer gia popolato: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)
    existing = count_elements_on_layer(commands, types, layer_index)
    if existing and not force:
        print(f"Layer {LAYER_NAME} gia popolato con {existing} elementi. Nessuna modifica.")
        print("Usa FORZA solo dopo verifica visiva.")
        return

    roof_rows = get_roof_rows(commands, types)
    object_rows = build_capriate(roof_rows)
    if not object_rows:
        raise SystemExit("Nessuna falda compatibile trovata per le capriate di libreria.")

    created_rows = []
    failures = []
    for row in object_rows:
        try:
            result = tapir(commands, types, "CreateObjects", {"objectsData": [row["data"]]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": row["code"], "error": "nessun elemento restituito", "result": result})
                continue
            new_row = dict(row)
            new_row["element"] = elements[0]
            created_rows.append(new_row)
        except Exception as exc:
            failures.append({"code": row["code"], "error": str(exc)})

    layer_result = set_elements_layer(commands, types, created_rows, layer_index)
    id_result = write_general_ids(commands, types, created_rows)
    write_outputs(layer_index, roof_rows, created_rows, failures, layer_result, id_result)

    print("BERRA V09 capriate di libreria applicata.")
    print(f"Falde compatibili: {len(roof_rows)}")
    print(f"Capriate create: {len(created_rows)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
