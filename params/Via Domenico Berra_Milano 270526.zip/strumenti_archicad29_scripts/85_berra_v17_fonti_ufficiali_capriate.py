from __future__ import annotations

import csv
from pathlib import Path

from PIL import Image, ImageOps


BASE = Path(r"E:\Project_berra_Prova 04 100626\CARTELLA BERRA_100626\COSTRUZIONE_100625")
OUT_DIR = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526\output_berra_v03_falde_ifc_pipeline")

OUT_FONTI = OUT_DIR / "berra_v17_fonti_ufficiali_input.csv"
OUT_CAPRIATE = OUT_DIR / "berra_v17_catalogo_capriate_travi.csv"
OUT_REPORT = OUT_DIR / "berra_v17_fonti_ufficiali_capriate_report.md"


SOURCE_ITEMS = [
    {
        "ambito": "geometria",
        "file": "01_MODELLLO_ESISTENTE",
        "uso_bim": "base sagoma esistente e confronto con V03",
        "regola": "riscontro, non sostituisce il V03 aperto in Archicad",
    },
    {
        "ambito": "pianta",
        "file": r"02_PLANIMETRIE\BERRA PIANO TERRENO.jpg",
        "uso_bim": "muri, corti, portici, accessi, giardino",
        "regola": "calibrare su sagoma V03 prima di generare aperture o portici",
    },
    {
        "ambito": "pianta",
        "file": r"02_PLANIMETRIE\BERRA PIANO PRIMO.jpg",
        "uso_bim": "finestre, logge e corrispondenza verticali",
        "regola": "usare dopo allineamento piano terreno/primo",
    },
    {
        "ambito": "pianta",
        "file": r"02_PLANIMETRIE\BERRA PIANO SOTTOTETTO.jpg",
        "uso_bim": "sottotetto, travi, appoggi e geometrie di copertura",
        "regola": "fonte primaria per strutture sottotetto insieme a planimetria capriate",
    },
    {
        "ambito": "quota",
        "file": r"02_PLANIMETRIE\PIANTA CON QUOTE-1.jpg",
        "uso_bim": "scala generale e controllo distanze",
        "regola": "usare come calibrazione dimensionale",
    },
    {
        "ambito": "coperture",
        "file": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\PLANIMETRIA CAPRIATE.jpg",
        "uso_bim": "posizione ufficiale capriate e travi",
        "regola": "fonte primaria per V17; non usare piu griglie automatiche V15/V16 come finale",
    },
    {
        "ambito": "coperture",
        "file": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\PLANIMETRIA TETTI.jpg",
        "uso_bim": "zone di intervento, manto, consolidamento",
        "regola": "associare campate e fasi A-B / C-D-E",
    },
    {
        "ambito": "dettaglio",
        "file": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE.jpg",
        "uso_bim": "schema catalogazione travi e tipologie di capriata",
        "regola": "derivare famiglie/oggetti tipo 1, 2, 3",
    },
    {
        "ambito": "dettaglio",
        "file": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE 02.jpg",
        "uso_bim": "sezioni progetto, pacchetto copertura, appoggi, correnti",
        "regola": "usare per sezione e stratigrafia",
    },
    {
        "ambito": "rilievo",
        "file": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\MAPPA E FOTO CAPRIATE RILEVATE.jpg",
        "uso_bim": "riscontro fotografico travi 1-8 e dissesti",
        "regola": "associare ID BIM alle travi rilevate",
    },
    {
        "ambito": "sezione",
        "file": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\SEZIONE TIPO.jpg",
        "uso_bim": "ingombri verticali e relazione con copertura",
        "regola": "verifica quote e spessori prima di importare oggetti",
    },
    {
        "ambito": "foto",
        "file": r"04_fOTO\TETTI",
        "uso_bim": "coppi, camini, lucernai, gronde, pluviali, scossaline",
        "regola": "texture e dettagli puntuali",
    },
    {
        "ambito": "foto",
        "file": r"04_fOTO\FACCIATA SU STRADA 01",
        "uso_bim": "facciata, portale, portone, finestre, cornici, cancellata",
        "regola": "fase successiva a strutture tetto",
    },
    {
        "ambito": "foto",
        "file": r"04_fOTO\PRIMO PORTICO",
        "uso_bim": "archi, colonne/pilastri, loggiato, pavimenti",
        "regola": "fase successiva a strutture tetto",
    },
    {
        "ambito": "foto",
        "file": r"04_fOTO\SECONDO PORTICO CON GIARDINO",
        "uso_bim": "portico laterizio, pozzo, archi, camminamenti",
        "regola": "fase successiva a strutture tetto",
    },
]


TRUSS_CATALOG = [
    {
        "id_bim": "BERRA-STR-CAP-T01",
        "tipo": "Capriata tipo 1",
        "fonte": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE.jpg",
        "componenti": "catena, puntoni, monaco, saette, appoggi laterali",
        "uso": "capriate indicate come tipo 1 nella planimetria ufficiale",
        "stato": "da modellare dopo calibrazione tavola capriate",
    },
    {
        "id_bim": "BERRA-STR-CAP-T02",
        "tipo": "Capriata tipo 2",
        "fonte": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE.jpg",
        "componenti": "catena, puntoni, monaco, saette; schema piu basso/compatto",
        "uso": "capriate indicate come tipo 2 nella planimetria ufficiale",
        "stato": "da modellare dopo calibrazione tavola capriate",
    },
    {
        "id_bim": "BERRA-STR-CAP-T03",
        "tipo": "Capriata tipo 3",
        "fonte": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE.jpg",
        "componenti": "capriata con pacchetto sottostante e assito/controsoffitto ligneo",
        "uso": "capriate indicate come tipo 3 nella planimetria ufficiale",
        "stato": "da modellare dopo calibrazione tavola capriate",
    },
    {
        "id_bim": "BERRA-STR-TRV-001",
        "tipo": "Travi 1-3",
        "fonte": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\MAPPA E FOTO CAPRIATE RILEVATE.jpg",
        "componenti": "travi rilevate da sostituire",
        "uso": "catalogazione e computo intervento",
        "stato": "da sostituire secondo tavola di rilievo",
    },
    {
        "id_bim": "BERRA-STR-TRV-004",
        "tipo": "Travi 4-9",
        "fonte": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE.jpg",
        "componenti": "travi rilevate da consolidare",
        "uso": "catalogazione e computo intervento",
        "stato": "da consolidare secondo tavola di rilievo",
    },
    {
        "id_bim": "BERRA-STR-TRV-010A",
        "tipo": "Travi 10A/10Z, 11A/11V, 12A/12C",
        "fonte": r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\DETTAGLIO CAPRIATE.jpg",
        "componenti": "travi/capriate catalogate per coppie",
        "uso": "catalogazione e computo intervento",
        "stato": "da consolidare secondo tavola di rilievo",
    },
]


def image_meta(path: Path) -> tuple[int | None, int | None]:
    if not path.is_file() or path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp"}:
        return None, None
    with Image.open(path) as image:
        image = ImageOps.exif_transpose(image)
        return image.width, image.height


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    source_rows: list[dict[str, str]] = []
    for item in SOURCE_ITEMS:
        p = BASE / item["file"]
        width, height = image_meta(p)
        source_rows.append(
            {
                "ambito": item["ambito"],
                "file": item["file"],
                "esiste": "si" if p.exists() else "no",
                "tipo": "cartella" if p.is_dir() else p.suffix.lower(),
                "larghezza_px": "" if width is None else str(width),
                "altezza_px": "" if height is None else str(height),
                "uso_bim": item["uso_bim"],
                "regola": item["regola"],
            }
        )

    write_csv(OUT_FONTI, source_rows)
    write_csv(OUT_CAPRIATE, TRUSS_CATALOG)

    missing = [row for row in source_rows if row["esiste"] != "si"]
    lines = [
        "# Berra V17 - fonti ufficiali capriate e strutture",
        "",
        "Questa passata non modifica Archicad.",
        "Serve a bloccare le fonti corrette prima di generare nuovi elementi BIM.",
        "",
        "## Output",
        "",
        f"- `{OUT_FONTI.name}`",
        f"- `{OUT_CAPRIATE.name}`",
        "",
        "## Regole operative",
        "",
        "- Non usare piu le griglie strutturali V15/V16 come modello finale.",
        "- Usare il V03 come base geometrica delle falde impostate dall'utente.",
        "- Usare `PLANIMETRIA CAPRIATE.jpg` per posizione e campate delle capriate.",
        "- Usare `DETTAGLIO CAPRIATE.jpg` e `DETTAGLIO CAPRIATE 02.jpg` per tipologie e sezioni.",
        "- Usare `MAPPA E FOTO CAPRIATE RILEVATE.jpg` per stato, numerazione e priorita di intervento.",
        "",
        "## Controllo file",
        "",
        f"- Fonti controllate: {len(source_rows)}",
        f"- Fonti mancanti: {len(missing)}",
    ]
    if missing:
        lines.append("")
        lines.append("### Mancanti")
        for row in missing:
            lines.append(f"- `{row['file']}`")

    OUT_REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Creato: {OUT_FONTI}")
    print(f"Creato: {OUT_CAPRIATE}")
    print(f"Creato: {OUT_REPORT}")


if __name__ == "__main__":
    main()

