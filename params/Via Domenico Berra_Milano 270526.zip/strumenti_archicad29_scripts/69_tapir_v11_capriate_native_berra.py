from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_V11_CAPRIATE_NATIVE"
OUT_JSON = Path("berra_v11_capriate_native_result.json")
OUT_CSV = Path("berra_v11_capriate_native_elementi.csv")
OUT_TXT = Path("berra_v11_capriate_native_report.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 175,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_roof_rows(commands, types):
    layer_names = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Roof":
            continue
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        if layer.startswith("BERRA_STANDBY_"):
            continue
        box = box_item.get("boundingBox3D", {})
        x1 = float(box.get("xMin", 0.0))
        x2 = float(box.get("xMax", 0.0))
        y1 = float(box.get("yMin", 0.0))
        y2 = float(box.get("yMax", 0.0))
        z1 = float(box.get("zMin", 0.0))
        z2 = float(box.get("zMax", 0.0))
        span_x = x2 - x1
        span_y = y2 - y1
        height = z2 - z1
        if span_x < 4.5 or span_y < 8.0 or height < 1.25:
            continue
        if span_y < span_x:
            continue
        rows.append(
            {
                "guid": element.get("elementId", {}).get("guid", ""),
                "layer": layer,
                "old_id": detail.get("id", ""),
                "x1": x1,
                "x2": x2,
                "y1": y1,
                "y2": y2,
                "z1": z1,
                "z2": z2,
                "spanX": span_x,
                "spanY": span_y,
                "height": height,
            }
        )
    rows.sort(key=lambda item: (item["y1"], item["x1"], item["guid"]))
    return rows


def count_elements_on_layer(commands, types, layer_index):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    count = 0
    for detail in details:
        try:
            count += int(detail.get("layerIndex", -1)) == int(layer_index)
        except Exception:
            pass
    return count


def positions_between(start, end, count):
    if count <= 1:
        return [(start + end) / 2.0]
    return [start + (end - start) * (i + 1) / (count + 1) for i in range(count)]


def add_beam(rows, code, classe, roof, x1, y1, x2, y2, z, width, height, note):
    rows.append(
        {
            "kind": "Beam",
            "code": code,
            "classe": classe,
            "roofGuid": roof["guid"],
            "roofLayer": roof["layer"],
            "x1": round(float(x1), 4),
            "y1": round(float(y1), 4),
            "x2": round(float(x2), 4),
            "y2": round(float(y2), 4),
            "z": round(float(z), 4),
            "width": round(float(width), 4),
            "height": round(float(height), 4),
            "note": note,
            "data": {
                "begCoordinate": coord(x1, y1),
                "endCoordinate": coord(x2, y2),
                "zCoordinate": float(z),
                "width": float(width),
                "height": float(height),
            },
        }
    )


def add_column(rows, code, classe, roof, x, y, z, height, width, depth, note):
    rows.append(
        {
            "kind": "Column",
            "code": code,
            "classe": classe,
            "roofGuid": roof["guid"],
            "roofLayer": roof["layer"],
            "x1": round(float(x), 4),
            "y1": round(float(y), 4),
            "x2": round(float(x), 4),
            "y2": round(float(y), 4),
            "z": round(float(z), 4),
            "width": round(float(width), 4),
            "height": round(float(height), 4),
            "depth": round(float(depth), 4),
            "note": note,
            "data": {
                "coordinates": point3(x, y, z),
                "height": float(height),
                "width": float(width),
                "depth": float(depth),
            },
        }
    )


def build_native_capriate(roof_rows):
    rows = []
    counters = Counter()

    def code(prefix):
        counters[prefix] += 1
        return f"BER-V11-{prefix}-{counters[prefix]:03d}"

    for roof_index, roof in enumerate(roof_rows, start=1):
        x1, x2 = roof["x1"], roof["x2"]
        y1, y2 = roof["y1"], roof["y2"]
        span_x = roof["spanX"]
        span_y = roof["spanY"]
        margin_x = min(0.75, span_x * 0.10)
        margin_y = min(1.00, span_y * 0.10)
        left = x1 + margin_x
        right = x2 - margin_x
        center_x = (left + right) / 2.0
        length = max(1.0, right - left)
        top_z = roof["z2"] - 0.18
        desired_post_h = min(1.45, max(0.75, roof["height"] - 0.45))
        base_z = max(roof["z1"] + 0.12, top_z - desired_post_h)
        post_h = max(0.65, min(desired_post_h, top_z - base_z))
        collar_z = base_z + post_h - 0.08
        count = 1 if span_y < 13.0 else 2 if span_y < 22.0 else 3

        for y in positions_between(y1 + margin_y, y2 - margin_y, count):
            note = f"capriata nativa controllata su falda {roof_index}"
            add_beam(rows, code("CAT"), "catena", roof, left, y, right, y, base_z, 0.16, 0.18, note)
            add_column(rows, code("MON"), "monaco", roof, center_x, y, base_z, post_h, 0.16, 0.16, note)
            for side_x in (center_x - length * 0.28, center_x + length * 0.28):
                add_column(rows, code("RIT"), "ritto-laterale", roof, side_x, y, base_z, max(0.45, post_h * 0.58), 0.12, 0.12, note)
            collar_len = min(2.20, max(0.85, length * 0.32))
            add_beam(
                rows,
                code("CLR"),
                "collarino",
                roof,
                center_x - collar_len / 2.0,
                y,
                center_x + collar_len / 2.0,
                y,
                collar_z,
                0.12,
                0.12,
                note,
            )
    return rows


def set_elements_layer(commands, types, created_rows, layer_index):
    if not created_rows:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": int(layer_index)}}
                for row in created_rows
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def write_general_ids(commands, types, created_rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created_rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created_rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created_rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def create_rows(commands, types, rows):
    created = []
    failures = []
    for row in rows:
        command_name = "CreateBeams" if row["kind"] == "Beam" else "CreateColumns"
        payload_key = "beamsData" if row["kind"] == "Beam" else "columnsData"
        try:
            result = tapir(commands, types, command_name, {payload_key: [row["data"]]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": row["code"], "kind": row["kind"], "error": "nessun elemento restituito", "result": result})
                continue
            new_row = dict(row)
            new_row["element"] = elements[0]
            created.append(new_row)
        except Exception as exc:
            failures.append({"code": row["code"], "kind": row["kind"], "error": str(exc)})
    return created, failures


def write_outputs(layer_index, roof_rows, created_rows, failures, layer_result, id_result):
    fields = [
        "codice_id",
        "guid",
        "layer",
        "tipo",
        "classe",
        "roof_guid",
        "roof_layer",
        "x1",
        "y1",
        "x2",
        "y2",
        "z",
        "larghezza",
        "altezza",
        "profondita",
        "lunghezza_m",
        "volume_stimato_m3",
        "note",
    ]
    csv_rows = []
    for row in created_rows:
        length = math.hypot(row["x2"] - row["x1"], row["y2"] - row["y1"]) if row["kind"] == "Beam" else row["height"]
        depth = row.get("depth", row["height"])
        volume = length * row["width"] * depth if row["kind"] == "Beam" else row["height"] * row["width"] * row.get("depth", row["width"])
        csv_rows.append(
            {
                "codice_id": row["code"],
                "guid": row["element"]["elementId"]["guid"],
                "layer": LAYER_NAME,
                "tipo": row["kind"],
                "classe": row["classe"],
                "roof_guid": row["roofGuid"],
                "roof_layer": row["roofLayer"],
                "x1": row["x1"],
                "y1": row["y1"],
                "x2": row["x2"],
                "y2": row["y2"],
                "z": row["z"],
                "larghezza": row["width"],
                "altezza": row["height"],
                "profondita": row.get("depth", ""),
                "lunghezza_m": round(length, 4),
                "volume_stimato_m3": round(volume, 5),
                "note": row["note"],
            }
        )
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(csv_rows)

    by_class = Counter(row["classe"] for row in created_rows)
    by_kind = Counter(row["kind"] for row in created_rows)
    payload = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "roofRowsUsed": len(roof_rows),
        "created": len(created_rows),
        "failures": failures,
        "summaryByClass": dict(by_class),
        "summaryByKind": dict(by_kind),
        "setLayerResult": layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V11 - CAPRIATE NATIVE CONTROLLATE",
                "=" * 46,
                f"Layer: {LAYER_NAME} index {layer_index}",
                f"Falde utilizzate: {len(roof_rows)}",
                f"Elementi creati: {len(created_rows)}",
                "Classi:",
                *[f"- {name}: {count}" for name, count in sorted(by_class.items())],
                "Tipi:",
                *[f"- {name}: {count}" for name, count in sorted(by_kind.items())],
                f"Fallimenti: {len(failures)}",
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea capriate native controllate con Beam e Column.")
        print("Uso: py 69_tapir_v11_capriate_native_berra.py APPLICA")
        print("Per rilanciare su layer gia popolato: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)
    existing = count_elements_on_layer(commands, types, layer_index)
    if existing and not force:
        print(f"Layer {LAYER_NAME} gia popolato con {existing} elementi. Nessuna modifica.")
        print("Usa FORZA solo dopo verifica visiva.")
        return

    roof_rows = get_roof_rows(commands, types)
    rows = build_native_capriate(roof_rows)
    if not rows:
        raise SystemExit("Nessuna falda compatibile trovata per capriate native.")
    created_rows, failures = create_rows(commands, types, rows)
    layer_result = set_elements_layer(commands, types, created_rows, layer_index)
    id_result = write_general_ids(commands, types, created_rows)
    write_outputs(layer_index, roof_rows, created_rows, failures, layer_result, id_result)

    print("BERRA V11 capriate native controllate applicata.")
    print(f"Falde compatibili: {len(roof_rows)}")
    print(f"Elementi creati: {len(created_rows)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
