from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_google_earth_correzione_result.json")

STANDBY_LAYER = "BERRA_AI_STANDBY_PRE_GE2_01"
OLD_LAYERS_TO_STANDBY = [
    "BERRA_AI_COPERTURE_01",
    "BERRA_AI_COPERTURE_02",
    "BERRA_AI_CORTE_VERDE_01",
    "BERRA_AI_FRONTE_STRADA_01",
    "BERRA_AI_FINITURE_01",
    "BERRA_AI_SOTTOGRONDA_IMPIANTI_01",
    "BERRA_AI_TEGOLATO_01",
    "BERRA_AI_GE_TETTI_01",
    "BERRA_AI_GE_CORTI_01",
    "BERRA_AI_GE_STRADA_01",
    "BERRA_AI_GE_DETTAGLI_01",
]

LAYER_ROOFS = "BERRA_AI_GE2_TETTI_01"
LAYER_COURTS = "BERRA_AI_GE2_CORTI_01"
LAYER_STREET = "BERRA_AI_GE2_STRADA_01"
LAYER_DETAILS = "BERRA_AI_GE2_DETTAGLI_01"

MODEL_ROTATION_DEG = -3.20
MODEL_PIVOT = (-29.50, -20.00)


# Coordinate ricavate dagli ingombri reali del modello e corrette per una
# lettura piu vicina al volume Google Earth: corte centrale libera, tetti
# continui a falda e strada come contesto esterno.
ROOF_BLOCKS = [
    {
        "name": "manica_ovest_lunga",
        "level": 6.30,
        "thickness": 0.18,
        "angle": 29.0,
        "points": [(-50.45, -72.05), (-41.05, -72.05), (-41.05, 33.10), (-50.45, 33.10)],
    },
    {
        "name": "fronte_via_berra",
        "level": 6.30,
        "thickness": 0.18,
        "angle": 30.0,
        "points": [(-50.45, -72.05), (-10.55, -72.05), (-10.55, -61.20), (-50.45, -61.20)],
    },
    {
        "name": "manica_est_lunga",
        "level": 6.30,
        "thickness": 0.18,
        "angle": 29.0,
        "points": [(-11.05, -72.05), (-7.95, -72.05), (-7.95, 14.35), (-11.05, 14.35)],
    },
    {
        "name": "corpo_interno_sud",
        "level": 5.30,
        "thickness": 0.16,
        "angle": 27.0,
        "points": [(-40.95, -63.35), (-17.35, -63.35), (-17.35, -20.85), (-40.95, -20.85)],
    },
    {
        "name": "manica_nord_loggiato",
        "level": 6.30,
        "thickness": 0.18,
        "angle": 30.0,
        "points": [(-34.45, 13.20), (-8.05, 13.20), (-8.05, 33.05), (-34.45, 33.05)],
    },
    {
        "name": "collegamento_corte_ovest",
        "level": 5.30,
        "thickness": 0.16,
        "angle": 27.0,
        "points": [(-48.45, -33.20), (-41.20, -33.20), (-41.20, -20.75), (-48.45, -20.75)],
    },
    {
        "name": "corpo_trasversale_corte",
        "level": 6.30,
        "thickness": 0.18,
        "angle": 29.0,
        "points": [(-39.85, -21.15), (-16.95, -21.15), (-16.95, -17.00), (-39.85, -17.00)],
    },
]

COURT_GREEN_POLYGONS = [
    # Corte/loggiato nord: sagoma aperta e non rettangolo pieno.
    [(-32.70, 14.35), (-22.20, 14.35), (-21.55, 19.80), (-22.40, 29.85), (-28.10, 30.85), (-32.70, 26.65)],
    # Fascia verde interna sud-ovest, arretrata rispetto ai percorsi.
    [(-38.80, -59.70), (-33.45, -58.90), (-33.15, -44.20), (-35.30, -36.30), (-35.80, -24.05), (-38.85, -24.05)],
    # Fascia verde interna sud-est, separata dal percorso centrale.
    [(-27.35, -59.40), (-22.00, -58.85), (-21.35, -48.10), (-24.30, -38.80), (-24.10, -24.20), (-27.80, -24.20)],
    # Piccola aiuola di ingresso verso via Berra.
    [(-37.40, -69.70), (-31.20, -69.50), (-30.80, -65.20), (-36.60, -64.95)],
]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def polygon_center(points):
    return (
        sum(x for x, _y in points) / len(points),
        sum(y for _x, y in points) / len(points),
    )


def rotate_xy(x, y, center=None):
    """Ruota in pianta attorno al centro locale, mantenendo il posizionamento."""
    px, py = center or MODEL_PIVOT
    angle = math.radians(MODEL_ROTATION_DEG)
    ca = math.cos(angle)
    sa = math.sin(angle)
    dx = x - px
    dy = y - py
    return px + dx * ca - dy * sa, py + dx * sa + dy * ca


def rotate_points(points, center=None):
    pivot = center or polygon_center(points)
    return [rotate_xy(x, y, pivot) for x, y in points]


def coord_rotated(x, y, center):
    xr, yr = rotate_xy(float(x), float(y), center)
    return {"x": xr, "y": yr}


def point3_rotated(x, y, z, center):
    xr, yr = rotate_xy(float(x), float(y), center)
    return {"x": xr, "y": yr, "z": float(z)}


def rect_polygon(x1, y1, x2, y2):
    return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, layer_name, group_nr, hidden=False):
    existing = find_layer_index(commands, types, layer_name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": layer_name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group_nr),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, layer_name)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {layer_name}")
    return created


def get_all_with_details(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    return elements, details


def move_layers_to_standby(commands, types, standby_index):
    layer_indices = {
        name: find_layer_index(commands, types, name)
        for name in OLD_LAYERS_TO_STANDBY
    }
    wanted = {idx for idx in layer_indices.values() if idx is not None}
    if not wanted:
        return {"movedCount": 0, "layers": layer_indices}

    elements, details = get_all_with_details(commands, types)
    to_move = []
    for element, detail in zip(elements, details):
        try:
            layer_index = int(detail.get("layerIndex", -999))
        except Exception:
            continue
        if layer_index in wanted:
            to_move.append(element)

    if not to_move:
        return {"movedCount": 0, "layers": layer_indices}

    result = tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": standby_index}}
                for element in to_move
            ]
        },
    )
    return {"movedCount": len(to_move), "layers": layer_indices, "result": result}


def count_elements_on_layer(commands, types, layer_index):
    elements, details = get_all_with_details(commands, types)
    count = 0
    for detail in details:
        try:
            count += int(detail.get("layerIndex", -1)) == int(layer_index)
        except Exception:
            pass
    return count


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": layer_index}}
                for element in elements
            ]
        },
    )


def roof_data():
    items = []
    for roof in ROOF_BLOCKS:
        center = polygon_center(roof["points"])
        items.append({
            "level": roof["level"],
            "thickness": roof["thickness"],
            "polygonCoordinates": [coord(x, y) for x, y in rotate_points(roof["points"], center)],
            "eavesOverhang": 0.18,
            "levels": [{"levelHeight": 0.0, "levelAngle": math.radians(roof["angle"])}],
        })
    return items


def add_beam(beams, x1, y1, x2, y2, z, width=0.08, height=0.055, center=None):
    if center is None:
        beg = coord(x1, y1)
        end = coord(x2, y2)
    else:
        beg = coord_rotated(x1, y1, center)
        end = coord_rotated(x2, y2, center)
    beams.append(
        {
            "begCoordinate": beg,
            "endCoordinate": end,
            "zCoordinate": float(z),
            "width": float(width),
            "height": float(height),
        }
    )


def build_roof_detail_beams():
    beams = []
    for roof in ROOF_BLOCKS:
        pts = roof["points"]
        center = polygon_center(pts)
        x1 = min(p[0] for p in pts)
        x2 = max(p[0] for p in pts)
        y1 = min(p[1] for p in pts)
        y2 = max(p[1] for p in pts)
        width_x = x2 - x1
        width_y = y2 - y1
        eave_z = roof["level"] + 0.12
        ridge_raise = min(width_x, width_y) * 0.45 * math.tan(math.radians(roof["angle"]))
        ridge_z = roof["level"] + 0.25 + ridge_raise

        if width_y >= width_x:
            xm = (x1 + x2) / 2.0
            add_beam(beams, xm, y1, xm, y2, ridge_z, width=0.11, height=0.08, center=center)
            # File di coppi indicative parallele alla linea di gronda.
            y = y1 + 2.6
            while y < y2 - 1.0:
                add_beam(beams, x1 + 0.25, y, x2 - 0.25, y, eave_z + 0.10, width=0.035, height=0.025, center=center)
                y += 3.2
        else:
            ym = (y1 + y2) / 2.0
            add_beam(beams, x1, ym, x2, ym, ridge_z, width=0.11, height=0.08, center=center)
            x = x1 + 2.6
            while x < x2 - 1.0:
                add_beam(beams, x, y1 + 0.25, x, y2 - 0.25, eave_z + 0.10, width=0.035, height=0.025, center=center)
                x += 3.2

        # Gonde continue senza sovraspessori eccessivi.
        add_beam(beams, x1, y1, x2, y1, eave_z, width=0.09, height=0.06, center=center)
        add_beam(beams, x1, y2, x2, y2, eave_z, width=0.09, height=0.06, center=center)
        add_beam(beams, x1, y1, x1, y2, eave_z, width=0.09, height=0.06, center=center)
        add_beam(beams, x2, y1, x2, y2, eave_z, width=0.09, height=0.06, center=center)
    return beams


def add_box(morphs, x, y, z, sx, sy, sz, center=None):
    base = point3_rotated(x, y, z, center) if center is not None else point3(x, y, z)
    morphs.append({"basePoint": base, "size": dim3(sx, sy, sz)})


def build_roof_morphs():
    morphs = []
    chimneys = [
        (-47.1, -58.0, 6.8), (-43.6, -35.5, 6.8), (-45.7, -8.0, 6.8),
        (-45.8, 20.5, 6.8), (-30.6, 25.0, 6.8), (-16.4, 10.5, 6.8),
        (-10.0, -47.0, 6.8), (-24.5, -62.8, 6.8), (-35.0, -22.0, 5.8),
        (-20.2, -34.0, 5.8),
    ]
    for x, y, z in chimneys:
        add_box(morphs, x - 0.18, y - 0.18, z, 0.36, 0.36, 0.95)
        add_box(morphs, x - 0.24, y - 0.24, z + 0.92, 0.48, 0.48, 0.12)
    return morphs


def build_court_slabs():
    return [
        {
            "level": 0.025,
            "thickness": 0.045,
            "polygonCoordinates": [coord(x, y) for x, y in rotate_points(polygon)],
        }
        for polygon in COURT_GREEN_POLYGONS
    ]


def build_court_beams():
    beams = []
    for polygon in COURT_GREEN_POLYGONS:
        center = polygon_center(polygon)
        pts = polygon + [polygon[0]]
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            add_beam(beams, x1, y1, x2, y2, 0.08, width=0.055, height=0.04, center=center)
    # Percorsi principali: diagonali e bordi leggeri, non rettangoli pieni.
    add_beam(beams, -38.2, -22.0, -18.2, -22.0, 0.09, width=0.08, height=0.045, center=(-28.2, -22.0))
    add_beam(beams, -32.7, 14.2, -22.0, 30.2, 0.09, width=0.055, height=0.035, center=(-27.4, 22.2))
    add_beam(beams, -22.0, 14.5, -32.0, 30.2, 0.09, width=0.055, height=0.035, center=(-27.0, 22.4))
    return beams


def build_court_morphs():
    morphs = []
    trees = [
        (-30.2, 17.5, 1.4), (-27.4, 22.4, 1.7), (-29.2, 27.0, 1.5),
        (-35.6, -42.0, 1.5), (-24.2, -45.0, 1.4), (-35.2, -30.4, 1.3),
    ]
    court_center = (-29.2, 0.0)
    for x, y, scale in trees:
        add_box(morphs, x - 0.12, y - 0.12, 0.00, 0.24, 0.24, 1.45 * scale, center=court_center)
        add_box(morphs, x - 0.85 * scale, y - 0.85 * scale, 1.05 * scale, 1.70 * scale, 1.70 * scale, 1.20 * scale, center=court_center)
    # Vasi lungo il loggiato, meno invasivi della passata precedente.
    for x, y in [(-32.3, 15.1), (-32.3, 19.1), (-32.2, 23.2), (-32.0, 27.2)]:
        add_box(morphs, x - 0.18, y - 0.18, 0.00, 0.36, 0.36, 0.32, center=(-32.1, 21.2))
        add_box(morphs, x - 0.28, y - 0.28, 0.30, 0.56, 0.56, 0.30, center=(-32.1, 21.2))
    return morphs


def build_street_morphs():
    morphs = []
    # Cancello e recinzione sull'ingresso storico.
    gate_y = -72.63
    gate_center = (-31.35, gate_y)
    add_box(morphs, -34.4, gate_y, 0.00, 0.45, 0.45, 2.05, center=gate_center)
    add_box(morphs, -28.3, gate_y, 0.00, 0.45, 0.45, 2.05, center=gate_center)
    for i in range(12):
        add_box(morphs, -33.8 + i * 0.48, gate_y - 0.02, 0.38, 0.045, 0.10, 1.38, center=gate_center)
    # Alberature ai lati dell'ingresso, come nella vista Google.
    add_box(morphs, -38.7, -69.8, 0.00, 0.32, 0.32, 2.3, center=gate_center)
    add_box(morphs, -40.0, -71.0, 2.05, 2.6, 2.6, 2.1, center=gate_center)
    add_box(morphs, -20.3, -70.5, 0.00, 0.30, 0.30, 2.4, center=gate_center)
    add_box(morphs, -21.5, -71.7, 2.10, 2.5, 2.5, 2.0, center=gate_center)
    return morphs


def build_street_slabs():
    street_polygons = [
        # Via Berra davanti al fronte principale.
        rect_polygon(-52.2, -76.75, -5.7, -72.50),
        # Marciapiede aderente al fronte.
        rect_polygon(-52.2, -72.55, -5.7, -71.95),
        # Tratto laterale di via Domenico Berra visto nella foto zenitale.
        rect_polygon(-54.70, -71.90, -50.55, 32.10),
        # Marciapiede lungo la manica ovest.
        rect_polygon(-50.70, -71.90, -50.05, 32.10),
    ]
    return [
        {
            "level": -0.06,
            "thickness": 0.055,
            "polygonCoordinates": [coord(x, y) for x, y in rotate_points(polygon)],
        }
        for polygon in street_polygons
    ]


def build_street_beams():
    beams = []
    gate_y = -72.63
    gate_center = (-31.35, gate_y)
    add_beam(beams, -34.0, gate_y + 0.02, -28.3, gate_y + 0.02, 0.35, width=0.07, height=0.055, center=gate_center)
    add_beam(beams, -34.0, gate_y + 0.02, -28.3, gate_y + 0.02, 1.75, width=0.07, height=0.055, center=gate_center)
    add_beam(beams, -52.0, -72.35, -35.0, -72.35, 0.55, width=0.08, height=0.05, center=(-43.5, -72.35))
    add_beam(beams, -27.8, -72.35, -6.0, -72.35, 0.55, width=0.08, height=0.05, center=(-16.9, -72.35))
    return beams


def create_elements(commands, types, layer_index, command_name, payload_key, payload_data):
    result = tapir(commands, types, command_name, {payload_key: payload_data})
    elements = result.get("elements", [])
    layer_result = set_elements_layer(commands, types, elements, layer_index)
    return {"requested": len(payload_data), "created": len(elements), "result": result, "layerResult": layer_result}


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Correzione Google Earth per modello Berra.")
        print("Uso: py 39_tapir_google_earth_correzione_berra.py APPLICA")
        print("Per rilanciare sui layer gia popolati: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types

    standby_index = create_or_get_layer(commands, types, STANDBY_LAYER, 120, hidden=True)
    roof_index = create_or_get_layer(commands, types, LAYER_ROOFS, 121)
    court_index = create_or_get_layer(commands, types, LAYER_COURTS, 122)
    street_index = create_or_get_layer(commands, types, LAYER_STREET, 123)
    detail_index = create_or_get_layer(commands, types, LAYER_DETAILS, 124)

    existing_ge = {
        LAYER_ROOFS: count_elements_on_layer(commands, types, roof_index),
        LAYER_COURTS: count_elements_on_layer(commands, types, court_index),
        LAYER_STREET: count_elements_on_layer(commands, types, street_index),
        LAYER_DETAILS: count_elements_on_layer(commands, types, detail_index),
    }
    if any(existing_ge.values()) and not force:
        print("Layer Google Earth gia popolati. Nessuna modifica.")
        print(existing_ge)
        print("Usa: py 39_tapir_google_earth_correzione_berra.py APPLICA FORZA")
        return

    standby_result = move_layers_to_standby(commands, types, standby_index)

    try:
        tapir(commands, types, "ApplyFavoritesToElementDefaults", {"favorites": ["Falda Spiovente - Tegole"]})
    except Exception:
        pass

    roof_result = create_elements(commands, types, roof_index, "CreateRoofs", "roofsData", roof_data())
    roof_beams_result = create_elements(commands, types, detail_index, "CreateBeams", "beamsData", build_roof_detail_beams())
    roof_morphs_result = create_elements(commands, types, detail_index, "CreateMorphs", "morphsData", build_roof_morphs())
    court_slabs_result = create_elements(commands, types, court_index, "CreateSlabs", "slabsData", build_court_slabs())
    court_beams_result = create_elements(commands, types, court_index, "CreateBeams", "beamsData", build_court_beams())
    court_morphs_result = create_elements(commands, types, court_index, "CreateMorphs", "morphsData", build_court_morphs())
    street_slabs_result = create_elements(commands, types, street_index, "CreateSlabs", "slabsData", build_street_slabs())
    street_beams_result = create_elements(commands, types, street_index, "CreateBeams", "beamsData", build_street_beams())
    street_morphs_result = create_elements(commands, types, street_index, "CreateMorphs", "morphsData", build_street_morphs())

    output = {
        "standbyLayer": {"name": STANDBY_LAYER, "index": standby_index, "moveResult": standby_result},
        "layers": {
            LAYER_ROOFS: roof_index,
            LAYER_COURTS: court_index,
            LAYER_STREET: street_index,
            LAYER_DETAILS: detail_index,
        },
        "created": {
            "roofs": roof_result,
            "roofBeams": roof_beams_result,
            "roofMorphs": roof_morphs_result,
            "courtSlabs": court_slabs_result,
            "courtBeams": court_beams_result,
            "courtMorphs": court_morphs_result,
            "streetSlabs": street_slabs_result,
            "streetBeams": street_beams_result,
            "streetMorphs": street_morphs_result,
        },
    }
    OUT_JSON.write_text(json.dumps(output, indent=2), encoding="utf-8")

    print("Correzione Google Earth applicata.")
    print(f"Elementi spostati in stand-by: {standby_result.get('movedCount', 0)}")
    print(f"Coperture create: {roof_result['created']}")
    print(f"Dettagli tetto/trame create: {roof_beams_result['created'] + roof_morphs_result['created']}")
    print(f"Corte/verde create: {court_slabs_result['created'] + court_beams_result['created'] + court_morphs_result['created']}")
    print(f"Strada/ingresso creati: {street_slabs_result['created'] + street_beams_result['created'] + street_morphs_result['created']}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
