from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import ezdxf


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
DWG_OUT = ROOT / "output_berra_dwg_struttura_110626"
IFC_OUT = ROOT / "output_berra_v17_ufficiale_pipeline"
V20_OUT = ROOT / "output_berra_v20_falde_pln"
OUT = ROOT / "output_berra_v21_calibrazione_dwg"

DWG_SEGMENTS = DWG_OUT / "dwg_struttura_110626_flat_segments.csv"
IFC_ROOF_FACES = IFC_OUT / "berra_v17_ufficiale_ifc_roof_faces.csv"
V20_AXES = V20_OUT / "berra_v20_assi_falde_pln_allineati.csv"
CALIBRATION = OUT / "v21_candidati_calibrazione.csv"


def read_calibration(candidate="D_similitudine_ottimizzata"):
    with CALIBRATION.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            if r["candidate"] == candidate:
                return {
                    "dx": float(r["dx"]),
                    "dy": float(r["dy"]),
                    "rot_deg": float(r["rot_deg"]),
                    "scale": float(r["scale"]) if r["scale"] else 1.0,
                    "sx": float(r["sx"]) if r["sx"] else None,
                    "sy": float(r["sy"]) if r["sy"] else None,
                    "center": None,
                }
    raise RuntimeError(f"Candidato non trovato: {candidate}")


def bbox_points(points):
    return min(p[0] for p in points), min(p[1] for p in points), max(p[0] for p in points), max(p[1] for p in points)


def centroid(b):
    return (b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0


def transform_point(p, t):
    x, y = p
    cx, cy = t["center"]
    x -= cx
    y -= cy
    sx = t["sx"] if t["sx"] is not None else t["scale"]
    sy = t["sy"] if t["sy"] is not None else t["scale"]
    x *= sx
    y *= sy
    a = math.radians(t["rot_deg"])
    ca = math.cos(a)
    sa = math.sin(a)
    xr = x * ca - y * sa
    yr = x * sa + y * ca
    return xr + cx + t["dx"], yr + cy + t["dy"]


def read_dwg_segments():
    rows = []
    with DWG_SEGMENTS.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            length = float(r["length"])
            if length < 0.05:
                continue
            rows.append(
                {
                    "layer": r["layer"],
                    "type": r["type"],
                    "x1": float(r["x1"]),
                    "y1": float(r["y1"]),
                    "x2": float(r["x2"]),
                    "y2": float(r["y2"]),
                    "length": length,
                }
            )
    return rows


def read_ifc_edges():
    edges = []
    with IFC_ROOF_FACES.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=";")
        for r in reader:
            pts3 = json.loads(r["points"])
            pts = [(float(p[0]), float(p[1])) for p in pts3]
            for a, b in zip(pts, pts[1:] + pts[:1]):
                length = math.hypot(b[0] - a[0], b[1] - a[1])
                if length > 0.05:
                    edges.append({"roof_id": r["roof_id"], "x1": a[0], "y1": a[1], "x2": b[0], "y2": b[1], "length": length})
    return edges


def read_v20_axes():
    axes = []
    if not V20_AXES.exists():
        return axes
    with V20_AXES.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f, delimiter=";"):
            x0 = float(r["x0"])
            y0 = float(r["y0"])
            x1 = float(r["x1"])
            y1 = float(r["y1"])
            axes.append({"code": r["code"], "x1": x0, "y1": y0, "x2": x1, "y2": y1})
    return axes


def add_line(msp, layer, x1, y1, x2, y2, color=None):
    e = msp.add_line((x1, y1, 0), (x2, y2, 0), dxfattribs={"layer": layer})
    if color is not None:
        e.dxf.color = color


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    dwg = read_dwg_segments()
    ifc = read_ifc_edges()
    v20 = read_v20_axes()
    tr = read_calibration()
    ifc_points = [(s["x1"], s["y1"]) for s in ifc] + [(s["x2"], s["y2"]) for s in ifc]
    tr["center"] = centroid(bbox_points(ifc_points))

    doc = ezdxf.new("R2018")
    msp = doc.modelspace()
    layers = {
        "V21_DWG_STRUTTURA_BASE": 7,
        "V21_DWG_CONTESTO": 8,
        "V21_IFC_FALDE_NATIVE": 1,
        "V21_IFC_FALDE_D_CALIBRATA": 1,
        "V21_ASSI_V20_D_CALIBRATI": 4,
    }
    for name, color in layers.items():
        doc.layers.add(name=name, color=color)

    for s in dwg:
        layer = "V21_DWG_STRUTTURA_BASE" if ("strutturale" in s["layer"].lower() or "portante" in s["layer"].lower()) else "V21_DWG_CONTESTO"
        add_line(msp, layer, s["x1"], s["y1"], s["x2"], s["y2"])

    for s in ifc:
        add_line(msp, "V21_IFC_FALDE_NATIVE", s["x1"], s["y1"], s["x2"], s["y2"])
        a = transform_point((s["x1"], s["y1"]), tr)
        b = transform_point((s["x2"], s["y2"]), tr)
        add_line(msp, "V21_IFC_FALDE_D_CALIBRATA", a[0], a[1], b[0], b[1])

    for s in v20:
        a = transform_point((s["x1"], s["y1"]), tr)
        b = transform_point((s["x2"], s["y2"]), tr)
        add_line(msp, "V21_ASSI_V20_D_CALIBRATI", a[0], a[1], b[0], b[1])

    out_dxf = OUT / "v21_confronto_dwg_ifc_assi_calibrati.dxf"
    doc.saveas(out_dxf)
    print(f"Creato: {out_dxf}")
    print("Layer: " + ", ".join(layers.keys()))


if __name__ == "__main__":
    main()
