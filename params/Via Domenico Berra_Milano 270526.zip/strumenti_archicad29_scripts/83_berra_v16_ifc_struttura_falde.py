from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import ifcopenshell
import ifcopenshell.api.aggregate
import ifcopenshell.api.context
import ifcopenshell.api.geometry
import ifcopenshell.api.layer
import ifcopenshell.api.project
import ifcopenshell.api.pset
import ifcopenshell.api.root
import ifcopenshell.api.spatial
import ifcopenshell.api.unit
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
PIPELINE_DIR = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "output_berra_falde_ifc_pipeline"
FACES_CSV = PIPELINE_DIR / "berra_v15_falde_filtrate.csv"
GUIDES_CSV = PIPELINE_DIR / "berra_v15_guide_strutturali_falde.csv"
OUT_IFC = PIPELINE_DIR / "berra_v16_struttura_coperture_ifc.ifc"
OUT_CSV = PIPELINE_DIR / "berra_v16_struttura_coperture_computo.csv"
OUT_XLSX = PIPELINE_DIR / "berra_v16_struttura_coperture_computo.xlsx"
OUT_REPORT = PIPELINE_DIR / "berra_v16_struttura_coperture_report.txt"


ROLE_DATA = {
    "assito_travicelli_falda": {
        "prefix": "TRV",
        "layer": "BERRA_V16_ASSITO_TRAVICELLI",
        "name": "Travicello / assito su falda",
        "width": 0.055,
        "height": 0.075,
        "offset": 0.055,
        "ifc_class": "IfcBeam",
        "predefined_type": "JOIST",
    },
    "arcarecci_correnti_falda": {
        "prefix": "ARC",
        "layer": "BERRA_V16_ARCARECCI_CORRENTI",
        "name": "Arcareccio / corrente su falda",
        "width": 0.115,
        "height": 0.155,
        "offset": 0.095,
        "ifc_class": "IfcBeam",
        "predefined_type": "BEAM",
    },
    "capriate_linea_controllo": {
        "prefix": "CAP",
        "layer": "BERRA_V16_CAPRIATE_CONTROLLO",
        "name": "Capriata - linea primaria di controllo",
        "width": 0.140,
        "height": 0.180,
        "offset": 0.140,
        "ifc_class": "IfcBeam",
        "predefined_type": "BEAM",
    },
}


@dataclass(frozen=True)
class FaceRef:
    roof_id: str
    face_no: int
    normal: tuple[float, float, float]


@dataclass(frozen=True)
class BeamRow:
    code: str
    role: str
    roof_id: str
    face_no: int
    p1: tuple[float, float, float]
    p2: tuple[float, float, float]
    normal: tuple[float, float, float]
    length: float
    width: float
    height: float
    volume: float


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def norm(a):
    length = math.sqrt(dot(a, a))
    if length <= 1e-12:
        return (0.0, 0.0, 0.0)
    return (a[0] / length, a[1] / length, a[2] / length)


def length3(a, b):
    return math.sqrt(dot(sub(a, b), sub(a, b)))


def read_face_normals():
    refs: dict[tuple[str, int], FaceRef] = {}
    with FACES_CSV.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            roof_id = row["roof_id"]
            face_no = int(row["face_no"])
            normal = (
                float(row["normal_x"]),
                float(row["normal_y"]),
                float(row["normal_z"]),
            )
            refs[(roof_id, face_no)] = FaceRef(roof_id, face_no, norm(normal))
    return refs


def read_guides():
    face_refs = read_face_normals()
    counters = Counter()
    rows: list[BeamRow] = []
    with GUIDES_CSV.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            role = row["role"]
            if role not in ROLE_DATA:
                continue
            roof_id = row["roof_id"]
            face_no = int(row["face_no"])
            face_ref = face_refs.get((roof_id, face_no))
            if face_ref is None:
                continue
            p1 = (float(row["x1"]), float(row["y1"]), float(row["z1"]))
            p2 = (float(row["x2"]), float(row["y2"]), float(row["z2"]))
            length = length3(p1, p2)
            if length < 0.60:
                continue
            spec = ROLE_DATA[role]
            counters[role] += 1
            code = f"BERRA-STR-{spec['prefix']}-{counters[role]:04d}"
            width = spec["width"]
            height = spec["height"]
            offset = spec["offset"]
            normal = face_ref.normal if face_ref.normal[2] >= 0 else mul(face_ref.normal, -1.0)
            rows.append(
                BeamRow(
                    code=code,
                    role=role,
                    roof_id=roof_id,
                    face_no=face_no,
                    p1=add(p1, mul(normal, offset)),
                    p2=add(p2, mul(normal, offset)),
                    normal=normal,
                    length=length,
                    width=width,
                    height=height,
                    volume=length * width * height,
                )
            )
    return rows


def prism_vertices_faces(p1, p2, normal, width, height):
    x_axis = norm(sub(p2, p1))
    z_axis = norm(normal)
    if dot(z_axis, z_axis) <= 1e-12 or abs(dot(x_axis, z_axis)) > 0.97:
        z_axis = (0.0, 0.0, 1.0)
    y_axis = norm(cross(z_axis, x_axis))
    if dot(y_axis, y_axis) <= 1e-12:
        y_axis = norm(cross((0.0, 0.0, 1.0), x_axis))
    z_axis = norm(cross(x_axis, y_axis))

    hy = width / 2.0
    hz = height / 2.0
    offsets = [
        add(mul(y_axis, -hy), mul(z_axis, -hz)),
        add(mul(y_axis, hy), mul(z_axis, -hz)),
        add(mul(y_axis, hy), mul(z_axis, hz)),
        add(mul(y_axis, -hy), mul(z_axis, hz)),
    ]
    vertices = [add(p1, off) for off in offsets] + [add(p2, off) for off in offsets]
    faces = [
        [0, 1, 2, 3],
        [4, 7, 6, 5],
        [0, 4, 5, 1],
        [1, 5, 6, 2],
        [2, 6, 7, 3],
        [3, 7, 4, 0],
    ]
    return vertices, faces


def create_project():
    model = ifcopenshell.api.project.create_file(version="IFC4")
    project = ifcopenshell.api.root.create_entity(model, ifc_class="IfcProject", name="Via Berra 10 - struttura coperture V16")
    ifcopenshell.api.unit.assign_unit(model, length={"is_metric": True, "raw": "METERS"})
    model_context = ifcopenshell.api.context.add_context(model, context_type="Model")
    body_context = ifcopenshell.api.context.add_context(
        model,
        context_type="Model",
        context_identifier="Body",
        target_view="MODEL_VIEW",
        parent=model_context,
    )
    site = ifcopenshell.api.root.create_entity(model, ifc_class="IfcSite", name="Via Domenico Berra 10/12/14 Milano")
    building = ifcopenshell.api.root.create_entity(model, ifc_class="IfcBuilding", name="Complesso edilizio Via Berra")
    storey = ifcopenshell.api.root.create_entity(model, ifc_class="IfcBuildingStorey", name="Coperture e strutture lignee")
    for product in (site, building, storey):
        ifcopenshell.api.geometry.edit_object_placement(model, product=product, matrix=np.eye(4))
    ifcopenshell.api.aggregate.assign_object(model, products=[site], relating_object=project)
    ifcopenshell.api.aggregate.assign_object(model, products=[building], relating_object=site)
    ifcopenshell.api.aggregate.assign_object(model, products=[storey], relating_object=building)
    layers = {role: ifcopenshell.api.layer.add_layer(model, name=spec["layer"]) for role, spec in ROLE_DATA.items()}
    return model, body_context, storey, layers


def add_structural_element(model, body_context, storey, layers, row: BeamRow):
    spec = ROLE_DATA[row.role]
    product = ifcopenshell.api.root.create_entity(
        model,
        ifc_class=spec["ifc_class"],
        predefined_type=spec["predefined_type"],
        name=row.code,
    )
    product.ObjectType = spec["name"]
    product.Tag = row.code
    ifcopenshell.api.geometry.edit_object_placement(model, product=product, matrix=np.eye(4))
    vertices, faces = prism_vertices_faces(row.p1, row.p2, row.normal, row.width, row.height)
    representation = ifcopenshell.api.geometry.add_mesh_representation(
        model,
        context=body_context,
        vertices=[vertices],
        faces=[faces],
        force_faceted_brep=True,
    )
    ifcopenshell.api.layer.assign_layer(model, items=[representation], layer=layers[row.role])
    ifcopenshell.api.geometry.assign_representation(model, product=product, representation=representation)
    ifcopenshell.api.spatial.assign_container(model, products=[product], relating_structure=storey)

    pset = ifcopenshell.api.pset.add_pset(model, product=product, name="Pset_MCA_Berra")
    ifcopenshell.api.pset.edit_pset(
        model,
        pset=pset,
        properties={
            "Codice_ID": row.code,
            "Ruolo": row.role,
            "Descrizione": spec["name"],
            "Copertura_Origine": row.roof_id,
            "Falda_Origine": row.face_no,
            "Lunghezza_m": round(row.length, 4),
            "Sezione_Larghezza_m": row.width,
            "Sezione_Altezza_m": row.height,
            "Volume_m3": round(row.volume, 5),
            "Metodo": "Generato da falde IFC correnti V15",
        },
    )
    qto = ifcopenshell.api.pset.add_qto(model, product=product, name="Qto_MCA_Berra_Struttura")
    ifcopenshell.api.pset.edit_qto(
        model,
        qto=qto,
        properties={
            "Length": row.length,
            "GrossVolume": row.volume,
        },
    )
    return product


def computo_records(rows: list[BeamRow]):
    records = []
    for row in rows:
        spec = ROLE_DATA[row.role]
        records.append(
            {
                "codice_id": row.code,
                "ruolo": row.role,
                "layer_ifc": spec["layer"],
                "descrizione": spec["name"],
                "copertura_origine": row.roof_id,
                "falda_origine": row.face_no,
                "lunghezza_m": round(row.length, 4),
                "larghezza_m": row.width,
                "altezza_m": row.height,
                "volume_m3": round(row.volume, 5),
                "x1": round(row.p1[0], 4),
                "y1": round(row.p1[1], 4),
                "z1": round(row.p1[2], 4),
                "x2": round(row.p2[0], 4),
                "y2": round(row.p2[1], 4),
                "z2": round(row.p2[2], 4),
            }
        )
    return records


def write_computo(rows: list[BeamRow]):
    records = computo_records(rows)
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "codice_id",
            "ruolo",
            "layer_ifc",
            "descrizione",
            "copertura_origine",
            "falda_origine",
            "lunghezza_m",
            "larghezza_m",
            "altezza_m",
            "volume_m3",
            "x1",
            "y1",
            "z1",
            "x2",
            "y2",
            "z2",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(records)

    frame = pd.DataFrame(records)
    summary_role = (
        frame.groupby(["ruolo", "layer_ifc", "descrizione"], as_index=False)
        .agg(elementi=("codice_id", "count"), lunghezza_m=("lunghezza_m", "sum"), volume_m3=("volume_m3", "sum"))
        .sort_values("ruolo")
    )
    summary_roof = (
        frame.groupby(["copertura_origine", "ruolo"], as_index=False)
        .agg(elementi=("codice_id", "count"), lunghezza_m=("lunghezza_m", "sum"), volume_m3=("volume_m3", "sum"))
        .sort_values(["copertura_origine", "ruolo"])
    )
    with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
        frame.to_excel(writer, sheet_name="Elementi", index=False)
        summary_role.to_excel(writer, sheet_name="Sintesi ruolo", index=False)
        summary_roof.to_excel(writer, sheet_name="Sintesi copertura", index=False)


def write_report(rows: list[BeamRow]):
    by_role = Counter(row.role for row in rows)
    length_by_role = Counter()
    volume_by_role = Counter()
    by_roof = Counter(row.roof_id for row in rows)
    for row in rows:
        length_by_role[row.role] += row.length
        volume_by_role[row.role] += row.volume
    lines = [
        "BERRA V16 - IFC STRUTTURA COPERTURE",
        "=" * 42,
        "Questo passaggio NON modifica il file PLN.",
        f"IFC generato: {OUT_IFC}",
        f"CSV computo: {OUT_CSV}",
        f"XLSX computo: {OUT_XLSX}",
        f"Elementi strutturali: {len(rows)}",
        "",
        "Per ruolo:",
    ]
    for role in sorted(by_role):
        lines.append(
            f"- {role}: {by_role[role]} elementi, {length_by_role[role]:.2f} m, {volume_by_role[role]:.3f} m3"
        )
    lines.extend(["", "Per copertura origine:"])
    for roof_id, count in sorted(by_roof.items()):
        lines.append(f"- {roof_id}: {count} elementi")
    lines.extend(
        [
            "",
            "Uso consigliato:",
            "1. Importare/merge l'IFC in Archicad come riferimento separato.",
            "2. Verificare allineamento su falde corrette.",
            "3. Solo dopo validazione convertire o sostituire con elementi/librerie definitive.",
        ]
    )
    OUT_REPORT.write_text("\n".join(lines), encoding="utf-8")


def main():
    PIPELINE_DIR.mkdir(parents=True, exist_ok=True)
    rows = read_guides()
    model, body_context, storey, layers = create_project()
    for row in rows:
        add_structural_element(model, body_context, storey, layers, row)
    model.write(str(OUT_IFC))
    write_computo(rows)
    write_report(rows)
    print(OUT_IFC)
    print(f"Elementi: {len(rows)}")


if __name__ == "__main__":
    main()
