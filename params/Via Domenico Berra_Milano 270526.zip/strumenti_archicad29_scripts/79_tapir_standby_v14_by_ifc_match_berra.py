from __future__ import annotations

import importlib.util
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


STANDBY_LAYER = "BERRA_STANDBY_REVISIONE_STRUTTURE_FINITURE"
V14_SCRIPT = Path(__file__).with_name("77_tapir_v14_strisce_falde_ifc_berra.py")
OUT_TXT = Path(r"E:\strumenti-archicad29\berra_standby_v14_by_ifc_match_report.txt")
OUT_JSON = Path(r"E:\strumenti-archicad29\berra_standby_v14_by_ifc_match_result.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def load_v14_module():
    spec = importlib.util.spec_from_file_location("v14", V14_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Impossibile caricare {V14_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bbox_of_points(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    zs = [p[2] for p in points]
    return {
        "xMin": min(xs),
        "xMax": max(xs),
        "yMin": min(ys),
        "yMax": max(ys),
        "zMax": max(zs),
    }


def predicted_bboxes():
    v14 = load_v14_module()
    faces = v14.read_roof_faces()
    strips = v14.build_strips(faces)
    return [bbox_of_points(item["points"]) for item in strips]


def matches_prediction(box, predictions):
    ax1 = float(box.get("xMin", 0.0))
    ax2 = float(box.get("xMax", 0.0))
    ay1 = float(box.get("yMin", 0.0))
    ay2 = float(box.get("yMax", 0.0))
    az2 = float(box.get("zMax", 0.0))
    for pred in predictions:
        dx = max(abs(ax1 - pred["xMin"]), abs(ax2 - pred["xMax"]))
        dy = max(abs(ay1 - pred["yMin"]), abs(ay2 - pred["yMax"]))
        dz = abs(az2 - pred["zMax"])
        if dx <= 0.08 and dy <= 0.08 and dz <= 0.18:
            return True
    return False


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_standby_layer(commands, types):
    existing = find_layer_index(commands, types, STANDBY_LAYER)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": STANDBY_LAYER,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 190,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, STANDBY_LAYER)
    if created is None:
        raise RuntimeError(f"Layer non creato: {STANDBY_LAYER}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Mette in stand-by solo le Mesh che combaciano con le strisce V14 previste da IFC.")
        print("Uso: py 79_tapir_standby_v14_by_ifc_match_berra.py APPLICA")
        return

    predictions = predicted_bboxes()
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby_index = create_or_get_standby_layer(commands, types)
    layers = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])

    matched = []
    scanned_meshes = 0
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Mesh":
            continue
        scanned_meshes += 1
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        if layer == STANDBY_LAYER:
            continue
        box = box_item.get("boundingBox3D", {})
        if matches_prediction(box, predictions):
            matched.append(
                {
                    "element": element,
                    "id": detail.get("id", ""),
                    "layer": layer,
                    "guid": element.get("elementId", {}).get("guid", ""),
                    "box": {key: round(float(box.get(key, 0.0)), 4) for key in ("xMin", "xMax", "yMin", "yMax", "zMin", "zMax")},
                }
            )

    if matched:
        result = tapir(
            commands,
            types,
            "SetDetailsOfElements",
            {
                "elementsWithDetails": [
                    {"elementId": row["element"]["elementId"], "details": {"layerIndex": standby_index}}
                    for row in matched
                ]
            },
        )
    else:
        result = None

    payload = {
        "predictedV14Strips": len(predictions),
        "scannedMeshes": scanned_meshes,
        "matchedMoved": len(matched),
        "byLayer": dict(Counter(row["layer"] for row in matched)),
        "standbyLayer": STANDBY_LAYER,
        "standbyIndex": standby_index,
        "matched": [{key: value for key, value in row.items() if key != "element"} for row in matched],
        "result": result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - STAND-BY V14 BY IFC MATCH",
                "=" * 42,
                f"Strisce V14 previste: {len(predictions)}",
                f"Mesh controllate: {scanned_meshes}",
                f"Mesh combacianti spostate: {len(matched)}",
                "Per layer origine:",
                *(f"- {layer}: {count}" for layer, count in sorted(payload["byLayer"].items())),
            ]
        ),
        encoding="utf-8",
    )
    print(f"Mesh V14 spostate in stand-by: {len(matched)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
