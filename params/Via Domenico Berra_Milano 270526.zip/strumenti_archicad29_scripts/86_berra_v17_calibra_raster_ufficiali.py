from __future__ import annotations

import ast
import csv
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
BASE = Path(r"E:\Project_berra_Prova 04 100626\CARTELLA BERRA_100626\COSTRUZIONE_100625")
PIPELINE = ROOT / "output_berra_v17_ufficiale_pipeline"

FACES_CSV = PIPELINE / "berra_v17_ufficiale_ifc_roof_faces.csv"
OUT_CSV = PIPELINE / "berra_v17_calibrazione_raster_bbox.csv"
OUT_MD = PIPELINE / "berra_v17_calibrazione_raster_report.md"

RASTERS = [
    ("pianta_quote", BASE / r"02_PLANIMETRIE\PIANTA CON QUOTE-1.jpg"),
    ("piano_terreno", BASE / r"02_PLANIMETRIE\BERRA PIANO TERRENO.jpg"),
    ("piano_primo", BASE / r"02_PLANIMETRIE\BERRA PIANO PRIMO.jpg"),
    ("piano_sottotetto", BASE / r"02_PLANIMETRIE\BERRA PIANO SOTTOTETTO.jpg"),
    ("planimetria_capriate", BASE / r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\PLANIMETRIA CAPRIATE.jpg"),
    ("planimetria_tetti", BASE / r"03_SEZIONI DETTAGLI\CAPRIATE TRAVI\PLANIMETRIA TETTI.jpg"),
]


def parse_points(value: str) -> list[tuple[float, float, float]]:
    data = ast.literal_eval(value)
    return [(float(x), float(y), float(z)) for x, y, z in data]


def read_model_bbox() -> dict[str, float]:
    xs: list[float] = []
    ys: list[float] = []
    zs: list[float] = []
    with FACES_CSV.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        for row in reader:
            for x, y, z in parse_points(row["points"]):
                xs.append(x)
                ys.append(y)
                zs.append(z)
    return {
        "model_min_x": min(xs),
        "model_max_x": max(xs),
        "model_min_y": min(ys),
        "model_max_y": max(ys),
        "model_min_z": min(zs),
        "model_max_z": max(zs),
        "model_w": max(xs) - min(xs),
        "model_h": max(ys) - min(ys),
    }


def dark_bbox(image: Image.Image, label: str) -> dict[str, int | float | str]:
    gray = image.convert("L")
    w, h = gray.size
    px = gray.load()

    # Ignore page borders and titles. The crop is intentionally conservative:
    # it finds a usable registration envelope, not the final architectural outline.
    margin_x = int(w * 0.08)
    margin_y = int(h * 0.05)
    min_x, min_y = w, h
    max_x, max_y = 0, 0
    count = 0

    for y in range(margin_y, h - margin_y):
        for x in range(margin_x, w - margin_x):
            value = px[x, y]
            if value < 178:
                min_x = min(min_x, x)
                min_y = min(min_y, y)
                max_x = max(max_x, x)
                max_y = max(max_y, y)
                count += 1

    if count == 0:
        return {
            "label": label,
            "img_w": w,
            "img_h": h,
            "ink_px": 0,
            "bbox_x0": "",
            "bbox_y0": "",
            "bbox_x1": "",
            "bbox_y1": "",
            "bbox_w": "",
            "bbox_h": "",
            "bbox_ratio": "",
        }

    bw = max_x - min_x
    bh = max_y - min_y
    return {
        "label": label,
        "img_w": w,
        "img_h": h,
        "ink_px": count,
        "bbox_x0": min_x,
        "bbox_y0": min_y,
        "bbox_x1": max_x,
        "bbox_y1": max_y,
        "bbox_w": bw,
        "bbox_h": bh,
        "bbox_ratio": round(bw / bh, 6) if bh else "",
    }


def save_preview(label: str, image: Image.Image, bbox: dict[str, int | float | str]) -> Path:
    preview = ImageOps.exif_transpose(image).convert("RGB")
    preview.thumbnail((1100, 1500), Image.Resampling.LANCZOS)
    scale_x = preview.width / image.width
    scale_y = preview.height / image.height
    draw = ImageDraw.Draw(preview)

    if bbox["ink_px"]:
        x0 = int(float(bbox["bbox_x0"]) * scale_x)
        y0 = int(float(bbox["bbox_y0"]) * scale_y)
        x1 = int(float(bbox["bbox_x1"]) * scale_x)
        y1 = int(float(bbox["bbox_y1"]) * scale_y)
        draw.rectangle([x0, y0, x1, y1], outline=(220, 35, 35), width=4)
        draw.text((x0 + 8, y0 + 8), "bbox lettura raster", fill=(220, 35, 35))

    out = PIPELINE / f"berra_v17_calibrazione_{label}.jpg"
    preview.save(out, quality=90)
    return out


def main() -> None:
    PIPELINE.mkdir(parents=True, exist_ok=True)
    model = read_model_bbox()
    rows: list[dict[str, str | int | float]] = []
    previews: list[Path] = []

    for label, path in RASTERS:
        image = ImageOps.exif_transpose(Image.open(path))
        bbox = dark_bbox(image, label)
        previews.append(save_preview(label, image, bbox))

        row: dict[str, str | int | float] = dict(bbox)
        row["path"] = str(path)
        if bbox["ink_px"] and bbox["bbox_w"] and bbox["bbox_h"]:
            sx = model["model_w"] / float(bbox["bbox_w"])
            sy = model["model_h"] / float(bbox["bbox_h"])
            row["approx_m_per_px_x_by_roof_bbox"] = round(sx, 6)
            row["approx_m_per_px_y_by_roof_bbox"] = round(sy, 6)
            row["approx_scale_error_pct"] = round(abs(sx - sy) / max(sx, sy) * 100.0, 2) if max(sx, sy) else ""
        else:
            row["approx_m_per_px_x_by_roof_bbox"] = ""
            row["approx_m_per_px_y_by_roof_bbox"] = ""
            row["approx_scale_error_pct"] = ""
        rows.append(row)

    fieldnames = [
        "label",
        "path",
        "img_w",
        "img_h",
        "ink_px",
        "bbox_x0",
        "bbox_y0",
        "bbox_x1",
        "bbox_y1",
        "bbox_w",
        "bbox_h",
        "bbox_ratio",
        "approx_m_per_px_x_by_roof_bbox",
        "approx_m_per_px_y_by_roof_bbox",
        "approx_scale_error_pct",
    ]
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    lines = [
        "# Berra V17 - calibrazione raster ufficiali",
        "",
        "Questa verifica non modifica Archicad.",
        "",
        "## BBox modello V03 da IFC ufficiale",
        "",
        f"- X: {model['model_min_x']:.3f} / {model['model_max_x']:.3f} m, larghezza {model['model_w']:.3f} m",
        f"- Y: {model['model_min_y']:.3f} / {model['model_max_y']:.3f} m, altezza {model['model_h']:.3f} m",
        f"- Z: {model['model_min_z']:.3f} / {model['model_max_z']:.3f} m",
        "",
        "## Output",
        "",
        f"- `{OUT_CSV.name}`",
    ]
    for preview in previews:
        lines.append(f"- `{preview.name}`")
    lines.extend(
        [
            "",
            "## Lettura",
            "",
            "Le anteprime mostrano in rosso il bounding box dei pixel scuri interni.",
            "Questo non e ancora un allineamento finale: serve a individuare quali raster sono abbastanza puliti per essere registrati sul V03.",
            "Il posizionamento finale delle capriate deve essere eseguito sulla planimetria capriate calibrata su punti comuni, non su una semplice bbox.",
        ]
    )
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Creato: {OUT_CSV}")
    print(f"Creato: {OUT_MD}")
    for preview in previews:
        print(f"Anteprima: {preview}")


if __name__ == "__main__":
    main()

