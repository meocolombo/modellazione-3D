from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


TARGET_LAYER = "BERRA_V13_STRUTTURA_3DS_ALLINEATA"
STANDBY_LAYER = "BERRA_STANDBY_REVISIONE_STRUTTURE_FINITURE"
SKIP_TYPES = {"BeamSegment", "ColumnSegment"}
OUT_TXT = Path(r"E:\strumenti-archicad29\berra_standby_v13_struttura_3ds_report.txt")
OUT_JSON = Path(r"E:\strumenti-archicad29\berra_standby_v13_struttura_3ds_result.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_standby_layer(commands, types):
    existing = find_layer_index(commands, types, STANDBY_LAYER)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": STANDBY_LAYER,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 190,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, STANDBY_LAYER)
    if created is None:
        raise RuntimeError(f"Layer non creato: {STANDBY_LAYER}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def get_rows(commands, types):
    layers = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    rows = []
    for element, detail in zip(elements, details):
        rows.append(
            {
                "element": element,
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
                "layer": layers.get(int(detail.get("layerIndex", -999)), ""),
            }
        )
    return rows


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print(f"Mette in stand-by il layer {TARGET_LAYER}.")
        print("Uso: py 75_tapir_standby_v13_struttura_3ds_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby_index = create_or_get_standby_layer(commands, types)
    rows = [row for row in get_rows(commands, types) if row["layer"] == TARGET_LAYER and row["type"] not in SKIP_TYPES]
    if rows:
        result = tapir(
            commands,
            types,
            "SetDetailsOfElements",
            {
                "elementsWithDetails": [
                    {"elementId": row["element"]["elementId"], "details": {"layerIndex": standby_index}}
                    for row in rows
                ]
            },
        )
    else:
        result = None

    payload = {
        "targetLayer": TARGET_LAYER,
        "standbyLayer": STANDBY_LAYER,
        "standbyIndex": standby_index,
        "moved": len(rows),
        "byType": dict(Counter(row["type"] for row in rows)),
        "result": result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - STAND-BY V13 STRUTTURA 3DS",
                "=" * 42,
                f"Layer bersaglio: {TARGET_LAYER}",
                f"Layer stand-by: {STANDBY_LAYER} index {standby_index}",
                f"Elementi spostati: {len(rows)}",
                "Per tipo:",
                *(f"- {typ}: {count}" for typ, count in sorted(payload["byType"].items())),
            ]
        ),
        encoding="utf-8",
    )
    print(f"Elementi V13 spostati in stand-by: {len(rows)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
