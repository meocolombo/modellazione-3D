from __future__ import annotations

import csv
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
DWG_OUT = ROOT / "output_berra_dwg_struttura_110626"
IFC_OUT = ROOT / "output_berra_v17_ufficiale_pipeline"
V20_OUT = ROOT / "output_berra_v20_falde_pln"
OUT = ROOT / "output_berra_v21_calibrazione_dwg"

DWG_SEGMENTS = DWG_OUT / "dwg_struttura_110626_flat_segments.csv"
IFC_ROOF_FACES = IFC_OUT / "berra_v17_ufficiale_ifc_roof_faces.csv"
V20_AXES = V20_OUT / "berra_v20_assi_falde_pln_allineati.csv"


def bbox_points(points):
    return min(p[0] for p in points), min(p[1] for p in points), max(p[0] for p in points), max(p[1] for p in points)


def centroid(b):
    return (b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0


def size(b):
    return b[2] - b[0], b[3] - b[1]


def point_seg_dist(px, py, ax, ay, bx, by):
    vx = bx - ax
    vy = by - ay
    wx = px - ax
    wy = py - ay
    vv = vx * vx + vy * vy
    if vv <= 1e-12:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, (wx * vx + wy * vy) / vv))
    qx = ax + t * vx
    qy = ay + t * vy
    return math.hypot(px - qx, py - qy)


def nearest_dist(point, segments):
    px, py = point
    best = 1e9
    for s in segments:
        d = point_seg_dist(px, py, s["x1"], s["y1"], s["x2"], s["y2"])
        if d < best:
            best = d
    return best


def percentile(vals, q):
    vals = sorted(vals)
    if not vals:
        return 0.0
    pos = (len(vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return vals[lo]
    return vals[lo] * (hi - pos) + vals[hi] * (pos - lo)


def read_dwg_segments():
    rows = []
    with DWG_SEGMENTS.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            length = float(r["length"])
            if length < 0.05:
                continue
            rows.append(
                {
                    "layer": r["layer"],
                    "type": r["type"],
                    "x1": float(r["x1"]),
                    "y1": float(r["y1"]),
                    "x2": float(r["x2"]),
                    "y2": float(r["y2"]),
                    "length": length,
                }
            )
    return rows


def read_ifc_edges():
    edges = []
    with IFC_ROOF_FACES.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=";")
        for r in reader:
            pts3 = json.loads(r["points"])
            pts = [(float(p[0]), float(p[1])) for p in pts3]
            for a, b in zip(pts, pts[1:] + pts[:1]):
                length = math.hypot(b[0] - a[0], b[1] - a[1])
                if length > 0.05:
                    edges.append({"layer": "IFC_ROOF", "x1": a[0], "y1": a[1], "x2": b[0], "y2": b[1], "length": length})
    return edges


def read_v20_axes():
    axes = []
    if not V20_AXES.exists():
        return axes
    with V20_AXES.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f, delimiter=";"):
            x0 = float(r["x0"])
            y0 = float(r["y0"])
            x1 = float(r["x1"])
            y1 = float(r["y1"])
            length = math.hypot(x1 - x0, y1 - y0)
            if length > 0.05:
                axes.append({"layer": "V20_AXIS", "x1": x0, "y1": y0, "x2": x1, "y2": y1, "length": length, "code": r["code"]})
    return axes


def sample_segment(seg, step=1.0):
    n = max(2, int(math.ceil(seg["length"] / step)) + 1)
    for i in range(n):
        t = i / (n - 1)
        yield seg["x1"] + (seg["x2"] - seg["x1"]) * t, seg["y1"] + (seg["y2"] - seg["y1"]) * t


def transform_point(p, t):
    x, y = p
    cx, cy = t.get("center", (0.0, 0.0))
    x -= cx
    y -= cy
    sx = t.get("sx", t.get("scale", 1.0))
    sy = t.get("sy", t.get("scale", 1.0))
    x *= sx
    y *= sy
    a = math.radians(t.get("rot_deg", 0.0))
    ca = math.cos(a)
    sa = math.sin(a)
    xr = x * ca - y * sa
    yr = x * sa + y * ca
    return xr + cx + t.get("dx", 0.0), yr + cy + t.get("dy", 0.0)


def transform_seg(seg, t):
    a = transform_point((seg["x1"], seg["y1"]), t)
    b = transform_point((seg["x2"], seg["y2"]), t)
    out = dict(seg)
    out.update({"x1": a[0], "y1": a[1], "x2": b[0], "y2": b[1]})
    out["length"] = math.hypot(b[0] - a[0], b[1] - a[1])
    return out


def score_transform(ifc_edges, dwg_struct, t):
    pts = []
    for s in ifc_edges:
        for p in sample_segment(transform_seg(s, t), step=4.0):
            pts.append(p)
    # Limit for speed but keep distribution along the building.
    if len(pts) > 160:
        stride = max(1, len(pts) // 160)
        pts = pts[::stride]
    dists = [nearest_dist(p, dwg_struct) for p in pts]
    return {
        "median": percentile(dists, 0.50),
        "p75": percentile(dists, 0.75),
        "p90": percentile(dists, 0.90),
        "mean": sum(dists) / len(dists),
        "samples": len(dists),
    }


def optimize_translation(ifc_edges, dwg_struct, start):
    best_t = dict(start)
    best_score = score_transform(ifc_edges, dwg_struct, best_t)
    # Coarse to fine search around centroid translation.
    for radius, step in [(4.0, 1.0), (1.0, 0.25)]:
        base = dict(best_t)
        xs = [base.get("dx", 0.0) + i * step for i in range(int(-radius / step), int(radius / step) + 1)]
        ys = [base.get("dy", 0.0) + i * step for i in range(int(-radius / step), int(radius / step) + 1)]
        for dx in xs:
            for dy in ys:
                t = dict(base)
                t["dx"] = dx
                t["dy"] = dy
                sc = score_transform(ifc_edges, dwg_struct, t)
                if (sc["median"], sc["p75"], sc["mean"]) < (best_score["median"], best_score["p75"], best_score["mean"]):
                    best_t, best_score = t, sc
    return best_t, best_score


def optimize_similarity(ifc_edges, dwg_struct, start):
    best_t = dict(start)
    best_score = score_transform(ifc_edges, dwg_struct, best_t)
    for rot in [-1, 0, 1]:
        for scale in [1.00, 1.03, 1.06]:
            t = dict(start)
            t["rot_deg"] = rot
            t["scale"] = scale
            t2, sc = optimize_translation(ifc_edges, dwg_struct, t)
            if (sc["median"], sc["p75"], sc["mean"]) < (best_score["median"], best_score["p75"], best_score["mean"]):
                best_t, best_score = t2, sc
    return best_t, best_score


def render_candidate(name, dwg_struct, dwg_context, ifc_edges, v20_axes, transform, path):
    ifc_t = [transform_seg(s, transform) for s in ifc_edges]
    v20_t = [transform_seg(s, transform) for s in v20_axes]
    all_pts = (
        [(s["x1"], s["y1"]) for s in dwg_struct]
        + [(s["x2"], s["y2"]) for s in dwg_struct]
        + [(s["x1"], s["y1"]) for s in ifc_t]
        + [(s["x2"], s["y2"]) for s in ifc_t]
    )
    b = bbox_points(all_pts)
    minx, miny, maxx, maxy = b
    w, h = 1500, 2100
    margin = 70
    scale = min((w - 2 * margin) / max(maxx - minx, 1e-9), (h - 2 * margin) / max(maxy - miny, 1e-9))
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def tx(x, y):
        return int(margin + (x - minx) * scale), int(h - margin - (y - miny) * scale)

    for s in dwg_context:
        if s["length"] > 1.0:
            draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=(215, 215, 215), width=1)
    for s in dwg_struct:
        draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=(25, 25, 25), width=2)
    for s in ifc_t:
        draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=(220, 45, 45), width=2)
    for s in v20_t:
        draw.line([tx(s["x1"], s["y1"]), tx(s["x2"], s["y2"])], fill=(0, 170, 210), width=2)

    draw.text((margin, 24), name, fill=(0, 0, 0))
    draw.text((margin, 46), "nero DWG | rosso falde IFC trasformate | ciano assi V20 trasformati", fill=(80, 80, 80))
    img.save(path, quality=92)
    return path


def make_contact_sheet(images, path):
    thumbs = []
    for title, img_path in images:
        img = Image.open(img_path).convert("RGB")
        img.thumbnail((720, 1000))
        canvas = Image.new("RGB", (760, 1060), "white")
        d = ImageDraw.Draw(canvas)
        d.text((20, 14), title, fill=(0, 0, 0))
        canvas.paste(img, (20, 50))
        thumbs.append(canvas)
    cols = 2
    rows = math.ceil(len(thumbs) / cols)
    sheet = Image.new("RGB", (cols * 760, rows * 1060), "white")
    for i, thumb in enumerate(thumbs):
        sheet.paste(thumb, ((i % cols) * 760, (i // cols) * 1060))
    sheet.save(path, quality=92)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    dwg_all = read_dwg_segments()
    dwg_struct = [s for s in dwg_all if "strutturale" in s["layer"].lower() or "portante" in s["layer"].lower()]
    dwg_score = sorted([s for s in dwg_struct if s["length"] >= 0.8], key=lambda r: r["length"], reverse=True)[:320]
    dwg_context = [s for s in dwg_all if s not in dwg_struct]
    ifc = read_ifc_edges()
    v20 = read_v20_axes()

    bd = bbox_points([(s["x1"], s["y1"]) for s in dwg_struct] + [(s["x2"], s["y2"]) for s in dwg_struct])
    bi = bbox_points([(s["x1"], s["y1"]) for s in ifc] + [(s["x2"], s["y2"]) for s in ifc])
    cd = centroid(bd)
    ci = centroid(bi)
    sd = size(bd)
    si = size(bi)
    start = {"dx": cd[0] - ci[0], "dy": cd[1] - ci[1], "center": ci, "scale": 1.0, "rot_deg": 0.0}

    native = {"dx": 0.0, "dy": 0.0, "center": ci, "scale": 1.0, "rot_deg": 0.0}
    center = start
    opt_trans, opt_trans_score = optimize_translation(ifc, dwg_score, start)
    opt_sim, opt_sim_score = optimize_similarity(ifc, dwg_score, start)
    bbox_nonuniform = {
        "dx": cd[0] - ci[0],
        "dy": cd[1] - ci[1],
        "center": ci,
        "sx": sd[0] / si[0],
        "sy": sd[1] / si[1],
        "rot_deg": 0.0,
    }

    candidates = [
        ("A_native", native),
        ("B_centri", center),
        ("C_traslazione_ottimizzata", opt_trans),
        ("D_similitudine_ottimizzata", opt_sim),
        ("E_bbox_non_uniforme_diagnostica", bbox_nonuniform),
    ]

    rows = []
    rendered = []
    for name, tr in candidates:
        score = score_transform(ifc, dwg_score, tr)
        row = {
            "candidate": name,
            "dx": tr.get("dx", 0.0),
            "dy": tr.get("dy", 0.0),
            "rot_deg": tr.get("rot_deg", 0.0),
            "scale": tr.get("scale", ""),
            "sx": tr.get("sx", ""),
            "sy": tr.get("sy", ""),
            **score,
        }
        rows.append(row)
        img_path = OUT / f"v21_{name}.png"
        render_candidate(name, dwg_struct, dwg_context, ifc, v20, tr, img_path)
        rendered.append((name, img_path))

    with (OUT / "v21_candidati_calibrazione.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["candidate", "dx", "dy", "rot_deg", "scale", "sx", "sy", "median", "p75", "p90", "mean", "samples"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    make_contact_sheet(rendered, OUT / "v21_confronto_candidati_calibrazione.png")

    best = min(rows, key=lambda r: (float(r["median"]), float(r["p75"]), float(r["mean"])))
    report = [
        "# V21 calibrazione DWG struttura / falde IFC",
        "",
        "Nessuna modifica e stata fatta in Archicad.",
        "",
        "## Candidati",
        "",
    ]
    for r in rows:
        report.append(
            f"- {r['candidate']}: dx {float(r['dx']):.3f}, dy {float(r['dy']):.3f}, rot {float(r['rot_deg']):.3f}, "
            f"scale {r['scale'] or '-'}, sx {r['sx'] or '-'}, sy {r['sy'] or '-'}, "
            f"mediana {float(r['median']):.3f}, p75 {float(r['p75']):.3f}, p90 {float(r['p90']):.3f}"
        )
    report.extend(
        [
            "",
            f"## Migliore automatica per distanza lineare",
            "",
            f"`{best['candidate']}`",
            "",
            "Nota: il criterio automatico misura la distanza dei bordi falda IFC dalle linee portanti del DWG. Va verificato visivamente perche tetto e murature non coincidono sempre per natura.",
            "",
            "## Output",
            "",
            "- `v21_confronto_candidati_calibrazione.png`",
            "- `v21_candidati_calibrazione.csv`",
            "- `v21_A_native.png` ... `v21_E_bbox_non_uniforme_diagnostica.png`",
        ]
    )
    (OUT / "v21_calibrazione_report.md").write_text("\n".join(report), encoding="utf-8")
    print("V21 calibrazione creata")
    print(f"Migliore candidata: {best['candidate']} mediana={float(best['median']):.3f} p75={float(best['p75']):.3f}")


if __name__ == "__main__":
    main()
