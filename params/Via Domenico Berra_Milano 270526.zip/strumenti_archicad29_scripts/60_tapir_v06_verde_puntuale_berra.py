from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_V06_VERDE_ARREDI"
OUT_JSON = Path("berra_v06_verde_arredi_result.json")
OUT_CSV = Path("berra_v06_verde_arredi_elementi.csv")
OUT_TXT = Path("berra_v06_verde_arredi_report.txt")


# Coordinate derivate dal modello corrente e dalla tavola "TETTO E CAPRIATE BERRA".
# Passata volutamente ridotta: solo elementi puntuali di verde/arredo, non struttura.
OBJECTS = [
    # Giardino/corte maggiore.
    ("BER-V06-ALB-001", "Albero Modello Semplice 1", -36.20, -55.40, 0.00, 4.80, 4.80, 6.20, "Albero corte sud"),
    ("BER-V06-ALB-002", "Albero Modello Semplice 2", -30.30, -52.20, 0.00, 5.40, 5.40, 7.00, "Albero corte sud"),
    ("BER-V06-ALB-003", "Albero Modello Semplice 1", -24.60, -47.20, 0.00, 4.60, 4.60, 5.80, "Albero corte sud"),
    ("BER-V06-ALB-004", "Albero Modello Semplice 2", -36.40, -38.20, 0.00, 4.40, 4.40, 5.80, "Albero corte sud"),
    ("BER-V06-ALB-005", "Albero Modello Semplice 1", -28.60, -34.60, 0.00, 4.80, 4.80, 6.20, "Albero corte sud"),
    ("BER-V06-ARB-001", "Arbusti", -23.80, -30.00, 0.00, 2.30, 2.30, 1.40, "Arbusto corte sud"),
    ("BER-V06-SED-001", "Panchina", -30.20, -44.80, 0.00, 1.80, 0.65, 0.80, "Seduta corte sud"),
    # Corte superiore/loggiato.
    ("BER-V06-ALB-006", "Albero Modello Semplice 1", -31.40, 17.20, 0.00, 3.80, 3.80, 5.00, "Albero corte loggiato"),
    ("BER-V06-ARB-002", "Arbusti", -27.60, 22.80, 0.00, 2.10, 2.10, 1.30, "Arbusto corte loggiato"),
    ("BER-V06-ARB-003", "Arbusti", -23.70, 28.00, 0.00, 2.00, 2.00, 1.25, "Arbusto corte loggiato"),
    ("BER-V06-SED-002", "Panchina", -27.20, 20.80, 0.00, 1.80, 0.65, 0.80, "Seduta corte loggiato"),
]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 160,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def count_elements_on_layer(commands, types, layer_index):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    return sum(1 for detail in details if int(detail.get("layerIndex", -1)) == int(layer_index))


def set_details(commands, types, created_rows, layer_index):
    payload = []
    for row in created_rows:
        payload.append(
            {
                "elementId": row["element"]["elementId"],
                "details": {"layerIndex": int(layer_index)},
            }
        )
    layer_result = tapir(commands, types, "SetDetailsOfElements", {"elementsWithDetails": payload})

    id_payload = []
    for row in created_rows:
        id_payload.append(
            {
                "elementId": row["element"]["elementId"],
                "details": {"typeSpecificDetails": {}, "layerIndex": int(layer_index)},
            }
        )
    # Tapir non espone sempre l'Element ID via SetDetails per gli oggetti.
    # Lo script lascia comunque codici e guid nel CSV; General_ElementID viene scritto dopo.
    return layer_result


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        nonlocalized = getattr(prop_name, "nonLocalizedName", "")
        if nonlocalized == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def write_general_ids(commands, types, created_rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created_rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created_rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created_rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea una micro-pass di verde/arredi su layer dedicato.")
        print("Uso: py 60_tapir_v06_verde_puntuale_berra.py APPLICA")
        print("Per rilanciare su layer gia popolato: aggiungere FORZA.")
        return

    force = len(sys.argv) >= 3 and sys.argv[2].upper() == "FORZA"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)
    existing = count_elements_on_layer(commands, types, layer_index)
    if existing and not force:
        print(f"Layer {LAYER_NAME} gia popolato con {existing} elementi. Nessuna modifica.")
        print("Usa FORZA solo dopo verifica visiva.")
        return

    created_rows = []
    failures = []
    for code, libpart, x, y, z, sx, sy, sz, note in OBJECTS:
        data = {
            "objectsData": [
                {
                    "libraryPartName": libpart,
                    "coordinates": point3(x, y, z),
                    "dimensions": dim3(sx, sy, sz),
                }
            ]
        }
        try:
            result = tapir(commands, types, "CreateObjects", data)
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": code, "libraryPartName": libpart, "error": "nessun elemento restituito", "result": result})
                continue
            created_rows.append(
                {
                    "code": code,
                    "libraryPartName": libpart,
                    "x": x,
                    "y": y,
                    "z": z,
                    "sizeX": sx,
                    "sizeY": sy,
                    "sizeZ": sz,
                    "note": note,
                    "element": elements[0],
                }
            )
        except Exception as exc:
            failures.append({"code": code, "libraryPartName": libpart, "error": str(exc)})

    layer_result = set_details(commands, types, created_rows, layer_index) if created_rows else None
    id_result = write_general_ids(commands, types, created_rows) if created_rows else {"ok": 0, "failed": 0}

    csv_rows = []
    for row in created_rows:
        csv_rows.append(
            {
                "codice_id": row["code"],
                "guid": row["element"]["elementId"]["guid"],
                "layer": LAYER_NAME,
                "libraryPartName": row["libraryPartName"],
                "x": row["x"],
                "y": row["y"],
                "z": row["z"],
                "sizeX": row["sizeX"],
                "sizeY": row["sizeY"],
                "sizeZ": row["sizeZ"],
                "note": row["note"],
            }
        )
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["codice_id", "guid", "layer", "libraryPartName", "x", "y", "z", "sizeX", "sizeY", "sizeZ", "note"],
            delimiter=";",
        )
        writer.writeheader()
        writer.writerows(csv_rows)

    payload = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "requested": len(OBJECTS),
        "created": len(created_rows),
        "failures": failures,
        "setLayerResult": layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V06 - VERDE E ARREDI PUNTUALI",
                "=" * 40,
                f"Layer: {LAYER_NAME} index {layer_index}",
                f"Richiesti: {len(OBJECTS)}",
                f"Creati: {len(created_rows)}",
                f"Falliti: {len(failures)}",
                f"General_ElementID OK: {id_result.get('ok', 0)}",
                f"General_ElementID falliti: {id_result.get('failed', 0)}",
                "",
                "Elementi creati:",
                *(f"- {row['code']} | {row['libraryPartName']} | guid {row['element']['elementId']['guid']}" for row in created_rows),
                "",
                "Fallimenti:",
                *(f"- {item.get('code')} | {item.get('libraryPartName')} | {item.get('error')}" for item in failures),
            ]
        ),
        encoding="utf-8",
    )

    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Richiesti: {len(OBJECTS)}")
    print(f"Creati: {len(created_rows)}")
    print(f"Falliti: {len(failures)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
