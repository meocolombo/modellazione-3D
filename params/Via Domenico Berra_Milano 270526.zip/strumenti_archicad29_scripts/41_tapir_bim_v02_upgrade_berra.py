from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_v02_bim_upgrade_result.json")
OUT_COMPUTO = Path("berra_v02_bim_computo_preliminare.csv")
OUT_MAPPING = Path("berra_v02_bim_guid_mapping.csv")
OUT_GEO = Path("berra_v02_georeferenziazione.txt")

STANDBY_LAYER = "BERRA_BIM_V02_STANDBY_PRE_UPGRADE"
LAYERS = {
    "geo": ("BERRA_BIM_V02_00_GEOREFERENZIAZIONE", 150),
    "structure": ("BERRA_BIM_V02_04_STRUTTURE_COPERTURA", 154),
    "openings": ("BERRA_BIM_V02_05_APERTURE_PORTALI", 155),
    "finish": ("BERRA_BIM_V02_06_FINITURE_FACCIATE", 156),
    "green": ("BERRA_BIM_V02_07_VERDE_CONTESTO", 157),
    "library": ("BERRA_BIM_V02_08_LIBRERIE_LOCALI", 158),
}

SITE_WGS84 = {
    "address": "Via Domenico Berra 10/12/14, Milano",
    "latitude": 45.50849058,
    "longitude": 9.24840835,
    "model_local_rotation_deg": -3.20,
}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group, hidden=False):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def normalize_elements(elements):
    normalized = []
    for element in elements:
        if "elementId" in element:
            normalized.append(element)
        elif "guid" in element:
            normalized.append({"elementId": {"guid": element["guid"]}})
    return normalized


def set_layer(commands, types, elements, target_layer):
    elements = normalize_elements(elements)
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": target_layer}}
                for element in elements
            ]
        },
    )


def get_model(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    layer_names = layers_map(commands, types)
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        box = box_item.get("boundingBox3D", {})
        try:
            layer_name = layer_names.get(int(detail.get("layerIndex", -999)), "")
        except Exception:
            layer_name = ""
        rows.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
                "layer": layer_name,
                "details": detail.get("details", {}),
                "xMin": float(box.get("xMin", 0.0)),
                "xMax": float(box.get("xMax", 0.0)),
                "yMin": float(box.get("yMin", 0.0)),
                "yMax": float(box.get("yMax", 0.0)),
                "zMin": float(box.get("zMin", 0.0)),
                "zMax": float(box.get("zMax", 0.0)),
            }
        )
    return rows


def move_previous_v02(commands, types, standby_index, rows):
    to_move = [row["element"] for row in rows if row["layer"].startswith("BERRA_BIM_V02_")]
    if not to_move:
        return {"movedCount": 0}
    result = set_layer(commands, types, to_move, standby_index)
    return {"movedCount": len(to_move), "result": result}


def length2(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def bbox_area(row):
    return max(0.0, row["xMax"] - row["xMin"]) * max(0.0, row["yMax"] - row["yMin"])


def element_code(prefix, index):
    return f"BER-V02-{prefix}-{index:03d}"


def add_mapping(mapping, guid, code, category, layer, source):
    if guid:
        mapping.append(
            {
                "guid": guid,
                "codice_id": code,
                "categoria": category,
                "layer": layer,
                "sorgente": source,
            }
        )


def add_computo(computo, code, category, description, qty, unit, param=0.0, qty2=0.0, unit2=""):
    computo.append(
        {
            "codice_id": code,
            "categoria": category,
            "descrizione": description,
            "quantita_primaria": round(float(qty), 4),
            "unita_primaria": unit,
            "parametro_secondario": round(float(param), 4) if isinstance(param, (int, float)) else param,
            "quantita_secondaria": round(float(qty2), 4) if isinstance(qty2, (int, float)) else qty2,
            "unita_secondaria": unit2,
        }
    )


def collect_existing_quantities(rows, mapping, computo):
    counters = defaultdict(int)
    for row in rows:
        if row["layer"].startswith("BERRA_BIM_V02_"):
            continue
        typ = row["type"]
        if typ == "Wall":
            counters["WAL"] += 1
            code = element_code("WAL", counters["WAL"])
            d = row["details"]
            beg = d.get("begCoordinate", {})
            end = d.get("endCoordinate", {})
            if "x" in beg and "x" in end:
                length = length2(float(beg["x"]), float(beg["y"]), float(end["x"]), float(end["y"]))
            else:
                length = max(row["xMax"] - row["xMin"], row["yMax"] - row["yMin"])
            height = float(d.get("height", row["zMax"] - row["zMin"] or 3.0) or 3.0)
            thickness = float(d.get("thickness", 0.40) or 0.40)
            add_mapping(mapping, row["guid"], code, "Muratura esistente V02", row["layer"], row["id"])
            add_computo(computo, code, "Muratura", row["id"] or "muratura V02", length, "m", thickness, length * height * thickness, "m3")
        elif typ == "Slab":
            counters["SLB"] += 1
            code = element_code("SLB", counters["SLB"])
            thickness = max(0.05, row["zMax"] - row["zMin"])
            area = bbox_area(row)
            add_mapping(mapping, row["guid"], code, "Solaio esistente V02", row["layer"], row["id"])
            add_computo(computo, code, "Solaio", row["id"] or "solaio V02", area, "m2", thickness, area * thickness, "m3")
        elif typ == "Roof":
            counters["ROF"] += 1
            code = element_code("ROF", counters["ROF"])
            area = bbox_area(row)
            thickness = max(0.12, min(0.35, row["zMax"] - row["zMin"]))
            add_mapping(mapping, row["guid"], code, "Copertura esistente V02", row["layer"], row["id"])
            add_computo(computo, code, "Copertura", row["id"] or "copertura V02", area, "m2", thickness, area * thickness, "m3")
        elif typ == "Window":
            counters["WIN"] += 1
            code = element_code("WIN", counters["WIN"])
            add_mapping(mapping, row["guid"], code, "Finestra esistente V02", row["layer"], row["id"])
            add_computo(computo, code, "Finestra", row["id"] or "finestra V02", 1, "cad", 0, 1, "cad")
        elif typ == "Door":
            counters["DOR"] += 1
            code = element_code("DOR", counters["DOR"])
            add_mapping(mapping, row["guid"], code, "Porta esistente V02", row["layer"], row["id"])
            add_computo(computo, code, "Porta", row["id"] or "porta V02", 1, "cad", 0, 1, "cad")


def create_beams(commands, types, layer, data, codes, category, mapping, computo):
    if not data:
        return {"requested": 0, "created": 0}
    result = tapir(commands, types, "CreateBeams", {"beamsData": data})
    elements = normalize_elements(result.get("elements", []))
    set_result = set_layer(commands, types, elements, layer)
    for element, beam, code in zip(elements, data, codes):
        beg = beam["begCoordinate"]
        end = beam["endCoordinate"]
        length = length2(beg["x"], beg["y"], end["x"], end["y"])
        add_mapping(mapping, element["elementId"].get("guid", ""), code, category, "created", "beam")
        add_computo(computo, code, category, category.lower(), length, "m", beam["width"] * beam["height"], length * beam["width"] * beam["height"], "m3")
    return {"requested": len(data), "created": len(elements), "result": result, "setLayerResult": set_result}


def beam(x1, y1, x2, y2, z, width, height):
    return {
        "begCoordinate": coord(x1, y1),
        "endCoordinate": coord(x2, y2),
        "zCoordinate": float(z),
        "width": float(width),
        "height": float(height),
    }


def build_roof_structures(roof_rows):
    beams = []
    codes = []
    index = 1
    for roof in sorted(roof_rows, key=lambda r: (r["yMin"], r["xMin"])):
        x1, x2, y1, y2 = roof["xMin"], roof["xMax"], roof["yMin"], roof["yMax"]
        if abs(x2 - x1) < 1.2 or abs(y2 - y1) < 1.2:
            continue
        sx = x2 - x1
        sy = y2 - y1
        z_eave = max(roof["zMin"] + 0.18, min(roof["zMax"] - 0.15, roof["zMin"] + 0.55))
        z_ridge = roof["zMax"] + 0.08
        if sy >= sx:
            xm = (x1 + x2) / 2
            beams.append(beam(xm, y1 + 0.25, xm, y2 - 0.25, z_ridge, 0.12, 0.10))
            codes.append(element_code("STR-COL", index)); index += 1
            step = max(4.5, min(7.0, sy / max(1, round(sy / 6.0))))
            y = y1 + step
            while y < y2 - 0.5:
                beams.append(beam(x1 + 0.25, y, x2 - 0.25, y, z_eave + 0.25, 0.16, 0.12))
                codes.append(element_code("STR-CAP", index)); index += 1
                y += step
            for off in [0.32, 0.68]:
                x = x1 + sx * off
                beams.append(beam(x, y1 + 0.30, x, y2 - 0.30, z_eave + 0.12, 0.09, 0.07))
                codes.append(element_code("STR-ARC", index)); index += 1
        else:
            ym = (y1 + y2) / 2
            beams.append(beam(x1 + 0.25, ym, x2 - 0.25, ym, z_ridge, 0.12, 0.10))
            codes.append(element_code("STR-COL", index)); index += 1
            step = max(4.5, min(7.0, sx / max(1, round(sx / 6.0))))
            x = x1 + step
            while x < x2 - 0.5:
                beams.append(beam(x, y1 + 0.25, x, y2 - 0.25, z_eave + 0.25, 0.16, 0.12))
                codes.append(element_code("STR-CAP", index)); index += 1
                x += step
            for off in [0.32, 0.68]:
                y = y1 + sy * off
                beams.append(beam(x1 + 0.30, y, x2 - 0.30, y, z_eave + 0.12, 0.09, 0.07))
                codes.append(element_code("STR-ARC", index)); index += 1
        perimeter = [
            (x1, y1, x2, y1),
            (x1, y2, x2, y2),
            (x1, y1, x1, y2),
            (x2, y1, x2, y2),
        ]
        for a, b, c, d in perimeter:
            beams.append(beam(a, b, c, d, z_eave, 0.09, 0.06))
            codes.append(element_code("STR-GRN", index)); index += 1
    return beams, codes


def create_morphs(commands, types, layer, data, codes, category, mapping, computo):
    if not data:
        return {"requested": 0, "created": 0}
    result = tapir(commands, types, "CreateMorphs", {"morphsData": data})
    elements = normalize_elements(result.get("elements", []))
    set_result = set_layer(commands, types, elements, layer)
    for element, morph, code in zip(elements, data, codes):
        size = morph.get("size", {})
        sx, sy, sz = float(size.get("x", 0)), float(size.get("y", 0)), float(size.get("z", 0))
        add_mapping(mapping, element["elementId"].get("guid", ""), code, category, "created", "morph")
        add_computo(computo, code, category, category.lower(), sx * sy, "m2", sz, sx * sy * sz, "m3")
    return {"requested": len(data), "created": len(elements), "result": result, "setLayerResult": set_result}


def box(x, y, z, sx, sy, sz):
    return {"basePoint": point3(x, y, z), "size": dim3(sx, sy, sz)}


def build_opening_finishes(window_rows, door_rows):
    morphs = []
    codes = []
    idx = 1
    for row in window_rows:
        wx = row["xMax"] - row["xMin"]
        wy = row["yMax"] - row["yMin"]
        z0 = row["zMin"]
        z1 = row["zMax"]
        if wx >= wy:
            x = row["xMin"] - 0.08
            y = row["yMin"] - 0.06
            sx = wx + 0.16
            sy = max(0.09, wy + 0.12)
            morphs.append(box(x, y, z0 - 0.10, sx, sy, 0.10))
            codes.append(element_code("FIN-DAV", idx)); idx += 1
            morphs.append(box(x, y, z1, sx, sy, 0.12))
            codes.append(element_code("FIN-ARC", idx)); idx += 1
        else:
            x = row["xMin"] - 0.06
            y = row["yMin"] - 0.08
            sx = max(0.09, wx + 0.12)
            sy = wy + 0.16
            morphs.append(box(x, y, z0 - 0.10, sx, sy, 0.10))
            codes.append(element_code("FIN-DAV", idx)); idx += 1
            morphs.append(box(x, y, z1, sx, sy, 0.12))
            codes.append(element_code("FIN-ARC", idx)); idx += 1
    for row in door_rows:
        wx = row["xMax"] - row["xMin"]
        wy = row["yMax"] - row["yMin"]
        x = row["xMin"] - 0.12
        y = row["yMin"] - 0.12
        morphs.append(box(x, y, row["zMax"], wx + 0.24, wy + 0.24, 0.18))
        codes.append(element_code("FIN-POR", idx)); idx += 1
    return morphs, codes


def build_green_context():
    slabs = []
    slab_codes = []
    beams = []
    beam_codes = []
    morphs = []
    morph_codes = []

    green_polys = [
        ("GRN", [(-40.1, 12.4), (-37.2, 12.4), (-37.9, 29.8), (-41.1, 29.2)]),
        ("GRN", [(-44.8, -60.5), (-36.2, -59.6), (-35.4, -26.0), (-44.3, -24.7)]),
        ("GRN", [(-31.8, -59.0), (-23.2, -58.2), (-22.4, -25.0), (-31.0, -24.2)]),
        ("CTX", [(-56.0, -77.2), (-10.5, -77.2), (-10.5, -72.3), (-56.0, -72.3)]),
        ("CTX", [(-56.2, -72.4), (-51.6, -72.4), (-51.6, 32.5), (-56.2, 32.5)]),
    ]
    for i, (prefix, pts) in enumerate(green_polys, start=1):
        slabs.append({"level": -0.04 if prefix == "CTX" else 0.02, "thickness": 0.055, "polygonCoordinates": [coord(x, y) for x, y in pts]})
        slab_codes.append(element_code(prefix, i))
        closed = pts + [pts[0]]
        for j, ((x1, y1), (x2, y2)) in enumerate(zip(closed, closed[1:]), start=1):
            beams.append(beam(x1, y1, x2, y2, 0.08, 0.055, 0.04))
            beam_codes.append(element_code(f"{prefix}-BD", len(beam_codes) + 1))
    trees = [
        (-39.8, 18.0, 1.2), (-39.4, 23.5, 1.4), (-43.3, -46.0, 1.5),
        (-39.0, -35.0, 1.4), (-27.5, -45.0, 1.4), (-25.5, -32.0, 1.2),
        (-36.0, -69.5, 1.3), (-20.5, -69.0, 1.3),
    ]
    for i, (x, y, scale) in enumerate(trees, start=1):
        morphs.append(box(x - 0.14, y - 0.14, 0.0, 0.28, 0.28, 1.8 * scale))
        morph_codes.append(element_code("ARB-TR", i))
        morphs.append(box(x - 0.9 * scale, y - 0.9 * scale, 1.4 * scale, 1.8 * scale, 1.8 * scale, 1.4 * scale))
        morph_codes.append(element_code("ARB-CH", i))
    return slabs, slab_codes, beams, beam_codes, morphs, morph_codes


def create_slabs(commands, types, layer, data, codes, category, mapping, computo):
    if not data:
        return {"requested": 0, "created": 0}
    result = tapir(commands, types, "CreateSlabs", {"slabsData": data})
    elements = normalize_elements(result.get("elements", []))
    set_result = set_layer(commands, types, elements, layer)
    for element, slab, code in zip(elements, data, codes):
        pts = slab["polygonCoordinates"]
        area = 0.0
        closed = pts + [pts[0]]
        for p1, p2 in zip(closed, closed[1:]):
            area += p1["x"] * p2["y"] - p2["x"] * p1["y"]
        area = abs(area) / 2.0
        thickness = float(slab.get("thickness", 0.0))
        add_mapping(mapping, element["elementId"].get("guid", ""), code, category, "created", "slab")
        add_computo(computo, code, category, category.lower(), area, "m2", thickness, area * thickness, "m3")
    return {"requested": len(data), "created": len(elements), "result": result, "setLayerResult": set_result}


def create_library_objects(commands, types, layer, mapping, computo):
    results = {}
    created = []
    points = [(-43.0, -46.0), (-27.0, -45.0), (-39.5, 22.0)]
    for library_name, dims, category in [
        ("Albero Deciduo", (4.0, 4.0, 7.0), "Libreria locale"),
        ("Panchina", (1.8, 0.7, 0.9), "Libreria locale"),
        ("Lampione 01", (0.6, 0.6, 3.6), "Libreria locale"),
    ]:
        try:
            data = [
                {"libraryPartName": library_name, "coordinates": point3(x, y, 0.0), "dimensions": dim3(*dims)}
                for x, y in points[:1 if "Panchina" in library_name else 3]
            ]
            result = tapir(commands, types, "CreateObjects", {"objectsData": data})
            elements = normalize_elements(result.get("elements", []))
            set_layer(commands, types, elements, layer)
            created += elements
            results[library_name] = {"created": len(elements), "result": result}
            for i, element in enumerate(elements, start=1):
                code = element_code("LIB", len(mapping) + i)
                add_mapping(mapping, element["elementId"].get("guid", ""), code, category, "created", library_name)
                add_computo(computo, code, category, library_name, 1, "cad", 0, 1, "cad")
        except Exception as exc:
            results[library_name] = {"error": str(exc)}
    return {"created": len(created), "results": results}


def write_csv(path, rows, fieldnames):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def write_geo_report():
    OUT_GEO.write_text(
        "\n".join(
            [
                "GEOREFERENZIAZIONE V02 - VIA BERRA",
                "=" * 35,
                f"Indirizzo: {SITE_WGS84['address']}",
                f"Latitudine riferimento Google Earth: {SITE_WGS84['latitude']}",
                f"Longitudine riferimento Google Earth: {SITE_WGS84['longitude']}",
                f"Rotazione locale modello stimata: {SITE_WGS84['model_local_rotation_deg']} gradi",
                "",
                "Nota: il V02 resta nel sistema locale del PLN. La georeferenziazione reale e usata come riferimento documentale; non ho ruotato o traslato il modello per non perdere l'allineamento delle falde corrette manualmente.",
                "Per completare la georeferenziazione formale va impostato il luogo progetto/Nord in Archicad dalle impostazioni progetto, se richiesto per IFC o coordinamento GIS.",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Aggiorna il modello Berra V02 con BIM/computo senza toccare le falde esistenti.")
        print("Uso: py 41_tapir_bim_v02_upgrade_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    layer_ids = {key: create_or_get_layer(commands, types, *value) for key, value in LAYERS.items()}
    standby = create_or_get_layer(commands, types, STANDBY_LAYER, 149, hidden=True)

    rows = get_model(commands, types)
    standby_result = move_previous_v02(commands, types, standby, rows)
    rows = get_model(commands, types)

    mapping = []
    computo = []
    collect_existing_quantities(rows, mapping, computo)

    roof_rows = [row for row in rows if row["type"] == "Roof" and not row["layer"].startswith("BERRA_BIM_V02_")]
    beam_data, beam_codes = build_roof_structures(roof_rows)
    structure_result = create_beams(commands, types, layer_ids["structure"], beam_data, beam_codes, "Struttura copertura", mapping, computo)

    window_rows = [row for row in rows if row["type"] == "Window"]
    door_rows = [row for row in rows if row["type"] == "Door"]
    opening_morphs, opening_codes = build_opening_finishes(window_rows, door_rows)
    opening_result = create_morphs(commands, types, layer_ids["openings"], opening_morphs, opening_codes, "Finitura aperture", mapping, computo)

    slabs, slab_codes, green_beams, green_beam_codes, green_morphs, green_morph_codes = build_green_context()
    green_slab_result = create_slabs(commands, types, layer_ids["green"], slabs, slab_codes, "Verde e contesto", mapping, computo)
    green_beam_result = create_beams(commands, types, layer_ids["green"], green_beams, green_beam_codes, "Bordo verde/contesto", mapping, computo)
    green_morph_result = create_morphs(commands, types, layer_ids["green"], green_morphs, green_morph_codes, "Verde", mapping, computo)

    geo_beams = [
        beam(-8.0, 38.0, -8.0, 46.0, 0.2, 0.10, 0.06),
        beam(-12.0, 38.0, -2.0, 38.0, 0.2, 0.06, 0.04),
    ]
    geo_codes = [element_code("GEO", 1), element_code("GEO", 2)]
    geo_result = create_beams(commands, types, layer_ids["geo"], geo_beams, geo_codes, "Georeferenziazione", mapping, computo)

    library_result = create_library_objects(commands, types, layer_ids["library"], mapping, computo)

    write_csv(
        OUT_COMPUTO,
        computo,
        [
            "codice_id",
            "categoria",
            "descrizione",
            "quantita_primaria",
            "unita_primaria",
            "parametro_secondario",
            "quantita_secondaria",
            "unita_secondaria",
        ],
    )
    write_csv(OUT_MAPPING, mapping, ["guid", "codice_id", "categoria", "layer", "sorgente"])
    write_geo_report()

    result = {
        "layers": layer_ids,
        "standby": standby_result,
        "existingModel": {
            "walls": sum(1 for row in rows if row["type"] == "Wall"),
            "slabs": sum(1 for row in rows if row["type"] == "Slab"),
            "roofs": sum(1 for row in rows if row["type"] == "Roof"),
            "windows": len(window_rows),
            "doors": len(door_rows),
        },
        "created": {
            "structure": structure_result,
            "openings": opening_result,
            "greenSlabs": green_slab_result,
            "greenBeams": green_beam_result,
            "greenMorphs": green_morph_result,
            "geo": geo_result,
            "library": library_result,
        },
        "outputs": {
            "computo": str(OUT_COMPUTO),
            "mapping": str(OUT_MAPPING),
            "georef": str(OUT_GEO),
        },
    }
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print("Upgrade BIM V02 completato.")
    print(f"Elementi V02 precedenti spostati in stand-by: {standby_result.get('movedCount', 0)}")
    print(f"Base letta: muri {result['existingModel']['walls']}, solai {result['existingModel']['slabs']}, coperture {result['existingModel']['roofs']}, finestre {result['existingModel']['windows']}, porte {result['existingModel']['doors']}")
    print(f"Strutture copertura create: {structure_result['created']}")
    print(f"Finiture aperture create: {opening_result['created']}")
    print(f"Verde/contesto creati: {green_slab_result['created'] + green_beam_result['created'] + green_morph_result['created']}")
    print(f"Librerie locali create: {library_result['created']}")
    print(f"Computo: {OUT_COMPUTO}")
    print(f"Mappatura: {OUT_MAPPING}")
    print(f"Georeferenziazione: {OUT_GEO}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
