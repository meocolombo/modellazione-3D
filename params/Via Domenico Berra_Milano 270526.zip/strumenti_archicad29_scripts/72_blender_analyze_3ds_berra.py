from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import bpy
from mathutils import Vector


DEFAULT_SRC = Path(r"Z:\268_Via Berra Milano\3d e piante via berra\268_BERRA_10_BACKUP_PRIMA_AI_V02.3ds")
DEFAULT_OUT = Path(r"E:\strumenti-archicad29")


def world_bbox(obj):
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    xs = [corner.x for corner in corners]
    ys = [corner.y for corner in corners]
    zs = [corner.z for corner in corners]
    return {
        "xMin": min(xs),
        "xMax": max(xs),
        "yMin": min(ys),
        "yMax": max(ys),
        "zMin": min(zs),
        "zMax": max(zs),
    }


def fmt(value):
    return round(float(value), 5)


def classify(obj, box):
    name = obj.name.lower()
    mats = " ".join(slot.material.name.lower() for slot in obj.material_slots if slot.material)
    dx = box["xMax"] - box["xMin"]
    dy = box["yMax"] - box["yMin"]
    dz = box["zMax"] - box["zMin"]
    text = f"{name} {mats}"
    if any(word in text for word in ("roof", "tetto", "copertura", "tile", "tegola")):
        return "copertura"
    if dz > 1.2 and min(dx, dy) < 1.4:
        return "verticale_sottile"
    if dz < 0.45 and max(dx, dy) > 4.0:
        return "piano_esteso"
    if dz > 1.0 and max(dx, dy) > 3.0:
        return "muro_volume"
    return "altro"


def main():
    args = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    src = Path(args[0]) if len(args) >= 1 else DEFAULT_SRC
    out_dir = Path(args[1]) if len(args) >= 2 else DEFAULT_OUT
    out_dir.mkdir(parents=True, exist_ok=True)

    if not src.exists():
        raise SystemExit(f"File 3DS non trovato: {src}")

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()
    bpy.ops.import_scene.autodesk_3ds(filepath=str(src))

    rows = []
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH":
            continue
        mesh = obj.data
        box = world_bbox(obj)
        dx = box["xMax"] - box["xMin"]
        dy = box["yMax"] - box["yMin"]
        dz = box["zMax"] - box["zMin"]
        material_names = [slot.material.name for slot in obj.material_slots if slot.material]
        rows.append(
            {
                "name": obj.name,
                "class": classify(obj, box),
                "vertices": len(mesh.vertices),
                "polygons": len(mesh.polygons),
                "materials": "|".join(material_names),
                "xMin": fmt(box["xMin"]),
                "xMax": fmt(box["xMax"]),
                "yMin": fmt(box["yMin"]),
                "yMax": fmt(box["yMax"]),
                "zMin": fmt(box["zMin"]),
                "zMax": fmt(box["zMax"]),
                "dx": fmt(dx),
                "dy": fmt(dy),
                "dz": fmt(dz),
            }
        )

    rows.sort(key=lambda row: (row["class"], row["zMin"], row["yMin"], row["xMin"], row["name"]))
    csv_path = out_dir / "berra_3ds_blender_objects.csv"
    json_path = out_dir / "berra_3ds_blender_objects.json"
    txt_path = out_dir / "berra_3ds_blender_report.txt"
    fields = [
        "name",
        "class",
        "vertices",
        "polygons",
        "materials",
        "xMin",
        "xMax",
        "yMin",
        "yMax",
        "zMin",
        "zMax",
        "dx",
        "dy",
        "dz",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
    json_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")

    by_class = {}
    for row in rows:
        by_class[row["class"]] = by_class.get(row["class"], 0) + 1
    txt_path.write_text(
        "\n".join(
            [
                "BERRA - ANALISI 3DS BLENDER",
                "=" * 34,
                f"File: {src}",
                f"Oggetti mesh: {len(rows)}",
                "Classi:",
                *(f"- {name}: {count}" for name, count in sorted(by_class.items())),
                f"CSV: {csv_path}",
                f"JSON: {json_path}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Oggetti mesh: {len(rows)}")
    print(f"Report: {txt_path}")


if __name__ == "__main__":
    main()
