from __future__ import annotations

import csv
import importlib.util
import math
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
SCRIPTS = ROOT / "strumenti_archicad29_scripts"
OUT = ROOT / "output_berra_v22_punti_omologhi"
ANCHORS_CSV = OUT / "v22_punti_omologhi_proposti.csv"


def load_v22_module():
    path = SCRIPTS / "97_berra_v22_punti_omologhi_assistiti.py"
    spec = importlib.util.spec_from_file_location("berra_v22_helpers", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Impossibile caricare {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_anchors():
    rows = []
    with ANCHORS_CSV.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            rows.append(
                {
                    "id": r["id"],
                    "descrizione": r["descrizione"],
                    "dwg_x": float(r["dwg_x"]),
                    "dwg_y": float(r["dwg_y"]),
                    "model_x_guess": float(r["model_x_guess"]),
                    "model_y_guess": float(r["model_y_guess"]),
                    "distanza_stima_m": float(r["distanza_stima_m"]),
                    "attendibilita": r["attendibilita"],
                }
            )
    return rows


def transform_segment(seg, tr, helpers):
    a = helpers.transform_point((seg["x1"], seg["y1"]), tr)
    b = helpers.transform_point((seg["x2"], seg["y2"]), tr)
    return {"x1": a[0], "y1": a[1], "x2": b[0], "y2": b[1]}


def draw_seg(draw, tx, seg, color, width=1):
    draw.line([tx(seg["x1"], seg["y1"]), tx(seg["x2"], seg["y2"])], fill=color, width=width)


def render_card(anchor, dwg, ifc_edges, v20_axes, tr, helpers, path):
    mx, my = helpers.transform_point((anchor["model_x_guess"], anchor["model_y_guess"]), tr)
    cx = (anchor["dwg_x"] + mx) / 2
    cy = (anchor["dwg_y"] + my) / 2
    distance = anchor["distanza_stima_m"]
    radius = max(5.5, min(18.0, distance + 5.0))
    minx, maxx = cx - radius, cx + radius
    miny, maxy = cy - radius, cy + radius
    w, h = 1000, 1000
    margin = 72
    sx = (w - 2 * margin) / (maxx - minx)
    sy = (h - 2 * margin) / (maxy - miny)
    scale = min(sx, sy)

    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def tx(x, y):
        return int(margin + (x - minx) * scale), int(h - margin - (y - miny) * scale)

    # Light grid, 1 m.
    gx0 = math.floor(minx)
    gx1 = math.ceil(maxx)
    gy0 = math.floor(miny)
    gy1 = math.ceil(maxy)
    for gx in range(gx0, gx1 + 1):
        color = (230, 230, 230) if gx % 5 else (210, 210, 210)
        draw.line([tx(gx, miny), tx(gx, maxy)], fill=color, width=1)
    for gy in range(gy0, gy1 + 1):
        color = (230, 230, 230) if gy % 5 else (210, 210, 210)
        draw.line([tx(minx, gy), tx(maxx, gy)], fill=color, width=1)

    for seg in dwg:
        # Draw only segments touching the view box.
        sb = (min(seg["x1"], seg["x2"]), min(seg["y1"], seg["y2"]), max(seg["x1"], seg["x2"]), max(seg["y1"], seg["y2"]))
        if sb[2] < minx or sb[0] > maxx or sb[3] < miny or sb[1] > maxy:
            continue
        layer = seg["layer"].lower()
        if "strutturale" in layer or "portante" in layer:
            draw_seg(draw, tx, seg, (20, 20, 20), 3)
        else:
            draw_seg(draw, tx, seg, (205, 205, 205), 1)

    for seg in ifc_edges:
        ts = transform_segment(seg, tr, helpers)
        sb = (min(ts["x1"], ts["x2"]), min(ts["y1"], ts["y2"]), max(ts["x1"], ts["x2"]), max(ts["y1"], ts["y2"]))
        if sb[2] < minx or sb[0] > maxx or sb[3] < miny or sb[1] > maxy:
            continue
        draw_seg(draw, tx, ts, (220, 45, 45), 3)

    for seg in v20_axes:
        ts = transform_segment(seg, tr, helpers)
        sb = (min(ts["x1"], ts["x2"]), min(ts["y1"], ts["y2"]), max(ts["x1"], ts["x2"]), max(ts["y1"], ts["y2"]))
        if sb[2] < minx or sb[0] > maxx or sb[3] < miny or sb[1] > maxy:
            continue
        draw_seg(draw, tx, ts, (0, 170, 210), 2)

    px, py = tx(anchor["dwg_x"], anchor["dwg_y"])
    qx, qy = tx(mx, my)
    draw.line([px, py, qx, qy], fill=(190, 120, 0), width=2)
    draw.ellipse([px - 15, py - 15, px + 15, py + 15], fill=(255, 230, 0), outline=(0, 0, 0), width=3)
    draw.ellipse([qx - 9, qy - 9, qx + 9, qy + 9], fill=(220, 45, 45), outline=(0, 0, 0), width=1)

    status = anchor["attendibilita"]
    status_color = (20, 120, 55) if status == "buona" else (180, 95, 0) if status == "da_verificare" else (170, 25, 25)
    draw.rectangle([0, 0, w, 64], fill=(248, 248, 248))
    draw.text((22, 16), f"{anchor['id']} - {anchor['descrizione']}", fill=(0, 0, 0))
    draw.text((22, 38), f"distanza {distance:.2f} m | {status}", fill=status_color)
    draw.text((22, h - 44), "nero DWG | rosso falda modello stimata | ciano asse | giallo punto DWG", fill=(70, 70, 70))
    img.save(path, quality=92)
    return path


def make_contact_sheet(cards, path):
    cols = 3
    rows = math.ceil(len(cards) / cols)
    card_w, card_h = 1000, 1000
    sheet = Image.new("RGB", (cols * card_w, rows * card_h), "white")
    for i, card in enumerate(cards):
        img = Image.open(card).convert("RGB")
        sheet.paste(img, ((i % cols) * card_w, (i // cols) * card_h))
    sheet.save(path, quality=92)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    helpers = load_v22_module()
    dwg = helpers.read_dwg_segments()
    ifc_edges, ifc_vertices = helpers.read_ifc_edges()
    v20_axes = helpers.read_v20_axes()
    tr = helpers.read_calibration()
    tr["center"] = helpers.centroid(helpers.bbox_points(ifc_vertices))
    anchors = read_anchors()

    cards_dir = OUT / "zoom_punti"
    cards_dir.mkdir(parents=True, exist_ok=True)
    cards = []
    for anchor in anchors:
        path = cards_dir / f"v22b_zoom_{anchor['id']}.png"
        cards.append(render_card(anchor, dwg, ifc_edges, v20_axes, tr, helpers, path))
    make_contact_sheet(cards, OUT / "v22b_schede_zoom_punti_omologhi.png")

    selection_rows = []
    for a in anchors:
        if a["attendibilita"] == "buona":
            uso = "raccomandato_verifica_visiva"
        elif a["distanza_stima_m"] <= 1.5:
            uso = "possibile_solo_se_confermato"
        else:
            uso = "non_usare_per_calibrazione"
        selection_rows.append({**a, "uso_consigliato": uso})

    with (OUT / "v22b_selezione_punti_consigliata.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = [
            "id",
            "descrizione",
            "dwg_x",
            "dwg_y",
            "model_x_guess",
            "model_y_guess",
            "distanza_stima_m",
            "attendibilita",
            "uso_consigliato",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(selection_rows)

    report = [
        "# V22B schede zoom punti omologhi",
        "",
        "Schede locali per decidere quali punti usare nella calibrazione V23.",
        "",
        "## Uso consigliato",
        "",
    ]
    for r in selection_rows:
        report.append(f"- {r['id']}: {r['uso_consigliato']} | distanza {r['distanza_stima_m']:.2f} m | {r['descrizione']}")
    report.extend(
        [
            "",
            "## Output",
            "",
            "- `v22b_schede_zoom_punti_omologhi.png`",
            "- `zoom_punti/v22b_zoom_P01.png` ... `zoom_punti/v22b_zoom_P12.png`",
            "- `v22b_selezione_punti_consigliata.csv`",
            "",
            "La calibrazione V23 richiede almeno 4 punti reali confermati; al momento risultano raccomandabili automaticamente solo P09 e P12.",
        ]
    )
    (OUT / "v22b_schede_zoom_report.md").write_text("\n".join(report), encoding="utf-8")
    print("Schede zoom V22B create")
    print(OUT / "v22b_schede_zoom_punti_omologhi.png")


if __name__ == "__main__":
    main()
