from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_cancella_layer_mirato_result.json")
OUT_TXT = Path("berra_cancella_layer_mirato_report.txt")
SKIP_TYPES = {"BeamSegment", "ColumnSegment"}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for element, detail in zip(elements, details):
        rows.append(
            {
                "element": element,
                "layer": layers.get(int(detail.get("layerIndex", -999)), ""),
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
            }
        )
    return rows


def delete_elements(commands, types, rows, chunk_size=80):
    results = []
    elements = [row["element"] for row in rows if row["type"] not in SKIP_TYPES]
    for start in range(0, len(elements), chunk_size):
        chunk = elements[start:start + chunk_size]
        result = tapir(commands, types, "DeleteElements", {"elements": chunk})
        results.append({"start": start, "count": len(chunk), "result": result})
    return results


def main():
    if len(sys.argv) < 3 or sys.argv[1].upper() != "CANCELLA":
        print("Cancella gli elementi di un singolo layer indicato.")
        print("Uso: py 68_tapir_cancella_layer_mirato.py CANCELLA NOME_LAYER")
        return
    target_layer = " ".join(sys.argv[2:])
    if not target_layer.startswith("BERRA_"):
        raise SystemExit("Per sicurezza questo script cancella solo layer che iniziano con BERRA_.")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types

    before = get_rows(commands, types)
    to_delete = [row for row in before if row["layer"] == target_layer and row["type"] not in SKIP_TYPES]
    delete_result = delete_elements(commands, types, to_delete)
    after = get_rows(commands, types)

    payload = {
        "targetLayer": target_layer,
        "deletedRequested": len(to_delete),
        "deletedByType": dict(Counter(row["type"] for row in to_delete)),
        "remainingOnTargetLayer": sum(1 for row in after if row["layer"] == target_layer and row["type"] not in SKIP_TYPES),
        "deleteResult": delete_result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - CANCELLAZIONE LAYER MIRATO",
                "=" * 40,
                f"Layer bersaglio: {target_layer}",
                f"Elementi richiesti in cancellazione: {payload['deletedRequested']}",
                f"Elementi rimasti sul layer: {payload['remainingOnTargetLayer']}",
                "Cancellati per tipo:",
                *(f"- {typ}: {count}" for typ, count in sorted(payload["deletedByType"].items())),
            ]
        ),
        encoding="utf-8",
    )
    print(f"Layer bersaglio: {target_layer}")
    print(f"Elementi richiesti in cancellazione: {payload['deletedRequested']}")
    print(f"Elementi rimasti sul layer: {payload['remainingOnTargetLayer']}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
