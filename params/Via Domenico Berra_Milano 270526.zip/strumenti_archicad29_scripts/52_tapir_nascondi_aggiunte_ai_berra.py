from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_hide_ai_additions_result.json")
OUT_TXT = Path("berra_hide_ai_additions_report.txt")
HIDDEN_LAYER = "BERRA_STANDBY_NASCOSTO_AGGIUNTE_AI"

HIDE_PREFIXES = (
    "BERRA_BIM_V02_",
    "BERRA_BIM_V03_",
    "BERRA_BIM_V04_",
)
HIDE_EXACT = {
    "BERRA_AI_DETTAGLI_01",
}
KEEP_EXACT = {
    "BERRA_AI_COPERTURE_02",
    "Shell - Copertura",
    "Strutturale - Portante",
    "Interni - Arredo",
    "Forma - Generale",
    "Marker - Alzato",
    "Disegno 2D - Generale",
    "Disegni e Immagini",
    "Quotatura - Generale",
}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def normalize(elements):
    out = []
    for element in elements or []:
        if "elementId" in element:
            out.append(element)
        elif "guid" in element:
            out.append({"elementId": {"guid": element["guid"]}})
    return out


def layer_attributes(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return result.get("attributes", [])


def layer_index(commands, types, layer_name):
    for layer in layer_attributes(commands, types):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_hidden_layer(commands, types):
    existing = layer_index(commands, types, HIDDEN_LAYER)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": HIDDEN_LAYER,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 190,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, HIDDEN_LAYER)
    if created is None:
        raise RuntimeError(f"Non riesco a creare il layer nascosto {HIDDEN_LAYER}")
    return created


def layers_map(commands, types):
    return {int(layer["index"]): str(layer.get("name", "")) for layer in layer_attributes(commands, types)}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for element, detail in zip(elements, details):
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        rows.append({"element": element, "layer": layer, "type": detail.get("type", ""), "id": detail.get("id", "")})
    return rows


def should_hide(layer):
    if layer in KEEP_EXACT:
        return False
    if layer in HIDE_EXACT:
        return True
    return any(layer.startswith(prefix) for prefix in HIDE_PREFIXES)


def set_layer(commands, types, elements, target_layer, chunk_size=120):
    elements = normalize(elements)
    if not elements:
        return None
    results = []
    for start in range(0, len(elements), chunk_size):
        chunk = elements[start:start + chunk_size]
        result = tapir(
            commands,
            types,
            "SetDetailsOfElements",
            {
                "elementsWithDetails": [
                    {"elementId": element["elementId"], "details": {"layerIndex": int(target_layer)}} for element in chunk
                ]
            },
        )
        results.append({"start": start, "count": len(chunk), "result": result})
    return results


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Sposta tutte le aggiunte automatiche AI/BIM in un layer nascosto, senza cancellare nulla.")
        print("Uso: py 52_tapir_nascondi_aggiunte_ai_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    hidden_index = create_hidden_layer(commands, types)
    rows = get_rows(commands, types)
    to_move = [row for row in rows if row["layer"] != HIDDEN_LAYER and should_hide(row["layer"])]
    result = set_layer(commands, types, [row["element"] for row in to_move], hidden_index)

    after = get_rows(commands, types)
    layer_counts = Counter(row["layer"] for row in after)
    moved_by_layer = Counter(row["layer"] for row in to_move)
    moved_by_type = Counter(row["type"] for row in to_move)
    hidden_attrs = [layer for layer in layer_attributes(commands, types) if str(layer.get("name", "")) == HIDDEN_LAYER]

    payload = {
        "hiddenLayer": HIDDEN_LAYER,
        "hiddenLayerIndex": hidden_index,
        "hiddenLayerAttributes": hidden_attrs,
        "movedCount": len(to_move),
        "movedByLayer": dict(moved_by_layer),
        "movedByType": dict(moved_by_type),
        "remainingLayerCounts": dict(layer_counts),
        "tapirResult": result,
        "note": "Non sono stati toccati Shell - Copertura e BERRA_AI_COPERTURE_02.",
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - AGGIUNTE AI NASCOSTE",
                "=" * 32,
                f"Layer nascosto: {HIDDEN_LAYER} (index {hidden_index})",
                f"Elementi spostati: {len(to_move)}",
                "",
                "Layer spostati:",
                *(f"- {layer}: {count}" for layer, count in sorted(moved_by_layer.items(), key=lambda item: (-item[1], item[0]))),
                "",
                "Tipi spostati:",
                *(f"- {typ}: {count}" for typ, count in sorted(moved_by_type.items(), key=lambda item: (-item[1], item[0]))),
                "",
                "Layer rimasti principali:",
                *(f"- {layer}: {count}" for layer, count in sorted(layer_counts.items(), key=lambda item: (-item[1], item[0]))[:20]),
                "",
                "Nota: Shell - Copertura e BERRA_AI_COPERTURE_02 non sono stati modificati.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Elementi spostati nel layer nascosto: {len(to_move)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
