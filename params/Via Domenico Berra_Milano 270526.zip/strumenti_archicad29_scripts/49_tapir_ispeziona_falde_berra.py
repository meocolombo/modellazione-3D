from __future__ import annotations

import json
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_roof_details_current.json")
OUT_TXT = Path("berra_roof_details_current.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    layers = layers_map(commands, types)
    roofs = []
    for element, detail, box_item in zip(elements, details, boxes):
        if detail.get("type") != "Roof":
            continue
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        box = box_item.get("boundingBox3D", {})
        roofs.append(
            {
                "guid": element.get("elementId", {}).get("guid", ""),
                "id": detail.get("id", ""),
                "layer": layer,
                "detailsKeys": sorted((detail.get("details") or {}).keys()),
                "details": detail.get("details") or {},
                "bbox": box,
            }
        )
    OUT_JSON.write_text(json.dumps(roofs, indent=2), encoding="utf-8")
    lines = [
        f"Falde lette: {len(roofs)}",
        "",
    ]
    for idx, roof in enumerate(roofs, start=1):
        box = roof["bbox"]
        lines.extend(
            [
                f"{idx}. layer={roof['layer']} id={roof['id']} guid={roof['guid']}",
                f"   bbox X {box.get('xMin')}..{box.get('xMax')} Y {box.get('yMin')}..{box.get('yMax')} Z {box.get('zMin')}..{box.get('zMax')}",
                f"   detail keys: {', '.join(roof['detailsKeys'])}",
                "",
            ]
        )
    OUT_TXT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Creato: {OUT_JSON}")
    print(f"Creato: {OUT_TXT}")


if __name__ == "__main__":
    main()
