from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


STANDBY_LAYER = "BERRA_BIM_V03_STANDBY_PRECEDENTI"
TARGET_PREFIX = "BERRA_BIM_V03_"
OUT_JSON = Path("berra_v03_standby_visibili_result.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def normalize(elements):
    out = []
    for el in elements or []:
        if "elementId" in el:
            out.append(el)
        elif "guid" in el:
            out.append({"elementId": {"guid": el["guid"]}})
    return out


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group=169):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": True,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": group,
                }
            ],
            "overwriteExisting": False,
        },
    )
    return layer_index(commands, types, name)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for el, detail in zip(elements, details):
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        rows.append({"element": el, "type": detail.get("type", ""), "layer": layer, "id": detail.get("id", "")})
    return rows


def set_layer(commands, types, elements, layer_idx):
    elements = normalize(elements)
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": el["elementId"], "details": {"layerIndex": int(layer_idx)}} for el in elements
            ]
        },
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Sposta in standby nascosto tutti i layer BERRA_BIM_V03_* visibili.")
        print("Uso: py 46_tapir_standby_v03_visibili_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby = create_or_get_layer(commands, types, STANDBY_LAYER)
    rows = get_rows(commands, types)
    to_move = [
        row for row in rows
        if row["layer"].startswith(TARGET_PREFIX) and row["layer"] != STANDBY_LAYER
    ]
    result = set_layer(commands, types, [row["element"] for row in to_move], standby)
    counts_by_layer = Counter(row["layer"] for row in to_move)
    counts_by_type = Counter(row["type"] for row in to_move)
    payload = {
        "moved": len(to_move),
        "standbyLayer": STANDBY_LAYER,
        "countsByLayer": dict(counts_by_layer),
        "countsByType": dict(counts_by_type),
        "tapirResult": result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Elementi V03 spostati in standby: {len(to_move)}")
    for layer, count in counts_by_layer.items():
        print(f"- {layer}: {count}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
