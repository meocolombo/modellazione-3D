from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_delete_ai_additions_result.json")
OUT_TXT = Path("berra_delete_ai_additions_report.txt")

DELETE_PREFIXES = (
    "BERRA_BIM_V02_",
    "BERRA_BIM_V03_",
    "BERRA_BIM_V04_",
)
DELETE_EXACT = {
    "BERRA_AI_DETTAGLI_01",
    "BERRA_STANDBY_NASCOSTO_AGGIUNTE_AI",
}
KEEP_EXACT = {
    "BERRA_AI_COPERTURE_02",
    "Shell - Copertura",
    "Strutturale - Portante",
    "Interni - Arredo",
    "Forma - Generale",
    "Marker - Alzato",
    "Disegno 2D - Generale",
    "Disegni e Immagini",
    "Quotatura - Generale",
}
SKIP_TYPES = {
    "BeamSegment",
    "ColumnSegment",
}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def normalize(elements):
    out = []
    for element in elements or []:
        if "elementId" in element:
            out.append(element)
        elif "guid" in element:
            out.append({"elementId": {"guid": element["guid"]}})
    return out


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for element, detail in zip(elements, details):
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        rows.append({"element": element, "layer": layer, "type": detail.get("type", ""), "id": detail.get("id", "")})
    return rows


def should_delete(row):
    layer = row["layer"]
    if layer in KEEP_EXACT:
        return False
    if row["type"] in SKIP_TYPES:
        return False
    if layer in DELETE_EXACT:
        return True
    return any(layer.startswith(prefix) for prefix in DELETE_PREFIXES)


def delete_elements(commands, types, elements, chunk_size=80):
    elements = normalize(elements)
    results = []
    for start in range(0, len(elements), chunk_size):
        chunk = elements[start:start + chunk_size]
        result = tapir(commands, types, "DeleteElements", {"elements": chunk})
        results.append({"start": start, "count": len(chunk), "result": result})
    return results


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "CANCELLA":
        print("Cancella in modo mirato le aggiunte automatiche AI/BIM errate.")
        print("Uso: py 54_tapir_cancella_aggiunte_ai_berra.py CANCELLA")
        print("Non tocca Shell - Copertura, BERRA_AI_COPERTURE_02 o layer base.")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types

    before = get_rows(commands, types)
    to_delete = [row for row in before if should_delete(row)]
    delete_result = delete_elements(commands, types, [row["element"] for row in to_delete])
    after = get_rows(commands, types)

    payload = {
        "deletedRequested": len(to_delete),
        "deletedByLayer": dict(Counter(row["layer"] for row in to_delete)),
        "deletedByType": dict(Counter(row["type"] for row in to_delete)),
        "remainingByLayer": dict(Counter(row["layer"] for row in after)),
        "remainingByType": dict(Counter(row["type"] for row in after)),
        "deleteResult": delete_result,
        "note": "Non sono stati toccati Shell - Copertura, BERRA_AI_COPERTURE_02 e layer base.",
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - CANCELLAZIONE AGGIUNTE AI",
                "=" * 36,
                f"Elementi richiesti in cancellazione: {len(to_delete)}",
                "",
                "Cancellati per layer:",
                *(f"- {layer}: {count}" for layer, count in sorted(payload["deletedByLayer"].items(), key=lambda item: (-item[1], item[0]))),
                "",
                "Cancellati per tipo:",
                *(f"- {typ}: {count}" for typ, count in sorted(payload["deletedByType"].items(), key=lambda item: (-item[1], item[0]))),
                "",
                "Layer rimasti:",
                *(f"- {layer}: {count}" for layer, count in sorted(payload["remainingByLayer"].items(), key=lambda item: (-item[1], item[0]))),
                "",
                "Nota: Shell - Copertura, BERRA_AI_COPERTURE_02 e layer base non sono stati toccati.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Elementi richiesti in cancellazione: {len(to_delete)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
