from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


SOURCE_CSV = Path(r"E:\strumenti-archicad29\berra_3ds_chunk_objects.csv")
LAYER_NAME = "BERRA_V13_STRUTTURA_3DS_ALLINEATA"
STANDBY_LAYER = "BERRA_STANDBY_REVISIONE_STRUTTURE_FINITURE"
OLD_STRUCTURE_LAYER = "BERRA_V12_STRUTTURA_CAMPATE"
OUT_CSV = Path(r"E:\strumenti-archicad29\berra_v13_struttura_3ds_allineata_elementi.csv")
OUT_JSON = Path(r"E:\strumenti-archicad29\berra_v13_struttura_3ds_allineata_result.json")
OUT_TXT = Path(r"E:\strumenti-archicad29\berra_v13_struttura_3ds_allineata_report.txt")
SKIP_TYPES = {"BeamSegment", "ColumnSegment"}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, layer_name, hidden, group_nr):
    existing = find_layer_index(commands, types, layer_name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": layer_name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group_nr),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, layer_name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {layer_name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_rows(commands, types):
    layers = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    rows = []
    for element, detail in zip(elements, details):
        rows.append(
            {
                "element": element,
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
                "layer": layers.get(int(detail.get("layerIndex", -999)), ""),
            }
        )
    return rows


def move_old_structure_to_standby(commands, types, standby_index):
    rows = [
        row
        for row in get_rows(commands, types)
        if row["layer"] == OLD_STRUCTURE_LAYER and row["type"] not in SKIP_TYPES
    ]
    if not rows:
        return {"moved": 0}
    result = tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": int(standby_index)}}
                for row in rows
            ]
        },
    )
    return {"moved": len(rows), "result": result}


def count_layer(commands, types, layer_name):
    return sum(1 for row in get_rows(commands, types) if row["layer"] == layer_name and row["type"] not in SKIP_TYPES)


def read_candidates():
    if not SOURCE_CSV.exists():
        raise FileNotFoundError(f"CSV 3DS non trovato: {SOURCE_CSV}")
    with SOURCE_CSV.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter=";"))

    candidates = []
    seen = set()
    for source in rows:
        if source.get("class") != "piano_sottile":
            continue
        x1 = float(source["xMin"])
        x2 = float(source["xMax"])
        y1 = float(source["yMin"])
        y2 = float(source["yMax"])
        z1 = float(source["zMin"])
        z2 = float(source["zMax"])
        dx = x2 - x1
        dy = y2 - y1
        dz = z2 - z1
        long_span = max(dx, dy)
        thin_span = min(dx, dy)
        if long_span < 2.0 or thin_span > 0.22:
            continue
        if dz < 0.035 or dz > 0.18:
            continue
        if z2 < 3.2 or z2 > 12.0:
            continue
        key = (
            round(x1, 2),
            round(x2, 2),
            round(y1, 2),
            round(y2, 2),
            round(z1, 2),
            round(z2, 2),
        )
        if key in seen:
            continue
        seen.add(key)
        horizontal = dx >= dy
        if horizontal:
            bx1, by1 = x1, (y1 + y2) / 2.0
            bx2, by2 = x2, (y1 + y2) / 2.0
        else:
            bx1, by1 = (x1 + x2) / 2.0, y1
            bx2, by2 = (x1 + x2) / 2.0, y2
        candidates.append(
            {
                "sourceName": source["name"],
                "begCoordinate": coord(bx1, by1),
                "endCoordinate": coord(bx2, by2),
                "zCoordinate": (z1 + z2) / 2.0,
                "width": max(0.055, thin_span),
                "height": max(0.055, dz),
                "x1": round(bx1, 4),
                "y1": round(by1, 4),
                "x2": round(bx2, 4),
                "y2": round(by2, 4),
                "z": round((z1 + z2) / 2.0, 4),
                "length": round(long_span, 4),
                "thin": round(thin_span, 4),
                "dz": round(dz, 4),
            }
        )
    candidates.sort(key=lambda row: (row["z"], row["y1"], row["x1"], row["sourceName"]))
    return candidates


def create_beams(commands, types, candidates):
    created = []
    failures = []
    for index, row in enumerate(candidates, start=1):
        code = f"BER-V13-3DS-TRV-{index:03d}"
        data = {
            "begCoordinate": row["begCoordinate"],
            "endCoordinate": row["endCoordinate"],
            "zCoordinate": row["zCoordinate"],
            "width": row["width"],
            "height": row["height"],
        }
        try:
            result = tapir(commands, types, "CreateBeams", {"beamsData": [data]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": code, "sourceName": row["sourceName"], "error": "nessun elemento restituito"})
                continue
            created.append({**row, "code": code, "element": elements[0]})
        except Exception as exc:
            failures.append({"code": code, "sourceName": row["sourceName"], "error": str(exc)})
    return created, failures


def set_layer(commands, types, rows, layer_index):
    if not rows:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": row["element"]["elementId"], "details": {"layerIndex": int(layer_index)}}
                for row in rows
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def set_ids(commands, types, rows):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(rows), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in rows:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(rows), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def write_outputs(candidates, created, failures, moved_old, set_layer_result, id_result):
    fields = [
        "codice_id",
        "guid",
        "source_3ds",
        "x1",
        "y1",
        "x2",
        "y2",
        "z",
        "larghezza",
        "altezza",
        "lunghezza_m",
        "volume_stimato_m3",
    ]
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        for row in created:
            volume = row["length"] * row["width"] * row["height"]
            writer.writerow(
                {
                    "codice_id": row["code"],
                    "guid": row["element"]["elementId"]["guid"],
                    "source_3ds": row["sourceName"],
                    "x1": row["x1"],
                    "y1": row["y1"],
                    "x2": row["x2"],
                    "y2": row["y2"],
                    "z": row["z"],
                    "larghezza": round(row["width"], 4),
                    "altezza": round(row["height"], 4),
                    "lunghezza_m": row["length"],
                    "volume_stimato_m3": round(volume, 5),
                }
            )

    payload = {
        "sourceCsv": str(SOURCE_CSV),
        "layer": LAYER_NAME,
        "oldStructureLayerMovedToStandby": moved_old,
        "candidateCount": len(candidates),
        "created": len(created),
        "failures": failures,
        "setLayerResult": set_layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V13 - STRUTTURA DA 3DS ALLINEATA",
                "=" * 48,
                f"Layer: {LAYER_NAME}",
                f"Sorgente 3DS CSV: {SOURCE_CSV}",
                f"V12 struttura spostata in stand-by: {moved_old}",
                f"Candidati 3DS: {len(candidates)}",
                f"Elementi creati: {len(created)}",
                f"Fallimenti: {len(failures)}",
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea travi/assiti allineati ai piani sottili estratti dal 3DS.")
        print("Uso: py 74_tapir_v13_struttura_da_3ds_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types, LAYER_NAME, False, 193)
    standby_index = create_or_get_layer(commands, types, STANDBY_LAYER, True, 190)
    if count_layer(commands, types, LAYER_NAME):
        print(f"Layer {LAYER_NAME} gia popolato. Nessuna modifica.")
        return

    moved_old = move_old_structure_to_standby(commands, types, standby_index)
    candidates = read_candidates()
    created, failures = create_beams(commands, types, candidates)
    set_layer_result = set_layer(commands, types, created, layer_index)
    id_result = set_ids(commands, types, created)
    write_outputs(candidates, created, failures, moved_old, set_layer_result, id_result)
    print("BERRA V13 struttura da 3DS applicata.")
    print(f"Candidati: {len(candidates)}")
    print(f"Elementi creati: {len(created)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
