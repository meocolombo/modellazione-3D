from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


SOURCE_FACES = Path(r"E:\strumenti-archicad29\berra_ifc_roof_faces.csv")
LAYER_NAME = "BERRA_V14_STRISCE_FALDE_IFC"
OUT_CSV = Path(r"E:\strumenti-archicad29\berra_v14_strisce_falde_ifc_elementi.csv")
OUT_JSON = Path(r"E:\strumenti-archicad29\berra_v14_strisce_falde_ifc_result.json")
OUT_TXT = Path(r"E:\strumenti-archicad29\berra_v14_strisce_falde_ifc_report.txt")
SKIP_TYPES = {"BeamSegment", "ColumnSegment"}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def point3(p):
    return {"x": float(p[0]), "y": float(p[1]), "z": float(p[2])}


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def norm(a):
    length = math.sqrt(dot(a, a))
    if length <= 1e-12:
        return (0.0, 0.0, 0.0)
    return (a[0] / length, a[1] / length, a[2] / length)


def polygon_area_3d(points):
    if len(points) < 3:
        return 0.0
    total = (0.0, 0.0, 0.0)
    base = points[0]
    for i in range(1, len(points) - 1):
        total = add(total, cross(sub(points[i], base), sub(points[i + 1], base)))
    return 0.5 * math.sqrt(dot(total, total))


def polygon_area_2d(poly):
    if len(poly) < 3:
        return 0.0
    area = 0.0
    for i, p in enumerate(poly):
        q = poly[(i + 1) % len(poly)]
        area += p[0] * q[1] - q[0] * p[1]
    return abs(area) * 0.5


def face_normal(points):
    if len(points) < 3:
        return (0.0, 0.0, 0.0)
    base = points[0]
    for i in range(1, len(points) - 1):
        n = cross(sub(points[i], base), sub(points[i + 1], base))
        if dot(n, n) > 1e-9:
            n = norm(n)
            return n if n[2] >= 0 else mul(n, -1.0)
    return (0.0, 0.0, 0.0)


def longest_edge_axis(points):
    best = None
    best_len = 0.0
    for i, p in enumerate(points):
        q = points[(i + 1) % len(points)]
        edge = sub(q, p)
        length = math.sqrt(dot(edge, edge))
        if length > best_len:
            best_len = length
            best = edge
    return norm(best or (1.0, 0.0, 0.0))


def clip_halfplane(poly, axis, limit, keep_greater):
    if not poly:
        return []

    def inside(point):
        value = point[axis]
        return value >= limit - 1e-9 if keep_greater else value <= limit + 1e-9

    def intersect(a, b):
        av = a[axis]
        bv = b[axis]
        if abs(bv - av) <= 1e-12:
            return b
        t = (limit - av) / (bv - av)
        return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)

    out = []
    prev = poly[-1]
    prev_inside = inside(prev)
    for cur in poly:
        cur_inside = inside(cur)
        if cur_inside:
            if not prev_inside:
                out.append(intersect(prev, cur))
            out.append(cur)
        elif prev_inside:
            out.append(intersect(prev, cur))
        prev = cur
        prev_inside = cur_inside
    return out


def clip_rect(poly, umin, umax, vmin, vmax):
    result = clip_halfplane(poly, 0, umin, True)
    result = clip_halfplane(result, 0, umax, False)
    result = clip_halfplane(result, 1, vmin, True)
    result = clip_halfplane(result, 1, vmax, False)
    return clean_poly(result)


def clean_poly(poly):
    cleaned = []
    for point in poly:
        if not cleaned or math.hypot(point[0] - cleaned[-1][0], point[1] - cleaned[-1][1]) > 1e-5:
            cleaned.append(point)
    if len(cleaned) > 1 and math.hypot(cleaned[0][0] - cleaned[-1][0], cleaned[0][1] - cleaned[-1][1]) <= 1e-5:
        cleaned.pop()
    return cleaned


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 194,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non creato: {LAYER_NAME}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def count_layer(commands, types):
    layers = layers_map(commands, types)
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    count = 0
    for detail in details:
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        if layer == LAYER_NAME and detail.get("type", "") not in SKIP_TYPES:
            count += 1
    return count


def read_roof_faces():
    faces = []
    with SOURCE_FACES.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            points = [tuple(float(value) for value in point) for point in json.loads(row["points"])]
            n = face_normal(points)
            area = polygon_area_3d(points)
            if n[2] < 0.25 or area < 2.0:
                continue
            faces.append(
                {
                    "roof_id": row["roof_id"],
                    "roof_guid": row["roof_guid"],
                    "face_no": int(row["face_no"]),
                    "normal": n,
                    "area": area,
                    "points": points,
                }
            )
    faces.sort(key=lambda item: (item["roof_id"], item["face_no"]))
    return faces


def build_strips(faces):
    strips = []
    for face in faces:
        points = face["points"]
        normal = face["normal"]
        origin = points[0]
        u_axis = longest_edge_axis(points)
        v_axis = norm(cross(normal, u_axis))
        if dot(v_axis, v_axis) <= 1e-12:
            continue
        local = [(dot(sub(p, origin), u_axis), dot(sub(p, origin), v_axis)) for p in points]
        u_values = [p[0] for p in local]
        v_values = [p[1] for p in local]
        umin, umax = min(u_values), max(u_values)
        vmin, vmax = min(v_values), max(v_values)
        width = vmax - vmin
        if width <= 0.55 or umax - umin <= 1.0:
            continue
        count = max(1, min(5, int(round(width / 2.6))))
        half = 0.045
        centers = [vmin + (vmax - vmin) * (i + 1) / (count + 1) for i in range(count)]
        for center in centers:
            clipped = clip_rect(local, umin - 0.01, umax + 0.01, center - half, center + half)
            if len(clipped) < 3 or polygon_area_2d(clipped) < 0.08:
                continue
            strip_points = []
            for u, v in clipped:
                p = add(origin, add(mul(u_axis, u), mul(v_axis, v)))
                p = add(p, mul(normal, 0.035))
                strip_points.append(p)
            strips.append(
                {
                    "roof_id": face["roof_id"],
                    "roof_guid": face["roof_guid"],
                    "face_no": face["face_no"],
                    "area": polygon_area_3d(strip_points),
                    "points": strip_points,
                }
            )
    return strips


def create_meshes(commands, types, strips):
    created = []
    failures = []
    for index, strip in enumerate(strips, start=1):
        code = f"BER-V14-FLD-STR-{index:03d}"
        data = {
            "level": 0.0,
            "ridges": "AllSharp",
            "showLines": False,
            "polygonCoordinates": [point3(p) for p in strip["points"]],
        }
        try:
            result = tapir(commands, types, "CreateMeshes", {"meshesData": [data]})
            elements = result.get("elements", [])
            if not elements:
                failures.append({"code": code, "roof_id": strip["roof_id"], "face_no": strip["face_no"], "error": "nessun elemento restituito"})
                continue
            created.append({**strip, "code": code, "element": elements[0]})
        except Exception as exc:
            failures.append({"code": code, "roof_id": strip["roof_id"], "face_no": strip["face_no"], "error": str(exc)})
    return created, failures


def set_layer(commands, types, created, layer_index):
    if not created:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": item["element"]["elementId"], "details": {"layerIndex": int(layer_index)}}
                for item in created
            ]
        },
    )


def get_general_element_id_property(commands):
    prop_names = commands.GetAllPropertyNames()
    prop_ids = commands.GetPropertyIds(prop_names)
    for prop_name, prop_id in zip(prop_names, prop_ids):
        if getattr(prop_name, "nonLocalizedName", "") == "General_ElementID":
            return getattr(prop_id, "propertyId", prop_id)
    return None


def native_guid(element):
    element_id = getattr(element, "elementId", None)
    guid = getattr(element_id, "guid", None)
    return str(guid).upper() if guid else ""


def set_ids(commands, types, created):
    prop_id = get_general_element_id_property(commands)
    if prop_id is None:
        return {"ok": 0, "failed": len(created), "error": "General_ElementID non trovata"}
    native_by_guid = {native_guid(element): element for element in commands.GetAllElements()}
    changes = []
    missing = 0
    for row in created:
        guid = row["element"]["elementId"]["guid"].upper()
        native = native_by_guid.get(guid)
        if native is None:
            missing += 1
            continue
        changes.append(types.ElementPropertyValue(native.elementId, prop_id, types.NormalStringPropertyValue(row["code"])))
    if not changes:
        return {"ok": 0, "failed": len(created), "missingNativeElements": missing}
    results = commands.SetPropertyValuesOfElements(changes)
    ok = 0
    failed = 0
    for result in results:
        text = repr(result)
        if "success': True" in text or "success=True" in text:
            ok += 1
        else:
            failed += 1
    return {"ok": ok, "failed": failed, "missingNativeElements": missing}


def write_outputs(faces, strips, created, failures, set_layer_result, id_result):
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["codice_id", "guid", "roof_id", "roof_guid", "face_no", "area_m2", "punti"]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        for item in created:
            writer.writerow(
                {
                    "codice_id": item["code"],
                    "guid": item["element"]["elementId"]["guid"],
                    "roof_id": item["roof_id"],
                    "roof_guid": item["roof_guid"],
                    "face_no": item["face_no"],
                    "area_m2": round(item["area"], 4),
                    "punti": json.dumps([[round(value, 4) for value in p] for p in item["points"]]),
                }
            )
    by_roof = Counter(item["roof_id"] for item in created)
    payload = {
        "layer": LAYER_NAME,
        "sourceFaces": str(SOURCE_FACES),
        "facesUsed": len(faces),
        "stripsGenerated": len(strips),
        "created": len(created),
        "failures": failures,
        "byRoof": dict(by_roof),
        "setLayerResult": set_layer_result,
        "idResult": id_result,
        "csv": str(OUT_CSV),
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V14 - STRISCE SU FALDE IFC",
                "=" * 42,
                f"Layer: {LAYER_NAME}",
                f"Facce falda usate: {len(faces)}",
                f"Strisce generate: {len(strips)}",
                f"Elementi creati: {len(created)}",
                f"Fallimenti: {len(failures)}",
                "Per copertura:",
                *(f"- {roof}: {count}" for roof, count in sorted(by_roof.items())),
                f"ID General_ElementID: {id_result}",
                f"CSV: {OUT_CSV}",
                f"JSON: {OUT_JSON}",
            ]
        ),
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Crea strisce mesh aderenti alle falde reali estratte da IFC.")
        print("Uso: py 77_tapir_v14_strisce_falde_ifc_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)
    if count_layer(commands, types):
        print(f"Layer {LAYER_NAME} gia popolato. Nessuna modifica.")
        return
    faces = read_roof_faces()
    strips = build_strips(faces)
    created, failures = create_meshes(commands, types, strips)
    set_layer_result = set_layer(commands, types, created, layer_index)
    id_result = set_ids(commands, types, created)
    write_outputs(faces, strips, created, failures, set_layer_result, id_result)
    print("BERRA V14 strisce su falde IFC applicata.")
    print(f"Facce usate: {len(faces)}")
    print(f"Elementi creati: {len(created)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
