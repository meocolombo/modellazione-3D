from __future__ import annotations

import json
from pathlib import Path

from archicad import ACConnection


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
PIPELINE = ROOT / "output_berra_v17_ufficiale_pipeline"

SOURCE_LAYER = "BERRA_V19_RIF_ASSI_CAPRIATE_DA_VERIFICARE"
STANDBY_LAYER = "BERRA_STANDBY_V19_RIF_ASSI_CAPRIATE_NON_ALLINEATI"

OUT_JSON = PIPELINE / "berra_v19_standby_non_allineati_result.json"
OUT_REPORT = PIPELINE / "berra_v19_standby_non_allineati_report.md"


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def normalize_elements(elements):
    normalized = []
    for element in elements or []:
        if "elementId" in element:
            normalized.append(element)
        elif "guid" in element:
            normalized.append({"elementId": {"guid": element["guid"]}})
    return normalized


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group, hidden=True):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {name}")
    return created


def main():
    conn = ACConnection.connect()
    assert conn
    commands = conn.commands
    types = conn.types

    source_idx = layer_index(commands, types, SOURCE_LAYER)
    standby_idx = create_or_get_layer(commands, types, STANDBY_LAYER, 221, hidden=True)

    moved = 0
    result = None
    if source_idx is not None:
        elements = tapir(commands, types, "GetAllElements").get("elements", [])
        details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
        to_move = []
        for element, detail in zip(elements, details):
            try:
                if int(detail.get("layerIndex", -1)) == int(source_idx):
                    to_move.append(element)
            except Exception:
                continue
        normalized = normalize_elements(to_move)
        moved = len(normalized)
        if normalized:
            result = tapir(
                commands,
                types,
                "SetDetailsOfElements",
                {
                    "elementsWithDetails": [
                        {"elementId": element["elementId"], "details": {"layerIndex": int(standby_idx)}}
                        for element in normalized
                    ]
                },
            )

    payload = {
        "sourceLayer": SOURCE_LAYER,
        "standbyLayer": STANDBY_LAYER,
        "sourceLayerIndex": source_idx,
        "standbyLayerIndex": standby_idx,
        "moved": moved,
        "result": result,
    }
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    OUT_REPORT.write_text(
        "\n".join(
            [
                "# Berra V19 - standby assi non allineati",
                "",
                f"- Layer origine: `{SOURCE_LAYER}`",
                f"- Layer standby: `{STANDBY_LAYER}`",
                f"- Elementi spostati: {moved}",
                "",
                "Motivo: gli assi V19 non risultavano allineati all'edificio nel modello Archicad.",
                "Non usare V19 come base per modellare capriate definitive.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"Elementi V19 spostati in standby: {moved}")
    print(f"Report: {OUT_REPORT}")


if __name__ == "__main__":
    main()

