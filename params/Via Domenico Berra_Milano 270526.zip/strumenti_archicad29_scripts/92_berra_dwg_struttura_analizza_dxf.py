from __future__ import annotations

import csv
import math
from collections import Counter, defaultdict
from pathlib import Path

import ezdxf
from PIL import Image, ImageDraw


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
OUT = ROOT / "output_berra_dwg_struttura_110626"
DXF = OUT / "268_BERRA_10_BACKUP_PRIMA_AI_V03_from_dwg.dxf"


def add_point(bbox: list[float | None], x: float, y: float) -> None:
    if bbox[0] is None or x < bbox[0]:
        bbox[0] = x
    if bbox[1] is None or y < bbox[1]:
        bbox[1] = y
    if bbox[2] is None or x > bbox[2]:
        bbox[2] = x
    if bbox[3] is None or y > bbox[3]:
        bbox[3] = y


def segment_length(a: tuple[float, float], b: tuple[float, float]) -> float:
    return math.hypot(b[0] - a[0], b[1] - a[1])


def iter_points(entity):
    etype = entity.dxftype()
    if etype == "LINE":
        yield (float(entity.dxf.start.x), float(entity.dxf.start.y))
        yield (float(entity.dxf.end.x), float(entity.dxf.end.y))
    elif etype == "LWPOLYLINE":
        for p in entity.get_points("xy"):
            yield (float(p[0]), float(p[1]))
    elif etype == "POLYLINE":
        for v in entity.vertices:
            loc = v.dxf.location
            yield (float(loc.x), float(loc.y))
    elif etype in {"CIRCLE", "ARC"}:
        center = entity.dxf.center
        radius = float(entity.dxf.radius)
        if etype == "ARC":
            start = math.radians(float(entity.dxf.start_angle))
            end = math.radians(float(entity.dxf.end_angle))
            if end < start:
                end += math.tau
            steps = max(12, int(abs(end - start) / math.tau * 48))
            for i in range(steps + 1):
                a = start + (end - start) * i / steps
                yield (float(center.x) + radius * math.cos(a), float(center.y) + radius * math.sin(a))
        else:
            for i in range(64):
                a = math.tau * i / 64
                yield (float(center.x) + radius * math.cos(a), float(center.y) + radius * math.sin(a))
    elif etype in {"TEXT", "MTEXT", "INSERT", "POINT"}:
        p = entity.dxf.insert if hasattr(entity.dxf, "insert") else entity.dxf.location
        yield (float(p.x), float(p.y))
    elif etype == "SPLINE":
        for p in entity.control_points:
            yield (float(p[0]), float(p[1]))


def iter_segments(entity):
    etype = entity.dxftype()
    if etype == "LINE":
        a = (float(entity.dxf.start.x), float(entity.dxf.start.y))
        b = (float(entity.dxf.end.x), float(entity.dxf.end.y))
        yield a, b
    elif etype in {"LWPOLYLINE", "POLYLINE", "ARC", "CIRCLE", "SPLINE"}:
        pts = list(iter_points(entity))
        if len(pts) < 2:
            return
        closed = False
        if etype == "LWPOLYLINE":
            closed = bool(entity.closed)
        elif etype in {"CIRCLE"}:
            closed = True
        for a, b in zip(pts, pts[1:]):
            yield a, b
        if closed:
            yield pts[-1], pts[0]


def color_for_index(i: int) -> tuple[int, int, int]:
    palette = [
        (40, 40, 40),
        (180, 40, 40),
        (40, 110, 180),
        (20, 150, 85),
        (150, 90, 20),
        (120, 70, 170),
        (30, 150, 150),
        (180, 120, 25),
    ]
    return palette[i % len(palette)]


def render_preview(segments, path: Path, bbox: tuple[float, float, float, float]) -> None:
    minx, miny, maxx, maxy = bbox
    w, h = 1800, 2600
    margin = 80
    sx = (w - margin * 2) / max(maxx - minx, 1e-9)
    sy = (h - margin * 2) / max(maxy - miny, 1e-9)
    s = min(sx, sy)
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def tx(p: tuple[float, float]) -> tuple[int, int]:
        x = margin + (p[0] - minx) * s
        y = h - margin - (p[1] - miny) * s
        return int(round(x)), int(round(y))

    layer_ids: dict[str, int] = {}
    for seg in segments:
        layer = seg["layer"]
        layer_ids.setdefault(layer, len(layer_ids))
        c = color_for_index(layer_ids[layer])
        a = tx((seg["x1"], seg["y1"]))
        b = tx((seg["x2"], seg["y2"]))
        draw.line([a, b], fill=c, width=2)

    draw.rectangle([margin, margin, w - margin, h - margin], outline=(220, 220, 220), width=1)
    draw.text((margin, 20), "DWG struttura 110626 - preview top-down DXF", fill=(0, 0, 0))
    draw.text((margin, 42), f"bbox: {minx:.3f},{miny:.3f} -> {maxx:.3f},{maxy:.3f}", fill=(80, 80, 80))
    img.save(path, quality=92)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    doc = ezdxf.readfile(DXF)
    msp = doc.modelspace()

    entity_counts = Counter()
    layer_counts = Counter()
    layer_lengths = defaultdict(float)
    layer_bbox: dict[str, list[float | None]] = defaultdict(lambda: [None, None, None, None])
    total_bbox: list[float | None] = [None, None, None, None]
    segments = []

    for e in msp:
        etype = e.dxftype()
        layer = str(e.dxf.layer)
        entity_counts[etype] += 1
        layer_counts[layer] += 1

        for x, y in iter_points(e):
            add_point(total_bbox, x, y)
            add_point(layer_bbox[layer], x, y)

        for a, b in iter_segments(e):
            length = segment_length(a, b)
            if length <= 1e-9:
                continue
            layer_lengths[layer] += length
            segments.append(
                {
                    "layer": layer,
                    "type": etype,
                    "x1": a[0],
                    "y1": a[1],
                    "x2": b[0],
                    "y2": b[1],
                    "length": length,
                    "angle_deg": math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])),
                }
            )

    bbox_tuple = tuple(float(v) for v in total_bbox if v is not None)
    if len(bbox_tuple) != 4:
        raise RuntimeError("Nessuna geometria leggibile nel DXF")

    with (OUT / "dwg_struttura_110626_entity_counts.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["entity_type", "count"])
        for k, v in entity_counts.most_common():
            writer.writerow([k, v])

    with (OUT / "dwg_struttura_110626_layers.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["layer", "entity_count", "line_length", "min_x", "min_y", "max_x", "max_y"])
        for layer, count in layer_counts.most_common():
            bb = layer_bbox[layer]
            writer.writerow(
                [
                    layer,
                    count,
                    f"{layer_lengths[layer]:.6f}",
                    "" if bb[0] is None else f"{bb[0]:.6f}",
                    "" if bb[1] is None else f"{bb[1]:.6f}",
                    "" if bb[2] is None else f"{bb[2]:.6f}",
                    "" if bb[3] is None else f"{bb[3]:.6f}",
                ]
            )

    with (OUT / "dwg_struttura_110626_segments.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["layer", "type", "x1", "y1", "x2", "y2", "length", "angle_deg"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(segments)

    render_preview(segments, OUT / "dwg_struttura_110626_preview.png", bbox_tuple)

    minx, miny, maxx, maxy = bbox_tuple
    report = [
        "# DWG struttura 110626 - analisi DXF",
        "",
        f"File sorgente: `{DXF.name}`",
        f"Entita modelspace: {sum(entity_counts.values())}",
        f"Layer rilevati: {len(layer_counts)}",
        f"Segmenti estratti: {len(segments)}",
        "",
        "## Estensione geometrica",
        "",
        f"- min X: {minx:.3f}",
        f"- min Y: {miny:.3f}",
        f"- max X: {maxx:.3f}",
        f"- max Y: {maxy:.3f}",
        f"- larghezza: {maxx - minx:.3f}",
        f"- altezza: {maxy - miny:.3f}",
        "",
        "## Layer principali",
        "",
    ]
    for layer, count in layer_counts.most_common(20):
        report.append(f"- `{layer}`: {count} entita, lunghezza linee {layer_lengths[layer]:.2f}")
    report.extend(
        [
            "",
            "## Output",
            "",
            "- `dwg_struttura_110626_preview.png`",
            "- `dwg_struttura_110626_layers.csv`",
            "- `dwg_struttura_110626_segments.csv`",
            "- `dwg_struttura_110626_entity_counts.csv`",
            "",
            "Nota: questa analisi non importa e non modifica il modello Archicad.",
        ]
    )
    (OUT / "dwg_struttura_110626_report.md").write_text("\n".join(report), encoding="utf-8")

    print(f"DXF analizzato: {DXF}")
    print(f"Layer: {len(layer_counts)} | Entita: {sum(entity_counts.values())} | Segmenti: {len(segments)}")
    print(f"BBox: {minx:.3f},{miny:.3f} -> {maxx:.3f},{maxy:.3f}")


if __name__ == "__main__":
    main()
