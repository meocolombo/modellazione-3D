from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_TEST_SCALA_CAPRIATE"
OUT_JSON = Path("berra_test_scala_oggetti_capriate.json")
OUT_CSV = Path("berra_test_scala_oggetti_capriate.csv")
OUT_TXT = Path("berra_test_scala_oggetti_capriate.txt")

LIB_PARTS = [
    "Capriata Storica",
    "Capriata Reticolare",
    "Capriata Howe",
    "Capriata Pratt",
    "Travatura",
    "Trave Warren",
    "Trave Howe",
    "Trave Pratt",
    "Trave parabolica",
    "triangleWoodTruss_m",
]

REQ_SIZE = {"x": 5.0, "y": 0.55, "z": 1.40}
BASE_X = 220.0
BASE_Y = 220.0


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 173,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": int(layer_index)}}
                for element in elements
            ]
        },
    )


def delete_elements(commands, types, elements):
    if not elements:
        return None
    return tapir(commands, types, "DeleteElements", {"elements": elements})


def bbox_row(libpart, element, bbox):
    box = bbox.get("boundingBox3D", {})
    x_min = float(box.get("xMin", 0.0))
    x_max = float(box.get("xMax", 0.0))
    y_min = float(box.get("yMin", 0.0))
    y_max = float(box.get("yMax", 0.0))
    z_min = float(box.get("zMin", 0.0))
    z_max = float(box.get("zMax", 0.0))
    return {
        "libraryPartName": libpart,
        "guid": element.get("elementId", {}).get("guid", ""),
        "xMin": round(x_min, 4),
        "xMax": round(x_max, 4),
        "yMin": round(y_min, 4),
        "yMax": round(y_max, 4),
        "zMin": round(z_min, 4),
        "zMax": round(z_max, 4),
        "bboxX": round(x_max - x_min, 4),
        "bboxY": round(y_max - y_min, 4),
        "bboxZ": round(z_max - z_min, 4),
        "reqX": REQ_SIZE["x"],
        "reqY": REQ_SIZE["y"],
        "reqZ": REQ_SIZE["z"],
        "scaleLooksControlled": abs((x_max - x_min) - REQ_SIZE["x"]) < 0.75
        and abs((z_max - z_min) - REQ_SIZE["z"]) < 0.75,
    }


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "APPLICA":
        print("Testa temporaneamente scala/ingombro degli oggetti capriata e poi li cancella.")
        print("Uso: py 66_tapir_test_scala_oggetti_capriate.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    created = []
    rows = []
    failures = []
    for index, libpart in enumerate(LIB_PARTS):
        x = BASE_X
        y = BASE_Y + index * 3.0
        data = {
            "objectsData": [
                {
                    "libraryPartName": libpart,
                    "coordinates": point3(x, y, 0.0),
                    "dimensions": dim3(REQ_SIZE["x"], REQ_SIZE["y"], REQ_SIZE["z"]),
                }
            ]
        }
        try:
            result = tapir(commands, types, "CreateObjects", data)
            elements = result.get("elements", [])
            if not elements:
                failures.append({"libraryPartName": libpart, "error": "nessun elemento", "result": result})
                continue
            element = elements[0]
            created.append(element)
            set_elements_layer(commands, types, [element], layer_index)
            bbox = tapir(commands, types, "Get3DBoundingBoxes", {"elements": [element]}).get("boundingBoxes3D", [{}])[0]
            rows.append(bbox_row(libpart, element, bbox))
        except Exception as exc:
            failures.append({"libraryPartName": libpart, "error": str(exc)})

    delete_result = delete_elements(commands, types, created)

    fields = [
        "libraryPartName",
        "guid",
        "bboxX",
        "bboxY",
        "bboxZ",
        "reqX",
        "reqY",
        "reqZ",
        "scaleLooksControlled",
        "xMin",
        "yMin",
        "zMin",
        "xMax",
        "yMax",
        "zMax",
    ]
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    payload = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "createdTemporary": len(created),
        "deletedTemporary": len(created),
        "rows": rows,
        "failures": failures,
        "deleteResult": delete_result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "TEST SCALA OGGETTI CAPRIATE",
                "=" * 32,
                f"Oggetti temporanei creati/cancellati: {len(created)}",
                "",
                "Risultati:",
                *[
                    f"- {row['libraryPartName']}: bbox {row['bboxX']} x {row['bboxY']} x {row['bboxZ']} "
                    f"controllato={row['scaleLooksControlled']}"
                    for row in rows
                ],
                "",
                f"Fallimenti: {len(failures)}",
                f"CSV: {OUT_CSV}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Oggetti temporanei creati/cancellati: {len(created)}")
    print(f"Fallimenti: {len(failures)}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
