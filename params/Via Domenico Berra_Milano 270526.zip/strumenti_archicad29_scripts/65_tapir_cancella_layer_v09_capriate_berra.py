from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


TARGET_LAYER = "BERRA_V09_CAPRIATE_LIBRERIA"
OUT_JSON = Path("berra_v09_capriate_cancellazione_result.json")
OUT_TXT = Path("berra_v09_capriate_cancellazione_report.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(layer["index"]): str(layer.get("name", "")) for layer in result.get("attributes", [])}


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for element, detail in zip(elements, details):
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        rows.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "layer": layer,
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
            }
        )
    return rows


def delete_elements(commands, types, elements, chunk_size=80):
    results = []
    for start in range(0, len(elements), chunk_size):
        chunk = elements[start:start + chunk_size]
        result = tapir(commands, types, "DeleteElements", {"elements": chunk})
        results.append({"start": start, "count": len(chunk), "result": result})
    return results


def main():
    if len(sys.argv) < 2 or sys.argv[1].upper() != "CANCELLA":
        print(f"Cancella solo gli elementi sul layer {TARGET_LAYER}.")
        print("Uso: py 65_tapir_cancella_layer_v09_capriate_berra.py CANCELLA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")

    commands = conn.commands
    types = conn.types
    before = get_rows(commands, types)
    to_delete = [row for row in before if row["layer"] == TARGET_LAYER]
    delete_result = delete_elements(commands, types, [row["element"] for row in to_delete]) if to_delete else []
    after = get_rows(commands, types)

    payload = {
        "targetLayer": TARGET_LAYER,
        "deletedRequested": len(to_delete),
        "deletedByType": dict(Counter(row["type"] for row in to_delete)),
        "remainingOnTargetLayer": sum(1 for row in after if row["layer"] == TARGET_LAYER),
        "remainingByLayer": dict(Counter(row["layer"] for row in after)),
        "deleteResult": delete_result,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA - CANCELLAZIONE V09 CAPRIATE LIBRERIA",
                "=" * 48,
                f"Layer bersaglio: {TARGET_LAYER}",
                f"Elementi richiesti in cancellazione: {len(to_delete)}",
                f"Elementi rimasti sul layer: {payload['remainingOnTargetLayer']}",
                "Cancellati per tipo:",
                *(f"- {typ}: {count}" for typ, count in sorted(payload["deletedByType"].items())),
            ]
        ),
        encoding="utf-8",
    )
    print(f"Elementi richiesti in cancellazione: {len(to_delete)}")
    print(f"Elementi rimasti sul layer: {payload['remainingOnTargetLayer']}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
