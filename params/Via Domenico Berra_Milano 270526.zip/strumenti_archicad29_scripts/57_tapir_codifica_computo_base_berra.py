from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

from archicad import ACConnection


OUT_MAPPING = Path("berra_base_codici_id_mapping.csv")
OUT_COMPUTO = Path("berra_base_computo_preliminare.csv")
OUT_SUMMARY = Path("berra_base_computo_sintesi.csv")
OUT_JSON = Path("berra_base_codifica_result.json")
OUT_TXT = Path("berra_base_codifica_report.txt")

SKIP_LAYERS_PREFIX = ("BERRA_BIM_", "BERRA_STANDBY_")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item.get("name", "")) for item in result.get("attributes", [])}


def get_model(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    layer_names = layers_map(commands, types)
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        layer = layer_names.get(int(detail.get("layerIndex", -999)), "")
        if any(layer.startswith(prefix) for prefix in SKIP_LAYERS_PREFIX):
            continue
        box = box_item.get("boundingBox3D", {})
        rows.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "type": detail.get("type", ""),
                "old_id": detail.get("id", ""),
                "layer": layer,
                "details": detail.get("details", {}),
                "xMin": float(box.get("xMin", 0.0)),
                "xMax": float(box.get("xMax", 0.0)),
                "yMin": float(box.get("yMin", 0.0)),
                "yMax": float(box.get("yMax", 0.0)),
                "zMin": float(box.get("zMin", 0.0)),
                "zMax": float(box.get("zMax", 0.0)),
            }
        )
    return rows


def length2(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def bbox_area(row):
    return max(0.0, row["xMax"] - row["xMin"]) * max(0.0, row["yMax"] - row["yMin"])


def bbox_len(row):
    return max(row["xMax"] - row["xMin"], row["yMax"] - row["yMin"], 0.0)


def prefix_for_type(typ):
    return {
        "Wall": "MUR",
        "Slab": "SOL",
        "Roof": "COP",
        "Window": "FIN",
        "Door": "POR",
        "Object": "OGG",
        "Morph": "FRM",
        "Line": "LIN",
        "Arc": "ARC",
        "Picture": "IMG",
        "Elevation": "ALZ",
        "Dimension": "QUO",
        "AngleDimension": "QAN",
    }.get(typ, typ[:3].upper() or "ELM")


def code_for(typ, number):
    return f"BER-BASE-{prefix_for_type(typ)}-{number:03d}"


def quantity_for(row):
    typ = row["type"]
    details = row["details"] or {}
    if typ == "Wall":
        beg = details.get("begCoordinate", {})
        end = details.get("endCoordinate", {})
        if "x" in beg and "x" in end:
            qty = length2(float(beg["x"]), float(beg["y"]), float(end["x"]), float(end["y"]))
        else:
            qty = bbox_len(row)
        thickness = float(details.get("thickness", 0.0) or 0.0)
        height = float(details.get("height", row["zMax"] - row["zMin"]) or (row["zMax"] - row["zMin"]))
        return "Murature", qty, "m", thickness, qty * max(height, 0.0) * max(thickness, 0.0), "m3"
    if typ in ("Slab", "Roof"):
        area = bbox_area(row)
        thickness = max(0.0, row["zMax"] - row["zMin"])
        return ("Solai" if typ == "Slab" else "Coperture"), area, "m2", thickness, area * thickness, "m3"
    if typ in ("Window", "Door", "Object", "Morph", "Picture", "Elevation"):
        return typ, 1.0, "cad", 0.0, 1.0, "cad"
    if typ in ("Line", "Arc"):
        return typ, bbox_len(row), "m", 0.0, bbox_len(row), "m"
    return typ or "Elemento", 1.0, "cad", 0.0, 1.0, "cad"


def try_set_ids(commands, types, mapping_rows):
    updated = 0
    failed = 0
    failures = []
    for item in mapping_rows:
        element = {"elementId": {"guid": item["guid"]}}
        try:
            result = tapir(
                commands,
                types,
                "SetDetailsOfElements",
                {"elementsWithDetails": [{"elementId": element["elementId"], "details": {"id": item["codice_id"]}}]},
            )
            # Some Tapir builds return executionResults, some return a compact success.
            if isinstance(result, dict) and "executionResults" in result:
                success = all(res.get("success") for res in result.get("executionResults", []))
            else:
                success = bool(result is None or result.get("success", True))
            if success:
                updated += 1
            else:
                failed += 1
                failures.append({"guid": item["guid"], "code": item["codice_id"], "result": result})
        except Exception as exc:
            failed += 1
            failures.append({"guid": item["guid"], "code": item["codice_id"], "error": str(exc)})
    return {"updated": updated, "failed": failed, "failures": failures[:25]}


def write_csv(path, rows, fields):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def main():
    apply_ids = len(sys.argv) > 1 and sys.argv[1] == "APPLICA_ID"
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    rows = get_model(commands, types)

    counters = defaultdict(int)
    mapping = []
    computo = []
    for row in sorted(rows, key=lambda r: (r["type"], r["layer"], r["old_id"], r["guid"])):
        counters[row["type"]] += 1
        codice = code_for(row["type"], counters[row["type"]])
        category, qty1, unit1, param, qty2, unit2 = quantity_for(row)
        mapping.append(
            {
                "guid": row["guid"],
                "codice_id": codice,
                "tipo": row["type"],
                "layer": row["layer"],
                "id_precedente": row["old_id"],
            }
        )
        computo.append(
            {
                "codice_id": codice,
                "categoria": category,
                "tipo": row["type"],
                "layer": row["layer"],
                "descrizione": row["old_id"] or row["type"],
                "quantita_primaria": round(float(qty1), 4),
                "unita_primaria": unit1,
                "parametro_secondario": round(float(param), 4),
                "quantita_secondaria": round(float(qty2), 4),
                "unita_secondaria": unit2,
            }
        )

    summary_rows = []
    grouped = defaultdict(list)
    for item in computo:
        grouped[item["categoria"]].append(item)
    for category, items in sorted(grouped.items()):
        unit_counts = Counter(item["unita_primaria"] for item in items)
        main_unit = unit_counts.most_common(1)[0][0]
        qty = sum(float(item["quantita_primaria"]) for item in items if item["unita_primaria"] == main_unit)
        summary_rows.append(
            {
                "categoria": category,
                "righe": len(items),
                "unita_prevalente": main_unit,
                "quantita_primaria_totale": round(qty, 4),
            }
        )

    write_csv(OUT_MAPPING, mapping, ["guid", "codice_id", "tipo", "layer", "id_precedente"])
    write_csv(
        OUT_COMPUTO,
        computo,
        [
            "codice_id",
            "categoria",
            "tipo",
            "layer",
            "descrizione",
            "quantita_primaria",
            "unita_primaria",
            "parametro_secondario",
            "quantita_secondaria",
            "unita_secondaria",
        ],
    )
    write_csv(OUT_SUMMARY, summary_rows, ["categoria", "righe", "unita_prevalente", "quantita_primaria_totale"])

    id_result = {"updated": 0, "failed": 0, "failures": []}
    if apply_ids:
        id_result = try_set_ids(commands, types, mapping)

    payload = {
        "applyIds": apply_ids,
        "elements": len(rows),
        "countsByType": dict(Counter(row["type"] for row in rows)),
        "countsByLayer": dict(Counter(row["layer"] for row in rows)),
        "idResult": id_result,
        "outputs": {
            "mapping": str(OUT_MAPPING),
            "computo": str(OUT_COMPUTO),
            "summary": str(OUT_SUMMARY),
        },
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA BASE - CODIFICA E COMPUTO",
                "=" * 34,
                f"Elementi letti: {len(rows)}",
                f"ID applicati: {'si' if apply_ids else 'no'}",
                f"ID aggiornati: {id_result['updated']}",
                f"ID falliti: {id_result['failed']}",
                "",
                "Tipi:",
                *(f"- {typ}: {count}" for typ, count in sorted(payload["countsByType"].items(), key=lambda i: (-i[1], i[0]))),
                "",
                "Output:",
                f"- {OUT_MAPPING}",
                f"- {OUT_COMPUTO}",
                f"- {OUT_SUMMARY}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Elementi letti: {len(rows)}")
    print(f"ID applicati: {'si' if apply_ids else 'no'}")
    print(f"ID aggiornati: {id_result['updated']} falliti: {id_result['failed']}")
    print(f"Report: {OUT_TXT}")


if __name__ == "__main__":
    main()
