from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

import bpy
from mathutils import Vector


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()


def import_dae(path: Path):
    bpy.ops.wm.collada_import(filepath=str(path))


def material_name(obj, idx):
    if idx < 0 or not hasattr(obj.data, "materials") or idx >= len(obj.data.materials):
        return ""
    mat = obj.data.materials[idx]
    return mat.name if mat else ""


def polygon_area_xy(points):
    if len(points) < 3:
        return 0.0
    area = 0.0
    closed = points + [points[0]]
    for p1, p2 in zip(closed, closed[1:]):
        area += p1[0] * p2[1] - p2[0] * p1[1]
    return abs(area) / 2.0


def face_rows():
    rows = []
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH":
            continue
        mesh = obj.data
        mw = obj.matrix_world
        normal_matrix = mw.to_3x3().inverted().transposed()
        for poly in mesh.polygons:
            verts = [mw @ mesh.vertices[i].co for i in poly.vertices]
            normal = (normal_matrix @ poly.normal).normalized()
            xs = [v.x for v in verts]
            ys = [v.y for v in verts]
            zs = [v.z for v in verts]
            pts = [(v.x, v.y) for v in verts]
            area_xy = polygon_area_xy(pts)
            if area_xy < 0.005:
                continue
            z_avg = sum(zs) / len(zs)
            mat = material_name(obj, poly.material_index)
            slope = math.degrees(math.acos(max(-1.0, min(1.0, abs(normal.z)))))
            if z_avg > 5.0 and 3.0 < slope < 60.0:
                cls = "falda_inclinata"
            elif z_avg > 5.0 and slope <= 3.0:
                cls = "piano_alto/copertura_piana"
            elif z_avg > 2.0 and slope > 70.0:
                cls = "facciata_alta"
            elif z_avg < 1.0 and slope <= 8.0:
                cls = "corte/suolo"
            else:
                cls = "altro"
            rows.append(
                {
                    "object": obj.name,
                    "material": mat,
                    "class": cls,
                    "xMin": min(xs),
                    "xMax": max(xs),
                    "yMin": min(ys),
                    "yMax": max(ys),
                    "zMin": min(zs),
                    "zMax": max(zs),
                    "zAvg": z_avg,
                    "normalX": normal.x,
                    "normalY": normal.y,
                    "normalZ": normal.z,
                    "slopeDeg": slope,
                    "areaXY": area_xy,
                    "points": pts,
                }
            )
    return rows


def point_in_poly(x, y, poly):
    inside = False
    n = len(poly)
    if n < 3:
        return False
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-9) + xi):
            inside = not inside
        j = i
    return inside


def detect_voids(rows):
    roof_polys = [r["points"] for r in rows if r["class"] in ("falda_inclinata", "piano_alto/copertura_piana") and r["areaXY"] > 0.05]
    if not roof_polys:
        return []
    x_min = min(min(p[0] for p in poly) for poly in roof_polys)
    x_max = max(max(p[0] for p in poly) for poly in roof_polys)
    y_min = min(min(p[1] for p in poly) for poly in roof_polys)
    y_max = max(max(p[1] for p in poly) for poly in roof_polys)
    nx, ny = 120, 180
    occupied = [[False for _ in range(ny)] for _ in range(nx)]
    for ix in range(nx):
        x = x_min + (ix + 0.5) / nx * (x_max - x_min)
        for iy in range(ny):
            y = y_min + (iy + 0.5) / ny * (y_max - y_min)
            if any(point_in_poly(x, y, poly) for poly in roof_polys):
                occupied[ix][iy] = True

    seen = set()
    voids = []
    for ix in range(nx):
        for iy in range(ny):
            if occupied[ix][iy] or (ix, iy) in seen:
                continue
            stack = [(ix, iy)]
            seen.add((ix, iy))
            cells = []
            touches_boundary = False
            while stack:
                cx, cy = stack.pop()
                cells.append((cx, cy))
                if cx in (0, nx - 1) or cy in (0, ny - 1):
                    touches_boundary = True
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nbx, nby = cx + dx, cy + dy
                    if nbx < 0 or nbx >= nx or nby < 0 or nby >= ny:
                        continue
                    if occupied[nbx][nby] or (nbx, nby) in seen:
                        continue
                    seen.add((nbx, nby))
                    stack.append((nbx, nby))
            if touches_boundary or len(cells) < 35:
                continue
            min_ix, max_ix = min(c[0] for c in cells), max(c[0] for c in cells)
            min_iy, max_iy = min(c[1] for c in cells), max(c[1] for c in cells)
            voids.append(
                {
                    "cells": len(cells),
                    "xMin": x_min + min_ix / nx * (x_max - x_min),
                    "xMax": x_min + (max_ix + 1) / nx * (x_max - x_min),
                    "yMin": y_min + min_iy / ny * (y_max - y_min),
                    "yMax": y_min + (max_iy + 1) / ny * (y_max - y_min),
                    "areaApprox": len(cells) * ((x_max - x_min) / nx) * ((y_max - y_min) / ny),
                }
            )
    return sorted(voids, key=lambda item: item["areaApprox"], reverse=True)[:12]


def svg_faces(rows, voids, out_svg):
    faces = [
        r for r in rows
        if r["class"] in ("falda_inclinata", "piano_alto/copertura_piana", "corte/suolo")
        and r["areaXY"] > 0.04
    ]
    if not faces:
        return
    x_min = min(min(p[0] for p in r["points"]) for r in faces)
    x_max = max(max(p[0] for p in r["points"]) for r in faces)
    y_min = min(min(p[1] for p in r["points"]) for r in faces)
    y_max = max(max(p[1] for p in r["points"]) for r in faces)
    width, height, pad = 1600, 1050, 45
    scale = min((width - 2 * pad) / (x_max - x_min), (height - 2 * pad) / (y_max - y_min))

    def sx(x):
        return pad + (x - x_min) * scale

    def sy(y):
        return height - pad - (y - y_min) * scale

    colors = {
        "falda_inclinata": "#a85335",
        "piano_alto/copertura_piana": "#d0a05c",
        "corte/suolo": "#698153",
    }
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#f6f2e9"/>',
        '<text x="45" y="30" font-family="Arial" font-size="18" fill="#28231f">Via Berra - facce reali da KMZ/DAE</text>',
    ]
    for r in sorted(faces, key=lambda item: (item["class"], item["zAvg"])):
        pts = " ".join(f"{sx(x):.2f},{sy(y):.2f}" for x, y in r["points"])
        col = colors.get(r["class"], "#888")
        opacity = "0.58" if r["class"] == "falda_inclinata" else "0.30"
        parts.append(f'<polygon points="{pts}" fill="{col}" fill-opacity="{opacity}" stroke="#2b2925" stroke-width="0.25"/>')
    for idx, v in enumerate(voids, start=1):
        x = sx(v["xMin"])
        y = sy(v["yMax"])
        w = (v["xMax"] - v["xMin"]) * scale
        h = (v["yMax"] - v["yMin"]) * scale
        parts.append(f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" fill="none" stroke="#00a6b5" stroke-width="2.0" stroke-dasharray="7 4"/>')
        parts.append(f'<text x="{x + 4:.2f}" y="{y + 15:.2f}" font-family="Arial" font-size="12" fill="#006d75">corte {idx}</text>')
    parts.append("</svg>")
    out_svg.write_text("\n".join(parts), encoding="utf-8")


def main():
    if len(sys.argv) < 3:
        print("Uso: blender --background --python 48_blender_faces_topdown_berra.py -- <model.dae> <out_dir>")
        return
    model = Path(sys.argv[-2])
    out_dir = Path(sys.argv[-1])
    out_dir.mkdir(parents=True, exist_ok=True)
    clear_scene()
    import_dae(model)
    rows = face_rows()
    voids = detect_voids(rows)

    csv_path = out_dir / "ArchiCADmodel_faces.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fieldnames = [
            "object", "material", "class", "xMin", "xMax", "yMin", "yMax", "zMin", "zMax",
            "zAvg", "normalX", "normalY", "normalZ", "slopeDeg", "areaXY"
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow({key: r[key] for key in fieldnames})

    polys_path = out_dir / "ArchiCADmodel_roof_face_polygons.json"
    polys = [
        {
            "class": r["class"],
            "material": r["material"],
            "zAvg": r["zAvg"],
            "slopeDeg": r["slopeDeg"],
            "areaXY": r["areaXY"],
            "points": r["points"],
        }
        for r in rows
        if r["class"] in ("falda_inclinata", "piano_alto/copertura_piana") and r["areaXY"] > 0.04
    ]
    polys_path.write_text(json.dumps(polys, indent=2), encoding="utf-8")

    summary = {
        "source": str(model),
        "faces": len(rows),
        "classes": dict(Counter(r["class"] for r in rows)),
        "roofFaceCount": len(polys),
        "voids": voids,
    }
    (out_dir / "ArchiCADmodel_faces_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (out_dir / "ArchiCADmodel_faces_summary.txt").write_text(
        "\n".join(
            [
                f"Sorgente: {model}",
                f"Facce lette: {len(rows)}",
                "Classi:",
                *(f"- {k}: {v}" for k, v in Counter(r["class"] for r in rows).most_common()),
                f"Facce copertura esportate: {len(polys)}",
                "Corti/vuoti interni stimati da coperture:",
                *(f"- corte {i}: X {v['xMin']:.2f}..{v['xMax']:.2f}, Y {v['yMin']:.2f}..{v['yMax']:.2f}, area ~{v['areaApprox']:.2f} m2" for i, v in enumerate(voids, 1)),
            ]
        ),
        encoding="utf-8",
    )
    svg_faces(rows, voids, out_dir / "ArchiCADmodel_faces_topdown.svg")
    print(f"Creato: {csv_path}")
    print(f"Creato: {polys_path}")
    print(f"Corti rilevate: {len(voids)}")


if __name__ == "__main__":
    main()
