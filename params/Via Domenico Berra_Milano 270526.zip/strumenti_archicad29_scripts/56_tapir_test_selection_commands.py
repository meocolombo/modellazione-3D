from __future__ import annotations

from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("berra_test_selection_commands.txt")
COMMANDS = [
    "SetSelectedElements",
    "SelectElements",
    "SetSelection",
    "AddElementsToSelection",
    "ClearSelection",
    "GetSelectedElements",
    "MoveElements",
    "DeleteElements",
]


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    lines = []
    for namespace in ("TapirCommand", "APICommand", "Archicad"):
        lines.append(f"[{namespace}]")
        for name in COMMANDS:
            try:
                available = conn.commands.IsAddOnCommandAvailable(conn.types.AddOnCommandId(namespace, name))
                lines.append(f"{name}: {'OK' if available else 'NO'}")
            except Exception as exc:
                lines.append(f"{name}: ERRORE {exc}")
        lines.append("")
    OUT_TXT.write_text("\n".join(lines), encoding="utf-8")
    print(OUT_TXT)


if __name__ == "__main__":
    main()
