from __future__ import annotations

from collections import Counter
from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("berra_audit_layers_corrente.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    by_layer = Counter()
    by_type = Counter()
    for detail in details:
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        by_layer[layer] += 1
        by_type[detail.get("type", "")] += 1
    lines = [
        "AUDIT LAYER CORRENTE",
        "=" * 22,
        f"Elementi totali: {len(elements)}",
        "",
        "Per layer:",
        *(f"- {layer}: {count}" for layer, count in sorted(by_layer.items(), key=lambda item: (-item[1], item[0]))),
        "",
        "Per tipo:",
        *(f"- {typ}: {count}" for typ, count in sorted(by_type.items(), key=lambda item: (-item[1], item[0]))),
    ]
    OUT_TXT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Creato: {OUT_TXT}")


if __name__ == "__main__":
    main()
