from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from archicad import ACConnection


STANDBY_LAYER = "BERRA_BIM_V04_STANDBY_PRECEDENTI"
LAYERS = {
    "courts": ("BERRA_BIM_V04_01_CORTI_INTERNE_DAE", 181),
    "edges": ("BERRA_BIM_V04_02_BORDI_CORTI_DAE", 182),
}
OUT_JSON = Path("berra_v04_corti_dae_result.json")
OUT_TXT = Path("berra_v04_corti_dae_controllo.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def normalize(elements):
    out = []
    for el in elements or []:
        if "elementId" in el:
            out.append(el)
        elif "guid" in el:
            out.append({"elementId": {"guid": el["guid"]}})
    return out


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group, hidden=False):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def set_layer(commands, types, elements, layer_idx):
    elements = normalize(elements)
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": el["elementId"], "details": {"layerIndex": int(layer_idx)}} for el in elements
            ]
        },
    )


def get_rows(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    layers = layers_map(commands, types)
    rows = []
    for element, detail in zip(elements, details):
        layer = layers.get(int(detail.get("layerIndex", -999)), "")
        rows.append({"element": element, "layer": layer, "type": detail.get("type", ""), "id": detail.get("id", "")})
    return rows


def move_previous_v04(commands, types, standby_idx):
    rows = get_rows(commands, types)
    to_move = [row["element"] for row in rows if row["layer"].startswith("BERRA_BIM_V04_") and row["layer"] != STANDBY_LAYER]
    if not to_move:
        return {"moved": 0}
    set_layer(commands, types, to_move, standby_idx)
    return {"moved": len(to_move)}


def beam(x1, y1, x2, y2, z=0.11, width=0.06, height=0.04):
    return {
        "begCoordinate": coord(x1, y1),
        "endCoordinate": coord(x2, y2),
        "zCoordinate": float(z),
        "width": float(width),
        "height": float(height),
    }


def court_polygon(void):
    # La lettura DAE individua i vuoti principali; uso un piccolo arretramento
    # per non sovrapporre i bordi alle murature/linee di copertura.
    margin = 0.12
    x1 = float(void["xMin"]) + margin
    x2 = float(void["xMax"]) - margin
    y1 = float(void["yMin"]) + margin
    y2 = float(void["yMax"]) - margin
    return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]


def polygon_area(pts):
    area = 0.0
    closed = pts + [pts[0]]
    for a, b in zip(closed, closed[1:]):
        area += a[0] * b[1] - b[0] * a[1]
    return abs(area) / 2.0


def load_voids(path):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return payload.get("voids", [])


def main():
    if len(sys.argv) < 3 or sys.argv[1] != "APPLICA":
        print("Crea solo corti interne V04 da analisi DAE. Non crea travi di copertura.")
        print("Uso: py 50_tapir_v04_corti_da_dae_berra.py APPLICA <faces_summary.json>")
        return
    json_path = Path(sys.argv[2])
    voids = load_voids(json_path)
    if not voids:
        raise SystemExit(f"Nessuna corte rilevata in {json_path}")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    standby = create_or_get_layer(commands, types, STANDBY_LAYER, 180, hidden=True)
    layer_ids = {key: create_or_get_layer(commands, types, *value) for key, value in LAYERS.items()}
    moved = move_previous_v04(commands, types, standby)

    slabs = []
    slab_codes = []
    edge_beams = []
    for index, void in enumerate(voids, start=1):
        pts = court_polygon(void)
        if polygon_area(pts) < 3.0:
            continue
        slabs.append(
            {
                "level": 0.015,
                "thickness": 0.045,
                "polygonCoordinates": [coord(x, y) for x, y in pts],
            }
        )
        slab_codes.append(f"BER-V04-CORTE-{index:02d}")
        closed = pts + [pts[0]]
        for a, b in zip(closed, closed[1:]):
            edge_beams.append(beam(a[0], a[1], b[0], b[1]))

    slab_result = tapir(commands, types, "CreateSlabs", {"slabsData": slabs}) if slabs else {"elements": []}
    slab_elements = normalize(slab_result.get("elements", []))
    set_layer(commands, types, slab_elements, layer_ids["courts"])

    beam_result = tapir(commands, types, "CreateBeams", {"beamsData": edge_beams}) if edge_beams else {"elements": []}
    beam_elements = normalize(beam_result.get("elements", []))
    set_layer(commands, types, beam_elements, layer_ids["edges"])

    summary = {
        "source": str(json_path),
        "voidsRead": len(voids),
        "previousV04Moved": moved["moved"],
        "createdSlabs": len(slab_elements),
        "createdEdgeBeams": len(beam_elements),
        "courts": [
            {
                "code": code,
                "area": polygon_area(slab["polygonCoordinates"]) if False else polygon_area([(p["x"], p["y"]) for p in slab["polygonCoordinates"]]),
                "points": slab["polygonCoordinates"],
            }
            for code, slab in zip(slab_codes, slabs)
        ],
        "note": "Passata prudente: nessuna trave di copertura generata. Le corti derivano dai vuoti reali letti dal KMZ/DAE.",
    }
    OUT_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    OUT_TXT.write_text(
        "\n".join(
            [
                "BERRA V04 - CORTI DA DAE",
                "=" * 28,
                f"Sorgente: {json_path}",
                f"Elementi V04 precedenti spostati in standby: {moved['moved']}",
                f"Solai/corti creati: {len(slab_elements)}",
                f"Bordi corti creati: {len(beam_elements)}",
                "Nessuna trave di copertura creata.",
                "",
                "Corti create:",
                *(f"- {court['code']}: area ~{court['area']:.2f} m2" for court in summary["courts"]),
            ]
        ),
        encoding="utf-8",
    )
    print(f"Solai/corti creati: {len(slab_elements)}")
    print(f"Bordi creati: {len(beam_elements)}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
