from __future__ import annotations

from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("berra_archicad_native_commands.txt")


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    names = sorted(name for name in dir(commands) if not name.startswith("_"))
    filtered = [
        name for name in names
        if any(token in name.casefold() for token in ("delete", "remove", "element", "selection", "lock", "layer"))
    ]
    OUT_TXT.write_text("\n".join(filtered), encoding="utf-8")
    print(OUT_TXT)


if __name__ == "__main__":
    main()
