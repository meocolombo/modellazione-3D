from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_bim_master_result.json")
OUT_COMPUTO = Path("berra_bim_computo_preliminare.csv")
OUT_GEO = Path("berra_bim_georeferenziazione.txt")

STANDBY_LAYER = "BERRA_STANDBY_PRE_BIM_MASTER_01"

LAYERS = {
    "geo": ("BERRA_BIM_00_GEOREFERENZIAZIONE", 130),
    "walls": ("BERRA_BIM_01_MURATURE", 131),
    "slabs": ("BERRA_BIM_02_SOLAI", 132),
    "roofs": ("BERRA_BIM_03_COPERTURE", 133),
    "structure": ("BERRA_BIM_04_STRUTTURE_COPERTURA", 134),
    "openings": ("BERRA_BIM_05_APERTURE_FINITURE", 135),
    "facades": ("BERRA_BIM_06_PORTALI_DECORI", 136),
    "green": ("BERRA_BIM_07_VERDE_ESTERNI", 137),
    "context": ("BERRA_BIM_08_CONTESTO", 138),
}

SITE_WGS84 = {
    "address": "Via Domenico Berra 10/12/14, Milano",
    "latitude": 45.50849058,
    "longitude": 9.24840835,
    "google_earth_heading_deg": -148.75824114,
    "model_local_rotation_deg": -3.20,
    "note": "Il modello Archicad e considerato in sistema locale; la georeferenziazione reale va usata come riferimento, non come trasformazione rigida del rilievo.",
}


ROOF_BLOCKS = [
    ("ROF-A", "manica ovest lunga", 6.30, 0.18, 29.0, [(-50.40, -72.05), (-41.05, -72.05), (-41.05, 33.05), (-50.40, 33.05)]),
    ("ROF-B", "fronte via Berra", 6.30, 0.18, 30.0, [(-50.35, -72.05), (-10.65, -72.05), (-10.65, -61.35), (-50.35, -61.35)]),
    ("ROF-C", "manica est", 6.30, 0.18, 29.0, [(-11.05, -72.00), (-8.00, -72.00), (-8.00, 14.20), (-11.05, 14.20)]),
    ("ROF-D", "corpo interno sud", 5.30, 0.16, 27.0, [(-40.90, -63.35), (-17.25, -63.35), (-17.25, -21.05), (-40.90, -21.05)]),
    ("ROF-E", "loggiato nord", 6.30, 0.18, 30.0, [(-34.45, 13.20), (-8.05, 13.20), (-8.05, 33.05), (-34.45, 33.05)]),
    ("ROF-F", "ala ovest corte", 5.30, 0.16, 27.0, [(-48.40, -33.20), (-41.20, -33.20), (-41.20, -20.75), (-48.40, -20.75)]),
    ("ROF-G", "corpo trasversale corte", 6.30, 0.18, 29.0, [(-39.85, -21.15), (-16.95, -21.15), (-16.95, -17.05), (-39.85, -17.05)]),
    ("ROF-H", "appendice nord ingresso", 6.30, 0.18, 29.0, [(-33.50, 33.00), (-22.10, 33.00), (-22.10, 41.80), (-33.50, 41.80)]),
]

SLAB_BLOCKS = [
    ("SLB-P0-A", "solaio piano terra corpo ovest", 0.00, 0.28, [(-50.40, -72.05), (-41.05, -72.05), (-41.05, 33.05), (-50.40, 33.05)]),
    ("SLB-P0-B", "solaio piano terra fronte", 0.00, 0.28, [(-50.35, -72.05), (-8.00, -72.05), (-8.00, -61.35), (-50.35, -61.35)]),
    ("SLB-P0-C", "solaio piano terra corpo est", 0.00, 0.28, [(-11.05, -72.00), (-8.00, -72.00), (-8.00, 14.20), (-11.05, 14.20)]),
    ("SLB-P0-D", "solaio piano terra corpo interno", 0.00, 0.28, [(-40.90, -63.35), (-17.25, -63.35), (-17.25, -21.05), (-40.90, -21.05)]),
    ("SLB-P1-A", "solaio primo piano corte storica", 3.30, 0.24, [(-50.30, -72.00), (-8.00, -72.00), (-8.00, 14.20), (-34.45, 33.05), (-50.30, 33.05)]),
    ("SLB-P2-A", "solaio sottotetto porzione alta", 6.30, 0.22, [(-50.20, -72.00), (-8.00, -72.00), (-8.00, 14.20), (-34.45, 33.05), (-50.20, 33.05)]),
]

GREEN_POLYGONS = [
    ("GRN-001", "corte nord/loggiato", [(-32.80, 14.40), (-22.30, 14.40), (-21.55, 20.00), (-22.40, 29.85), (-28.10, 30.85), (-32.80, 26.65)]),
    ("GRN-002", "giardino interno ovest", [(-38.85, -59.70), (-33.45, -58.90), (-33.10, -44.20), (-35.30, -36.30), (-35.80, -24.05), (-38.85, -24.05)]),
    ("GRN-003", "giardino interno est", [(-27.35, -59.40), (-22.00, -58.85), (-21.35, -48.10), (-24.30, -38.80), (-24.10, -24.20), (-27.80, -24.20)]),
    ("GRN-004", "aiuola ingresso", [(-37.40, -69.70), (-31.20, -69.50), (-30.80, -65.20), (-36.60, -64.95)]),
]


WINDOW_ROWS = [
    # x, y, z, larghezza, altezza, piano/facciata
    (-48.90, -66.0, 1.10, 0.95, 1.45, "fronte via Berra"),
    (-48.90, -58.5, 1.10, 0.95, 1.45, "fronte via Berra"),
    (-48.90, -50.0, 1.10, 0.95, 1.45, "manica ovest"),
    (-48.90, -42.5, 1.10, 0.95, 1.45, "manica ovest"),
    (-48.90, -30.5, 1.10, 0.95, 1.45, "manica ovest"),
    (-48.90, -18.5, 1.10, 0.95, 1.45, "manica ovest"),
    (-48.90, -6.5, 1.10, 0.95, 1.45, "manica ovest"),
    (-48.90, 6.0, 1.10, 0.95, 1.45, "manica ovest"),
    (-48.90, 19.0, 1.10, 0.95, 1.45, "manica ovest"),
    (-9.20, -66.0, 1.10, 0.95, 1.45, "manica est"),
    (-9.20, -54.0, 1.10, 0.95, 1.45, "manica est"),
    (-9.20, -42.0, 1.10, 0.95, 1.45, "manica est"),
    (-9.20, -30.0, 1.10, 0.95, 1.45, "manica est"),
    (-9.20, -18.0, 1.10, 0.95, 1.45, "manica est"),
    (-9.20, -6.0, 1.10, 0.95, 1.45, "manica est"),
    (-9.20, 6.0, 1.10, 0.95, 1.45, "manica est"),
]

DOOR_MARKERS = [
    (-34.0, -72.00, 0.05, 2.25, 2.85, "portale ingresso"),
    (-31.95, 13.35, 0.05, 1.60, 2.45, "portico corte"),
    (-31.95, 19.95, 0.05, 1.60, 2.45, "portico corte"),
    (-31.95, 26.55, 0.05, 1.60, 2.45, "portico corte"),
]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def polygon_area(points):
    total = 0.0
    pts = points + [points[0]]
    for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
        total += x1 * y2 - x2 * y1
    return abs(total) * 0.5


def line_length(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, layer_name, group_nr, hidden=False):
    existing = find_layer_index(commands, types, layer_name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": layer_name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group_nr),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, layer_name)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {layer_name}")
    return created


def get_layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def get_all_data(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    return elements, details, boxes


def bbox(box_item):
    return box_item.get("boundingBox3D", {})


def move_existing_ai_to_standby(commands, types, standby_index):
    layers = get_layers_map(commands, types)
    elements, details, _boxes = get_all_data(commands, types)
    to_move = []
    for element, detail in zip(elements, details):
        layer_name = layers.get(int(detail.get("layerIndex", -999)), "")
        if layer_name.startswith("BERRA_AI_") or layer_name.startswith("BERRA_BIM_"):
            to_move.append(element)
    if not to_move:
        return {"movedCount": 0}
    result = tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": standby_index}}
                for element in to_move
            ]
        },
    )
    return {"movedCount": len(to_move), "result": result}


def set_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": layer_index}}
                for element in elements
            ]
        },
    )


def set_ids(commands, types, elements, ids):
    if not elements:
        return None
    try:
        return tapir(
            commands,
            types,
            "SetDetailsOfElements",
            {
                "elementsWithDetails": [
                    {"elementId": element["elementId"], "details": {"id": element_id}}
                    for element, element_id in zip(elements, ids)
                ]
            },
        )
    except Exception as exc:
        return {"error": str(exc), "note": "ID non impostati via Tapir; codici disponibili nel CSV computo."}


def create_elements(commands, types, layer_index, command_name, payload_key, data, ids=None):
    result = tapir(commands, types, command_name, {payload_key: data})
    elements = result.get("elements", [])
    layer_result = set_layer(commands, types, elements, layer_index)
    id_result = set_ids(commands, types, elements, ids or []) if ids else None
    return elements, {"requested": len(data), "created": len(elements), "result": result, "layerResult": layer_result, "idResult": id_result}


def collect_existing_walls(commands, types):
    layers = get_layers_map(commands, types)
    elements, details, boxes = get_all_data(commands, types)
    walls_data = []
    source = []
    for detail, box_item in zip(details, boxes):
        layer_name = layers.get(int(detail.get("layerIndex", -999)), "")
        if layer_name.startswith("BERRA_"):
            continue
        if detail.get("type") != "Wall":
            continue
        d = detail.get("details", {})
        beg = d.get("begCoordinate", {})
        end = d.get("endCoordinate", {})
        box = bbox(box_item)
        if "x" not in beg or "x" not in end:
            continue
        z = float(box.get("zMin", 0.0))
        height = float(d.get("height", box.get("zMax", 3.0) - z or 3.0))
        thickness = float(d.get("thickness", 0.40) or 0.40)
        walls_data.append(
            {
                "begCoordinate": coord(beg["x"], beg["y"]),
                "endCoordinate": coord(end["x"], end["y"]),
                "zCoordinate": z,
                "height": height,
                "thickness": thickness,
            }
        )
        source.append(
            {
                "sourceId": detail.get("id", ""),
                "length": line_length(float(beg["x"]), float(beg["y"]), float(end["x"]), float(end["y"])),
                "z": z,
                "height": height,
                "thickness": thickness,
            }
        )
    return walls_data, source


def build_slabs():
    data = []
    ids = []
    computo = []
    for code, name, level, thickness, pts in SLAB_BLOCKS:
        data.append({"level": level, "thickness": thickness, "polygonCoordinates": [coord(x, y) for x, y in pts]})
        ids.append(f"BER-{code}")
        area = polygon_area(pts)
        computo.append((f"BER-{code}", "Solaio", name, area, "m2", thickness, area * thickness, "m3"))
    return data, ids, computo


def build_roofs():
    data = []
    ids = []
    computo = []
    for code, name, level, thickness, angle, pts in ROOF_BLOCKS:
        data.append(
            {
                "level": level,
                "thickness": thickness,
                "polygonCoordinates": [coord(x, y) for x, y in pts],
                "eavesOverhang": 0.22,
                "levels": [{"levelHeight": 0.0, "levelAngle": math.radians(angle)}],
            }
        )
        ids.append(f"BER-{code}")
        area = polygon_area(pts) / max(0.2, math.cos(math.radians(angle)))
        computo.append((f"BER-{code}", "Copertura", name, area, "m2", thickness, area * thickness, "m3"))
    return data, ids, computo


def add_beam(beams, ids, computo, code, name, x1, y1, x2, y2, z, width, height, category="Trave"):
    beams.append({"begCoordinate": coord(x1, y1), "endCoordinate": coord(x2, y2), "zCoordinate": z, "width": width, "height": height})
    ids.append(f"BER-{code}")
    length = line_length(x1, y1, x2, y2)
    computo.append((f"BER-{code}", category, name, length, "m", width * height, length * width * height, "m3"))


def build_roof_structure():
    beams = []
    ids = []
    computo = []
    idx = 1
    for _code, name, level, _thick, angle, pts in ROOF_BLOCKS:
        x1 = min(p[0] for p in pts)
        x2 = max(p[0] for p in pts)
        y1 = min(p[1] for p in pts)
        y2 = max(p[1] for p in pts)
        width_x = x2 - x1
        width_y = y2 - y1
        ridge_z = level + 0.25 + min(width_x, width_y) * 0.45 * math.tan(math.radians(angle))
        eave_z = level + 0.12
        if width_y >= width_x:
            xm = (x1 + x2) / 2.0
            add_beam(beams, ids, computo, f"STR-COL-{idx:03d}", f"colmo {name}", xm, y1, xm, y2, ridge_z, 0.12, 0.10)
            idx += 1
            step = 7.5
            y = y1 + step
            while y < y2:
                add_beam(beams, ids, computo, f"STR-CAP-{idx:03d}", f"capriata {name}", x1 + 0.25, y, x2 - 0.25, y, level + 0.80, 0.16, 0.12, "Capriata")
                idx += 1
                y += step
        else:
            ym = (y1 + y2) / 2.0
            add_beam(beams, ids, computo, f"STR-COL-{idx:03d}", f"colmo {name}", x1, ym, x2, ym, ridge_z, 0.12, 0.10)
            idx += 1
            step = 7.5
            x = x1 + step
            while x < x2:
                add_beam(beams, ids, computo, f"STR-CAP-{idx:03d}", f"capriata {name}", x, y1 + 0.25, x, y2 - 0.25, level + 0.80, 0.16, 0.12, "Capriata")
                idx += 1
                x += step
        add_beam(beams, ids, computo, f"STR-GRN-{idx:03d}", f"gronda {name}", x1, y1, x2, y1, eave_z, 0.09, 0.06, "Gronda")
        idx += 1
        add_beam(beams, ids, computo, f"STR-GRN-{idx:03d}", f"gronda {name}", x1, y2, x2, y2, eave_z, 0.09, 0.06, "Gronda")
        idx += 1
        add_beam(beams, ids, computo, f"STR-GRN-{idx:03d}", f"gronda {name}", x1, y1, x1, y2, eave_z, 0.09, 0.06, "Gronda")
        idx += 1
        add_beam(beams, ids, computo, f"STR-GRN-{idx:03d}", f"gronda {name}", x2, y1, x2, y2, eave_z, 0.09, 0.06, "Gronda")
        idx += 1
    return beams, ids, computo


def build_columns():
    data = []
    ids = []
    computo = []
    y_values = [14.2, 17.0, 19.8, 22.6, 25.4, 28.2, 30.8]
    for i, y in enumerate(y_values, start=1):
        data.append({"coordinates": point3(-33.00, y, 0.0), "height": 3.10, "width": 0.30, "depth": 0.30})
        ids.append(f"BER-COL-PORT-{i:03d}")
        computo.append((ids[-1], "Colonna", "colonne loggiato corte", 3.10, "m", 0.09, 0.279, "m3"))
    return data, ids, computo


def build_morph_boxes():
    morphs = []
    ids = []
    computo = []

    def add(code, category, name, x, y, z, sx, sy, sz):
        morphs.append({"basePoint": point3(x, y, z), "size": dim3(sx, sy, sz)})
        ids.append(f"BER-{code}")
        computo.append((ids[-1], category, name, sx * sy, "m2", sz, sx * sy * sz, "m3"))

    # Finestre e portali come marcatori computabili/visivi allineati alle facciate.
    for i, (x, y, z, w, h, facade) in enumerate(WINDOW_ROWS, start=1):
        add(f"WIN-MRK-{i:03d}", "Finestra", facade, x - 0.05, y - w / 2, z, 0.10, w, h)
        add(f"WIN-FRM-{i:03d}", "Cornice finestra", facade, x - 0.08, y - w / 2 - 0.10, z - 0.10, 0.08, w + 0.20, 0.12)
        add(f"WIN-HDR-{i:03d}", "Architrave finestra", facade, x - 0.08, y - w / 2 - 0.10, z + h, 0.08, w + 0.20, 0.12)
    for i, (x, y, z, w, h, name) in enumerate(DOOR_MARKERS, start=1):
        add(f"DOR-MRK-{i:03d}", "Porta/Portale", name, x - w / 2, y - 0.06, z, w, 0.12, h)
        add(f"DOR-ARCH-{i:03d}", "Cornice portale", name, x - w / 2 - 0.18, y - 0.08, z + h, w + 0.36, 0.16, 0.18)

    # Comignoli e piccoli lucernari.
    for i, (x, y, z) in enumerate([(-47.1, -58.0, 6.8), (-43.6, -35.5, 6.8), (-45.7, -8.0, 6.8), (-30.6, 25.0, 6.8), (-16.4, 10.5, 6.8), (-24.5, -62.8, 6.8)], start=1):
        add(f"FIN-CMN-{i:03d}", "Comignolo", "comignolo copertura", x - 0.18, y - 0.18, z, 0.36, 0.36, 0.95)
        add(f"FIN-COP-{i:03d}", "Comignolo", "cappello comignolo", x - 0.24, y - 0.24, z + 0.92, 0.48, 0.48, 0.12)
    return morphs, ids, computo


def build_green_and_context():
    slabs = []
    slab_ids = []
    beams = []
    beam_ids = []
    morphs = []
    morph_ids = []
    computo = []

    for code, name, pts in GREEN_POLYGONS:
        slabs.append({"level": 0.025, "thickness": 0.045, "polygonCoordinates": [coord(x, y) for x, y in pts]})
        slab_ids.append(f"BER-{code}")
        area = polygon_area(pts)
        computo.append((f"BER-{code}", "Verde", name, area, "m2", 0.045, area * 0.045, "m3"))
        pts2 = pts + [pts[0]]
        for i, ((x1, y1), (x2, y2)) in enumerate(zip(pts2, pts2[1:]), start=1):
            add_beam(beams, beam_ids, computo, f"{code}-BD-{i:02d}", f"bordo {name}", x1, y1, x2, y2, 0.08, 0.055, 0.04, "Bordo aiuola")

    def add_tree(code, x, y, scale):
        morphs.append({"basePoint": point3(x - 0.12, y - 0.12, 0.00), "size": dim3(0.24, 0.24, 1.45 * scale)})
        morph_ids.append(f"BER-{code}-TRK")
        computo.append((morph_ids[-1], "Verde", "tronco", 1.45 * scale, "m", 0.06, 0.06 * 1.45 * scale, "m3"))
        morphs.append({"basePoint": point3(x - 0.85 * scale, y - 0.85 * scale, 1.05 * scale), "size": dim3(1.70 * scale, 1.70 * scale, 1.20 * scale)})
        morph_ids.append(f"BER-{code}-CHI")
        computo.append((morph_ids[-1], "Verde", "chioma indicativa", 1.0, "cad", 0.0, 0.0, "cad"))

    for i, (x, y, scale) in enumerate([(-30.2, 17.5, 1.4), (-27.4, 22.4, 1.7), (-29.2, 27.0, 1.5), (-35.6, -42.0, 1.5), (-24.2, -45.0, 1.4), (-38.6, -69.0, 1.6), (-20.4, -69.2, 1.5)], start=1):
        add_tree(f"GRN-ARB-{i:03d}", x, y, scale)

    context_slabs = [
        ("CTX-STR-001", "via Berra fronte", -0.06, 0.055, [(-52.0, -76.7), (-5.8, -76.7), (-5.8, -72.4), (-52.0, -72.4)]),
        ("CTX-STR-002", "via Berra laterale", -0.06, 0.055, [(-54.7, -71.9), (-50.6, -71.9), (-50.6, 32.0), (-54.7, 32.0)]),
    ]
    for code, name, level, thickness, pts in context_slabs:
        slabs.append({"level": level, "thickness": thickness, "polygonCoordinates": [coord(x, y) for x, y in pts]})
        slab_ids.append(f"BER-{code}")
        area = polygon_area(pts)
        computo.append((f"BER-{code}", "Contesto", name, area, "m2", thickness, area * thickness, "m3"))

    return slabs, slab_ids, beams, beam_ids, morphs, morph_ids, computo


def build_geo_markers():
    beams = []
    ids = []
    computo = []
    # Freccia nord e asse locale: elementi simbolici non computati.
    add_beam(beams, ids, computo, "GEO-NORD-001", "freccia nord locale", -4.0, 38.0, -4.0, 46.0, 0.20, 0.10, 0.06, "Georef")
    add_beam(beams, ids, computo, "GEO-ASSE-001", "asse modello locale", -8.0, 38.0, 2.0, 38.0, 0.20, 0.06, 0.04, "Georef")
    return beams, ids


def write_computo(rows):
    with OUT_COMPUTO.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(["codice_id", "categoria", "descrizione", "quantita_primaria", "unita_primaria", "parametro_secondario", "quantita_volume_o_cad", "unita_secondaria"])
        for row in rows:
            writer.writerow(row)


def write_geo():
    lines = [
        "GEOREFERENZIAZIONE BIM VIA BERRA",
        "=" * 36,
        f"Indirizzo: {SITE_WGS84['address']}",
        f"Latitudine WGS84 riferimento Google Earth: {SITE_WGS84['latitude']}",
        f"Longitudine WGS84 riferimento Google Earth: {SITE_WGS84['longitude']}",
        f"Heading vista Google Earth: {SITE_WGS84['google_earth_heading_deg']} deg",
        f"Rotazione locale stimata del modello Archicad: {SITE_WGS84['model_local_rotation_deg']} deg",
        "",
        "Nota operativa:",
        SITE_WGS84["note"],
        "",
        "Il modello BIM master creato in questa passata usa il sistema locale del file PLN.",
        "Per georeferenziare formalmente il progetto in Archicad occorre impostare coordinate e Nord progetto negli attributi/progetto, operazione non esposta in modo affidabile dal ponte Tapir usato qui.",
    ]
    OUT_GEO.write_text("\n".join(lines), encoding="utf-8")


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Crea modello BIM master preliminare per Via Berra.")
        print("Uso: py 40_tapir_bim_master_berra.py APPLICA")
        print("Per ricreare dopo una passata precedente: aggiungere FORZA.")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types

    standby_index = create_or_get_layer(commands, types, STANDBY_LAYER, 129, hidden=True)
    layer_indices = {key: create_or_get_layer(commands, types, name, group) for key, (name, group) in LAYERS.items()}

    standby_result = move_existing_ai_to_standby(commands, types, standby_index)

    computo = []
    results = {"standby": standby_result, "created": {}}

    walls_data, wall_source = collect_existing_walls(commands, types)
    wall_ids = [f"BER-WAL-{i:03d}" for i in range(1, len(walls_data) + 1)]
    wall_elements, wall_result = create_elements(commands, types, layer_indices["walls"], "CreateWalls", "wallsData", walls_data, wall_ids)
    results["created"]["walls"] = wall_result
    for element_id, src in zip(wall_ids, wall_source):
        volume = src["length"] * src["height"] * src["thickness"]
        computo.append((element_id, "Muratura", src["sourceId"], src["length"], "m", src["thickness"], volume, "m3"))

    slabs_data, slab_ids, slab_computo = build_slabs()
    slab_elements, slab_result = create_elements(commands, types, layer_indices["slabs"], "CreateSlabs", "slabsData", slabs_data, slab_ids)
    results["created"]["slabs"] = slab_result
    computo.extend(slab_computo)

    roofs_data, roof_ids, roof_computo = build_roofs()
    roof_elements, roof_result = create_elements(commands, types, layer_indices["roofs"], "CreateRoofs", "roofsData", roofs_data, roof_ids)
    results["created"]["roofs"] = roof_result
    computo.extend(roof_computo)

    beams_data, beam_ids, beam_computo = build_roof_structure()
    beam_elements, beam_result = create_elements(commands, types, layer_indices["structure"], "CreateBeams", "beamsData", beams_data, beam_ids)
    results["created"]["roofStructure"] = beam_result
    computo.extend(beam_computo)

    columns_data, column_ids, column_computo = build_columns()
    column_elements, column_result = create_elements(commands, types, layer_indices["structure"], "CreateColumns", "columnsData", columns_data, column_ids)
    results["created"]["columns"] = column_result
    computo.extend(column_computo)

    morphs_data, morph_ids, morph_computo = build_morph_boxes()
    morph_elements, morph_result = create_elements(commands, types, layer_indices["openings"], "CreateMorphs", "morphsData", morphs_data, morph_ids)
    results["created"]["openingsFinishes"] = morph_result
    computo.extend(morph_computo)

    green_slabs, green_slab_ids, green_beams, green_beam_ids, green_morphs, green_morph_ids, green_computo = build_green_and_context()
    green_slab_elements, green_slab_result = create_elements(commands, types, layer_indices["green"], "CreateSlabs", "slabsData", green_slabs, green_slab_ids)
    green_beam_elements, green_beam_result = create_elements(commands, types, layer_indices["green"], "CreateBeams", "beamsData", green_beams, green_beam_ids)
    green_morph_elements, green_morph_result = create_elements(commands, types, layer_indices["green"], "CreateMorphs", "morphsData", green_morphs, green_morph_ids)
    results["created"]["greenSlabs"] = green_slab_result
    results["created"]["greenBeams"] = green_beam_result
    results["created"]["greenMorphs"] = green_morph_result
    computo.extend(green_computo)

    geo_beams, geo_ids = build_geo_markers()
    geo_elements, geo_result = create_elements(commands, types, layer_indices["geo"], "CreateBeams", "beamsData", geo_beams, geo_ids)
    results["created"]["geo"] = geo_result

    # Attribuisce codici agli elementi originali di apertura ancora presenti, se ci sono.
    layers = get_layers_map(commands, types)
    elements, details, _boxes = get_all_data(commands, types)
    existing_openings = []
    existing_opening_ids = []
    w_count = d_count = 0
    for element, detail in zip(elements, details):
        layer_name = layers.get(int(detail.get("layerIndex", -999)), "")
        if layer_name.startswith("BERRA_"):
            continue
        if detail.get("type") == "Window":
            w_count += 1
            existing_openings.append(element)
            existing_opening_ids.append(f"BER-WIN-EX-{w_count:03d}")
        elif detail.get("type") == "Door":
            d_count += 1
            existing_openings.append(element)
            existing_opening_ids.append(f"BER-DOR-EX-{d_count:03d}")
    results["existingOpeningsIdResult"] = set_ids(commands, types, existing_openings, existing_opening_ids)
    for element_id in existing_opening_ids:
        computo.append((element_id, "Apertura esistente", "finestra/porta Archicad esistente", 1, "cad", 0, 1, "cad"))

    write_computo(computo)
    write_geo()

    results["outputs"] = {"computo": str(OUT_COMPUTO), "georeferenziazione": str(OUT_GEO)}
    OUT_JSON.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print("BIM master Berra creato.")
    print(f"Elementi spostati in stand-by: {standby_result.get('movedCount', 0)}")
    print(f"Murature create: {wall_result['created']}")
    print(f"Solai creati: {slab_result['created']}")
    print(f"Coperture create: {roof_result['created']}")
    print(f"Strutture copertura create: {beam_result['created'] + column_result['created']}")
    print(f"Aperture/finiture create: {morph_result['created']}")
    print(f"Verde/contesto creato: {green_slab_result['created'] + green_beam_result['created'] + green_morph_result['created']}")
    print(f"Computo: {OUT_COMPUTO}")
    print(f"Georef: {OUT_GEO}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
