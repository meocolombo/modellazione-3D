from __future__ import annotations

import json
from pathlib import Path

from archicad import ACConnection


LAYER_NAME = "BERRA_V06_VERDE_ARREDI"
OUT_JSON = Path("berra_v06_oggetti_details.json")
OUT_TXT = Path("berra_v06_oggetti_details.txt")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types

    layers = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"}).get("attributes", [])
    layer_index = None
    for layer in layers:
        if str(layer.get("name", "")).casefold() == LAYER_NAME.casefold():
            layer_index = int(layer.get("index"))
            break
    if layer_index is None:
        raise SystemExit(f"Layer non trovato: {LAYER_NAME}")

    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        if int(detail.get("layerIndex", -1)) != layer_index:
            continue
        box = box_item.get("boundingBox3D", {})
        rows.append(
            {
                "element": element,
                "detail": detail,
                "box": box,
            }
        )

    OUT_JSON.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    lines = [
        "BERRA V06 - DETTAGLI OGGETTI",
        "=" * 30,
        f"Layer index: {layer_index}",
        f"Elementi letti: {len(rows)}",
        "",
    ]
    for row in rows:
        detail = row["detail"]
        box = row["box"]
        lines.append(
            f"- {detail.get('id')} | {detail.get('type')} | "
            f"X {float(box.get('xMin', 0)):.2f}..{float(box.get('xMax', 0)):.2f} | "
            f"Y {float(box.get('yMin', 0)):.2f}..{float(box.get('yMax', 0)):.2f} | "
            f"Z {float(box.get('zMin', 0)):.2f}..{float(box.get('zMax', 0)):.2f}"
        )
        lines.append(f"  details keys: {', '.join(sorted((detail.get('details') or {}).keys()))}")
        lines.append(f"  details: {json.dumps(detail.get('details') or {}, ensure_ascii=False)[:800]}")
    OUT_TXT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Elementi letti: {len(rows)}")
    print(f"Creati: {OUT_TXT}, {OUT_JSON}")


if __name__ == "__main__":
    main()
