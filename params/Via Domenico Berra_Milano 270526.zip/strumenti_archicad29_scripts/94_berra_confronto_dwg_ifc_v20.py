from __future__ import annotations

import csv
import json
import math
from collections import Counter
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(r"C:\Users\Studio 01 MCA\Desktop\sito 270526")
DWG_OUT = ROOT / "output_berra_dwg_struttura_110626"
IFC_OUT = ROOT / "output_berra_v17_ufficiale_pipeline"
V20_OUT = ROOT / "output_berra_v20_falde_pln"
OUT = DWG_OUT

DWG_SEGMENTS = DWG_OUT / "dwg_struttura_110626_flat_segments.csv"
IFC_ROOF_FACES = IFC_OUT / "berra_v17_ufficiale_ifc_roof_faces.csv"
V20_AXES = V20_OUT / "berra_v20_assi_falde_pln_allineati.csv"


def bbox_points(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return min(xs), min(ys), max(xs), max(ys)


def centroid_bbox(b):
    return (b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0


def bbox_size(b):
    return b[2] - b[0], b[3] - b[1]


def union_bbox(boxes):
    return (
        min(b[0] for b in boxes),
        min(b[1] for b in boxes),
        max(b[2] for b in boxes),
        max(b[3] for b in boxes),
    )


def angle_bin(angle: float, bin_size: float = 5.0) -> int:
    a = angle % 180.0
    return int(round(a / bin_size) * bin_size) % 180


def dominant_angles(segments, min_len=0.5, top=6):
    counts = Counter()
    for s in segments:
        length = s["length"]
        if length < min_len:
            continue
        dx = s["x2"] - s["x1"]
        dy = s["y2"] - s["y1"]
        a = math.degrees(math.atan2(dy, dx)) % 180.0
        counts[angle_bin(a)] += length
    return counts.most_common(top)


def read_dwg_segments():
    rows = []
    with DWG_SEGMENTS.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            row = {
                "layer": r["layer"],
                "type": r["type"],
                "x1": float(r["x1"]),
                "y1": float(r["y1"]),
                "x2": float(r["x2"]),
                "y2": float(r["y2"]),
                "length": float(r["length"]),
                "angle_deg": float(r["angle_deg"]),
            }
            rows.append(row)
    return rows


def read_ifc_edges():
    edges = []
    points = []
    with IFC_ROOF_FACES.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=";")
        for r in reader:
            pts3 = json.loads(r["points"])
            pts = [(float(p[0]), float(p[1])) for p in pts3]
            points.extend(pts)
            for a, b in zip(pts, pts[1:] + pts[:1]):
                length = math.hypot(b[0] - a[0], b[1] - a[1])
                if length > 1e-8:
                    edges.append(
                        {
                            "layer": "IFC_ROOF",
                            "type": "ROOF_EDGE",
                            "x1": a[0],
                            "y1": a[1],
                            "x2": b[0],
                            "y2": b[1],
                            "length": length,
                            "roof_id": r.get("roof_id", ""),
                        }
                    )
    return edges, points


def read_v20_axes():
    axes = []
    if not V20_AXES.exists():
        return axes
    with V20_AXES.open(newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f, delimiter=";"):
            x0 = float(r["x0"])
            y0 = float(r["y0"])
            x1 = float(r["x1"])
            y1 = float(r["y1"])
            axes.append(
                {
                    "layer": "V20_AXIS",
                    "type": "AXIS",
                    "x1": x0,
                    "y1": y0,
                    "x2": x1,
                    "y2": y1,
                    "length": math.hypot(x1 - x0, y1 - y0),
                    "code": r.get("code", ""),
                }
            )
    return axes


def render_overlay(dwg_struct, dwg_context, ifc_edges, v20_axes, bbox, path):
    minx, miny, maxx, maxy = bbox
    w, h = 2200, 3000
    margin = 100
    s = min((w - margin * 2) / max(maxx - minx, 1e-9), (h - margin * 2) / max(maxy - miny, 1e-9))
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)

    def tx(x, y):
        return int(round(margin + (x - minx) * s)), int(round(h - margin - (y - miny) * s))

    # Context/finiture: light gray.
    for seg in dwg_context:
        draw.line([tx(seg["x1"], seg["y1"]), tx(seg["x2"], seg["y2"])], fill=(190, 190, 190), width=1)

    # IFC roof edges: red.
    for seg in ifc_edges:
        draw.line([tx(seg["x1"], seg["y1"]), tx(seg["x2"], seg["y2"])], fill=(210, 45, 45), width=2)

    # DWG structural: black/orange depending on layer.
    for seg in dwg_struct:
        color = (25, 25, 25)
        if "quotatura" in seg["layer"].lower():
            color = (190, 100, 20)
        draw.line([tx(seg["x1"], seg["y1"]), tx(seg["x2"], seg["y2"])], fill=color, width=2)

    # V20 axes: cyan.
    for seg in v20_axes:
        draw.line([tx(seg["x1"], seg["y1"]), tx(seg["x2"], seg["y2"])], fill=(0, 170, 210), width=3)

    draw.rectangle([margin, margin, w - margin, h - margin], outline=(220, 220, 220), width=1)
    draw.text((margin, 28), "Confronto nativo: DWG struttura / IFC V03 falde / assi V20", fill=(0, 0, 0))
    draw.text((margin, 54), "nero = DWG strutturale, grigio = contesto DWG, rosso = falde IFC, ciano = assi V20", fill=(70, 70, 70))
    img.save(path, quality=92)


def main():
    dwg = read_dwg_segments()
    ifc_edges, ifc_points = read_ifc_edges()
    v20 = read_v20_axes()

    dwg_struct = [s for s in dwg if "strutturale" in s["layer"].lower() or "portante" in s["layer"].lower()]
    dwg_context = [s for s in dwg if s not in dwg_struct and s["length"] > 0.05]

    dwg_points = [(s["x1"], s["y1"]) for s in dwg_struct] + [(s["x2"], s["y2"]) for s in dwg_struct]
    ifc_edge_points = [(s["x1"], s["y1"]) for s in ifc_edges] + [(s["x2"], s["y2"]) for s in ifc_edges]
    v20_points = [(s["x1"], s["y1"]) for s in v20] + [(s["x2"], s["y2"]) for s in v20]

    b_dwg = bbox_points(dwg_points)
    b_ifc = bbox_points(ifc_edge_points)
    b_v20 = bbox_points(v20_points) if v20_points else b_ifc
    b_all = union_bbox([b_dwg, b_ifc, b_v20])

    render_overlay(
        dwg_struct,
        dwg_context,
        ifc_edges,
        v20,
        b_all,
        OUT / "confronto_nativo_dwg_struttura_ifc_v20.png",
    )

    cd = centroid_bbox(b_dwg)
    ci = centroid_bbox(b_ifc)
    cv = centroid_bbox(b_v20)
    sd = bbox_size(b_dwg)
    si = bbox_size(b_ifc)
    sv = bbox_size(b_v20)

    report = [
        "# Confronto DWG struttura 110626 / IFC V03 / V20",
        "",
        "Questa verifica non importa e non modifica nulla in Archicad.",
        "",
        "## Ingombri nativi",
        "",
        f"- DWG strutturale bbox: {b_dwg[0]:.3f}, {b_dwg[1]:.3f} -> {b_dwg[2]:.3f}, {b_dwg[3]:.3f} | size {sd[0]:.3f} x {sd[1]:.3f} | centro {cd[0]:.3f}, {cd[1]:.3f}",
        f"- IFC falde bbox: {b_ifc[0]:.3f}, {b_ifc[1]:.3f} -> {b_ifc[2]:.3f}, {b_ifc[3]:.3f} | size {si[0]:.3f} x {si[1]:.3f} | centro {ci[0]:.3f}, {ci[1]:.3f}",
        f"- V20 assi bbox: {b_v20[0]:.3f}, {b_v20[1]:.3f} -> {b_v20[2]:.3f}, {b_v20[3]:.3f} | size {sv[0]:.3f} x {sv[1]:.3f} | centro {cv[0]:.3f}, {cv[1]:.3f}",
        "",
        "## Scostamento dei centri",
        "",
        f"- centro DWG - centro IFC: dx {cd[0] - ci[0]:.3f}, dy {cd[1] - ci[1]:.3f}",
        f"- centro V20 - centro IFC: dx {cv[0] - ci[0]:.3f}, dy {cv[1] - ci[1]:.3f}",
        "",
        "## Direzioni dominanti",
        "",
        "DWG strutturale:",
    ]
    for a, total_len in dominant_angles(dwg_struct):
        report.append(f"- {a} gradi: lunghezza cumulata {total_len:.2f}")
    report.append("")
    report.append("IFC falde:")
    for a, total_len in dominant_angles(ifc_edges):
        report.append(f"- {a} gradi: lunghezza cumulata {total_len:.2f}")
    report.append("")
    report.append("## Output")
    report.append("")
    report.append("- `confronto_nativo_dwg_struttura_ifc_v20.png`")
    report.append("- `dwg_struttura_110626_flat_preview.png`")
    report.append("")
    report.append("## Nota operativa")
    report.append("")
    report.append("Se la tavola nativa non coincide, il passaggio successivo corretto e definire 3-4 punti omologhi tra DWG ingegnere e modello V03, poi applicare una trasformazione rigida/affine prima di generare nuove capriate.")
    (OUT / "confronto_dwg_struttura_ifc_v20_report.md").write_text("\n".join(report), encoding="utf-8")

    print("Confronto creato")
    print(f"DWG bbox {b_dwg}")
    print(f"IFC bbox {b_ifc}")
    print(f"Offset centro DWG-IFC dx={cd[0] - ci[0]:.3f} dy={cd[1] - ci[1]:.3f}")


if __name__ == "__main__":
    main()
