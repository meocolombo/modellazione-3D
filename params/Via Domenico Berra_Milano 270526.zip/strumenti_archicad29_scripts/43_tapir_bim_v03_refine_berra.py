from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_v03_bim_refine_result.json")
OUT_COMPUTO = Path("berra_v03_bim_computo_preliminare.csv")
OUT_MAPPING = Path("berra_v03_bim_guid_mapping.csv")
OUT_GEO = Path("berra_v03_georeferenziazione.txt")
OUT_CONTROL = Path("berra_v03_bim_controllo.txt")

STANDBY_LAYER = "BERRA_BIM_V03_STANDBY_PRECEDENTI"
STANDBY_PREFIXES = ("BERRA_BIM_V02_", "BERRA_BIM_V03_")
STANDBY_EXACT = {"BERRA_AI_DETTAGLI_01"}
KEEP_ROOF_LAYERS = {"Shell - Copertura", "BERRA_AI_COPERTURE_02"}

LAYERS = {
    "geo": ("BERRA_BIM_V03_00_GEO_MODELLO", 170),
    "roof": ("BERRA_BIM_V03_04_STRUTTURE_TETTO", 174),
    "openings": ("BERRA_BIM_V03_05_APERTURE_DECORI", 175),
    "loggia": ("BERRA_BIM_V03_06_LOGGIATI_PORTALI", 176),
    "green": ("BERRA_BIM_V03_07_VERDE_CONTESTO", 177),
    "site": ("BERRA_BIM_V03_08_PAVIMENTAZIONI_ARREDI", 178),
    "proxy": ("BERRA_BIM_V03_09_PROXY_ASSET_BLENDER", 179),
}

SITE_WGS84 = {
    "address": "Via Domenico Berra 10/12/14, Milano",
    "latitude": 45.50849058,
    "longitude": 9.24840835,
    "note": "Il PLN e' mantenuto nel suo sistema locale: gli elementi V03 sono allineati al modello corretto dall'utente, non alle coordinate GIS assolute.",
}


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def dim3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def normalize_elements(elements):
    normalized = []
    for element in elements or []:
        if "elementId" in element:
            normalized.append(element)
        elif "guid" in element:
            normalized.append({"elementId": {"guid": element["guid"]}})
    return normalized


def layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types, name, group, hidden=False):
    existing = layer_index(commands, types, name)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": name,
                    "isHidden": bool(hidden),
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": int(group),
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = layer_index(commands, types, name)
    if created is None:
        raise RuntimeError(f"Layer non creato: {name}")
    return created


def layers_map(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): str(item["name"]) for item in result.get("attributes", [])}


def get_model(commands, types):
    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])
    layer_names = layers_map(commands, types)
    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        box = box_item.get("boundingBox3D", {})
        try:
            layer_name = layer_names.get(int(detail.get("layerIndex", -999)), "")
        except Exception:
            layer_name = ""
        rows.append(
            {
                "element": element,
                "guid": element.get("elementId", {}).get("guid", ""),
                "type": detail.get("type", ""),
                "id": detail.get("id", ""),
                "layer": layer_name,
                "details": detail.get("details", {}),
                "xMin": float(box.get("xMin", 0.0)),
                "xMax": float(box.get("xMax", 0.0)),
                "yMin": float(box.get("yMin", 0.0)),
                "yMax": float(box.get("yMax", 0.0)),
                "zMin": float(box.get("zMin", 0.0)),
                "zMax": float(box.get("zMax", 0.0)),
            }
        )
    return rows


def should_standby(row):
    layer = row["layer"]
    if layer in KEEP_ROOF_LAYERS:
        return False
    if layer == STANDBY_LAYER:
        return False
    if layer in STANDBY_EXACT:
        return True
    return any(layer.startswith(prefix) for prefix in STANDBY_PREFIXES) and layer != STANDBY_LAYER


def should_skip_for_base(row):
    return row["layer"] == STANDBY_LAYER or should_standby(row)


def set_details(commands, types, elements, details):
    elements = normalize_elements(elements)
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {"elementsWithDetails": [{"elementId": el["elementId"], "details": details} for el in elements]},
    )


def set_layer(commands, types, elements, target_layer):
    return set_details(commands, types, elements, {"layerIndex": target_layer})


def try_set_ids(commands, types, elements, codes):
    # Non tutti i dettagli sono modificabili in ogni build; il computo resta comunque
    # tracciato nel CSV. Questo tentativo aggiorna l'ID quando Tapir lo accetta.
    updated = 0
    failed = 0
    for element, code in zip(normalize_elements(elements), codes):
        try:
            set_details(commands, types, [element], {"id": code})
            updated += 1
        except Exception:
            failed += 1
    return {"updated": updated, "failed": failed}


def move_previous(commands, types, standby_index, rows):
    to_move = [row["element"] for row in rows if should_standby(row)]
    if not to_move:
        return {"movedCount": 0}
    result = set_layer(commands, types, to_move, standby_index)
    return {"movedCount": len(to_move), "result": result}


def length2(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def code(prefix, index):
    return f"BER-V03-{prefix}-{index:03d}"


def add_mapping(mapping, guid, item_code, category, layer, source):
    if guid:
        mapping.append(
            {
                "guid": guid,
                "codice_id": item_code,
                "categoria": category,
                "layer": layer,
                "sorgente": source,
            }
        )


def add_computo(computo, item_code, category, description, qty, unit, param=0.0, qty2=0.0, unit2=""):
    computo.append(
        {
            "codice_id": item_code,
            "categoria": category,
            "descrizione": description,
            "quantita_primaria": round(float(qty), 4),
            "unita_primaria": unit,
            "parametro_secondario": round(float(param), 4) if isinstance(param, (int, float)) else param,
            "quantita_secondaria": round(float(qty2), 4) if isinstance(qty2, (int, float)) else qty2,
            "unita_secondaria": unit2,
        }
    )


def bbox_area(row):
    return max(0.0, row["xMax"] - row["xMin"]) * max(0.0, row["yMax"] - row["yMin"])


def collect_existing_quantities(rows, mapping, computo):
    counters = defaultdict(int)
    for row in rows:
        if should_skip_for_base(row):
            continue
        typ = row["type"]
        if typ == "Wall":
            counters["WAL"] += 1
            item_code = code("WAL", counters["WAL"])
            d = row["details"]
            beg = d.get("begCoordinate", {})
            end = d.get("endCoordinate", {})
            if "x" in beg and "x" in end:
                length = length2(float(beg["x"]), float(beg["y"]), float(end["x"]), float(end["y"]))
            else:
                length = max(row["xMax"] - row["xMin"], row["yMax"] - row["yMin"])
            height = float(d.get("height", row["zMax"] - row["zMin"] or 3.0) or 3.0)
            thickness = float(d.get("thickness", 0.40) or 0.40)
            add_mapping(mapping, row["guid"], item_code, "Muratura esistente", row["layer"], row["id"])
            add_computo(computo, item_code, "Muratura", row["id"] or "muratura", length, "m", thickness, length * height * thickness, "m3")
        elif typ == "Slab":
            counters["SLB"] += 1
            item_code = code("SLB", counters["SLB"])
            area = bbox_area(row)
            thickness = max(0.05, row["zMax"] - row["zMin"])
            add_mapping(mapping, row["guid"], item_code, "Solaio esistente", row["layer"], row["id"])
            add_computo(computo, item_code, "Solaio", row["id"] or "solaio", area, "m2", thickness, area * thickness, "m3")
        elif typ == "Roof":
            counters["ROF"] += 1
            item_code = code("ROF", counters["ROF"])
            area = bbox_area(row)
            thickness = max(0.12, min(0.35, row["zMax"] - row["zMin"] or 0.18))
            add_mapping(mapping, row["guid"], item_code, "Copertura esistente", row["layer"], row["id"])
            add_computo(computo, item_code, "Copertura", row["id"] or "copertura", area, "m2", thickness, area * thickness, "m3")
        elif typ in ("Window", "Door", "Column"):
            counters[typ] += 1
            item_code = code(typ[:3].upper(), counters[typ])
            add_mapping(mapping, row["guid"], item_code, f"{typ} esistente", row["layer"], row["id"])
            add_computo(computo, item_code, typ, row["id"] or typ, 1, "cad", 0, 1, "cad")


def beam(x1, y1, x2, y2, z, width, height):
    return {
        "begCoordinate": coord(x1, y1),
        "endCoordinate": coord(x2, y2),
        "zCoordinate": float(z),
        "width": float(width),
        "height": float(height),
    }


def box(x, y, z, sx, sy, sz):
    return {"basePoint": point3(x, y, z), "size": dim3(sx, sy, sz)}


def create_beams(commands, types, layer, layer_name, data, codes, category, mapping, computo):
    if not data:
        return {"requested": 0, "created": 0, "ids": {"updated": 0, "failed": 0}}
    result = tapir(commands, types, "CreateBeams", {"beamsData": data})
    elements = normalize_elements(result.get("elements", []))
    set_layer(commands, types, elements, layer)
    ids = try_set_ids(commands, types, elements, codes)
    for element, item, item_code in zip(elements, data, codes):
        beg = item["begCoordinate"]
        end = item["endCoordinate"]
        length = length2(beg["x"], beg["y"], end["x"], end["y"])
        volume = length * float(item["width"]) * float(item["height"])
        add_mapping(mapping, element["elementId"].get("guid", ""), item_code, category, layer_name, "beam")
        add_computo(computo, item_code, category, category.lower(), length, "m", item["width"] * item["height"], volume, "m3")
    return {"requested": len(data), "created": len(elements), "ids": ids}


def create_morphs(commands, types, layer, layer_name, data, codes, category, mapping, computo):
    if not data:
        return {"requested": 0, "created": 0, "ids": {"updated": 0, "failed": 0}}
    result = tapir(commands, types, "CreateMorphs", {"morphsData": data})
    elements = normalize_elements(result.get("elements", []))
    set_layer(commands, types, elements, layer)
    ids = try_set_ids(commands, types, elements, codes)
    for element, item, item_code in zip(elements, data, codes):
        size = item.get("size", {})
        sx, sy, sz = float(size.get("x", 0)), float(size.get("y", 0)), float(size.get("z", 0))
        add_mapping(mapping, element["elementId"].get("guid", ""), item_code, category, layer_name, "morph")
        add_computo(computo, item_code, category, category.lower(), max(sx * sy, 0.001), "m2", sz, sx * sy * sz, "m3")
    return {"requested": len(data), "created": len(elements), "ids": ids}


def create_slabs(commands, types, layer, layer_name, data, codes, category, mapping, computo):
    if not data:
        return {"requested": 0, "created": 0, "ids": {"updated": 0, "failed": 0}}
    result = tapir(commands, types, "CreateSlabs", {"slabsData": data})
    elements = normalize_elements(result.get("elements", []))
    set_layer(commands, types, elements, layer)
    ids = try_set_ids(commands, types, elements, codes)
    for element, item, item_code in zip(elements, data, codes):
        pts = item["polygonCoordinates"]
        area = polygon_area(pts)
        thickness = float(item.get("thickness", 0.0))
        add_mapping(mapping, element["elementId"].get("guid", ""), item_code, category, layer_name, "slab")
        add_computo(computo, item_code, category, category.lower(), area, "m2", thickness, area * thickness, "m3")
    return {"requested": len(data), "created": len(elements), "ids": ids}


def polygon_area(pts):
    if not pts:
        return 0.0
    area = 0.0
    closed = pts + [pts[0]]
    for p1, p2 in zip(closed, closed[1:]):
        area += p1["x"] * p2["y"] - p2["x"] * p1["y"]
    return abs(area) / 2.0


def base_rows(rows):
    return [row for row in rows if not should_skip_for_base(row)]


def model_extents(rows):
    usable = [r for r in rows if r["type"] in ("Wall", "Slab", "Roof", "Column")]
    return {
        "xMin": min((r["xMin"] for r in usable), default=0.0),
        "xMax": max((r["xMax"] for r in usable), default=0.0),
        "yMin": min((r["yMin"] for r in usable), default=0.0),
        "yMax": max((r["yMax"] for r in usable), default=0.0),
        "zMin": min((r["zMin"] for r in usable), default=0.0),
        "zMax": max((r["zMax"] for r in usable), default=0.0),
    }


def build_roof_structures(roof_rows):
    beams = []
    codes = []
    idx = 1
    for roof in sorted(roof_rows, key=lambda r: (r["yMin"], r["xMin"])):
        x1, x2 = roof["xMin"], roof["xMax"]
        y1, y2 = roof["yMin"], roof["yMax"]
        sx, sy = x2 - x1, y2 - y1
        if sx < 1.2 or sy < 1.2:
            continue
        z_low = max(roof["zMin"] + 0.08, min(roof["zMax"] - 0.15, roof["zMin"] + 0.35))
        z_high = roof["zMax"] + 0.05
        span_short = min(sx, sy)
        major_y = sy >= sx
        # Colmo, dormienti/gronde e assiti principali derivano solo dal rettangolo del tetto V02.
        if major_y:
            xm = (x1 + x2) / 2.0
            beams.append(beam(xm, y1 + 0.18, xm, y2 - 0.18, z_high, 0.11, 0.10))
            codes.append(code("STR-COL", idx)); idx += 1
            beams.extend([
                beam(x1 + 0.12, y1, x1 + 0.12, y2, z_low, 0.08, 0.06),
                beam(x2 - 0.12, y1, x2 - 0.12, y2, z_low, 0.08, 0.06),
            ])
            codes.extend([code("STR-GRN", idx), code("STR-GRN", idx + 1)]); idx += 2
            step = max(3.2, min(5.2, sy / max(1, round(sy / 4.4))))
            y = y1 + step
            while y < y2 - 0.40:
                beams.append(beam(x1 + 0.18, y, x2 - 0.18, y, z_low + 0.25, 0.14, 0.11))
                codes.append(code("STR-CAP", idx)); idx += 1
                y += step
            for off in (0.30, 0.50, 0.70):
                x = x1 + sx * off
                beams.append(beam(x, y1 + 0.20, x, y2 - 0.20, z_low + 0.16, 0.07, 0.055))
                codes.append(code("STR-ASS", idx)); idx += 1
        else:
            ym = (y1 + y2) / 2.0
            beams.append(beam(x1 + 0.18, ym, x2 - 0.18, ym, z_high, 0.11, 0.10))
            codes.append(code("STR-COL", idx)); idx += 1
            beams.extend([
                beam(x1, y1 + 0.12, x2, y1 + 0.12, z_low, 0.08, 0.06),
                beam(x1, y2 - 0.12, x2, y2 - 0.12, z_low, 0.08, 0.06),
            ])
            codes.extend([code("STR-GRN", idx), code("STR-GRN", idx + 1)]); idx += 2
            step = max(3.2, min(5.2, sx / max(1, round(sx / 4.4))))
            x = x1 + step
            while x < x2 - 0.40:
                beams.append(beam(x, y1 + 0.18, x, y2 - 0.18, z_low + 0.25, 0.14, 0.11))
                codes.append(code("STR-CAP", idx)); idx += 1
                x += step
            for off in (0.30, 0.50, 0.70):
                y = y1 + sy * off
                beams.append(beam(x1 + 0.20, y, x2 - 0.20, y, z_low + 0.16, 0.07, 0.055))
                codes.append(code("STR-ASS", idx)); idx += 1
        # Piccoli controventi sui tetti piu' larghi: segnalano la struttura da affinare in sezione.
        if span_short > 4.0:
            beams.append(beam(x1 + 0.25, y1 + 0.25, x2 - 0.25, y2 - 0.25, z_low + 0.30, 0.055, 0.045))
            codes.append(code("STR-CNT", idx)); idx += 1
            beams.append(beam(x2 - 0.25, y1 + 0.25, x1 + 0.25, y2 - 0.25, z_low + 0.30, 0.055, 0.045))
            codes.append(code("STR-CNT", idx)); idx += 1
    return beams, codes


def build_opening_decors(window_rows, door_rows):
    morphs = []
    codes = []
    idx = 1

    def frame_for(row, prefix, frame=0.10, depth_extra=0.08):
        nonlocal idx
        x1, x2 = row["xMin"], row["xMax"]
        y1, y2 = row["yMin"], row["yMax"]
        z1, z2 = row["zMin"], row["zMax"]
        sx, sy = max(0.15, x2 - x1), max(0.15, y2 - y1)
        h = max(0.45, z2 - z1)
        if sx >= sy:
            depth = max(0.13, sy + depth_extra)
            y = y1 - (depth - sy) / 2.0
            morphs.append(box(x1 - frame, y, z1, frame, depth, h))
            codes.append(code(f"{prefix}-STP", idx)); idx += 1
            morphs.append(box(x2, y, z1, frame, depth, h))
            codes.append(code(f"{prefix}-STP", idx)); idx += 1
            morphs.append(box(x1 - frame, y, z2, sx + 2 * frame, depth, frame))
            codes.append(code(f"{prefix}-ARC", idx)); idx += 1
            if prefix == "WIN":
                morphs.append(box(x1 - frame, y, z1 - frame, sx + 2 * frame, depth, frame))
                codes.append(code(f"{prefix}-DAV", idx)); idx += 1
        else:
            depth = max(0.13, sx + depth_extra)
            x = x1 - (depth - sx) / 2.0
            morphs.append(box(x, y1 - frame, z1, depth, frame, h))
            codes.append(code(f"{prefix}-STP", idx)); idx += 1
            morphs.append(box(x, y2, z1, depth, frame, h))
            codes.append(code(f"{prefix}-STP", idx)); idx += 1
            morphs.append(box(x, y1 - frame, z2, depth, sy + 2 * frame, frame))
            codes.append(code(f"{prefix}-ARC", idx)); idx += 1
            if prefix == "WIN":
                morphs.append(box(x, y1 - frame, z1 - frame, depth, sy + 2 * frame, frame))
                codes.append(code(f"{prefix}-DAV", idx)); idx += 1

    for row in sorted(window_rows, key=lambda r: (r["yMin"], r["xMin"], r["zMin"])):
        frame_for(row, "WIN", frame=0.09)
    for row in sorted(door_rows, key=lambda r: (r["yMin"], r["xMin"], r["zMin"])):
        frame_for(row, "DOR", frame=0.14)
    return morphs, codes


def center(row):
    return ((row["xMin"] + row["xMax"]) / 2.0, (row["yMin"] + row["yMax"]) / 2.0, row["zMin"], row["zMax"])


def build_loggia_portals(column_rows, include_pillars=False):
    beams = []
    beam_codes = []
    morphs = []
    morph_codes = []
    if len(column_rows) < 2:
        return beams, beam_codes, morphs, morph_codes

    cols = [(*center(r), r) for r in column_rows if r["zMax"] - r["zMin"] > 0.4]
    if len(cols) < 2:
        return beams, beam_codes, morphs, morph_codes
    x_range = max(c[0] for c in cols) - min(c[0] for c in cols)
    y_range = max(c[1] for c in cols) - min(c[1] for c in cols)
    sort_index = 1 if y_range >= x_range else 0
    cols = sorted(cols, key=lambda c: c[sort_index])
    bidx = 1
    midx = 1

    if include_pillars:
        for col in column_rows:
            sx = max(0.18, col["xMax"] - col["xMin"])
            sy = max(0.18, col["yMax"] - col["yMin"])
            sz = max(1.80, col["zMax"] - col["zMin"])
            morphs.append(box(col["xMin"], col["yMin"], col["zMin"], sx, sy, sz))
            morph_codes.append(code("LOG-COL", midx)); midx += 1

    for a, b in zip(cols, cols[1:]):
        x1, y1, zmin1, zmax1, _ = a
        x2, y2, zmin2, zmax2, _ = b
        d = length2(x1, y1, x2, y2)
        if d < 0.65 or d > 6.50:
            continue
        z_top = max(zmax1, zmax2) + 0.06
        beams.append(beam(x1, y1, x2, y2, z_top, 0.18, 0.18))
        beam_codes.append(code("LOG-TRV", bidx)); bidx += 1
        beams.append(beam(x1, y1, x2, y2, min(zmax1, zmax2) - 0.55, 0.075, 0.06))
        beam_codes.append(code("LOG-RNG", bidx)); bidx += 1

        # Conci schematici dell'arco, ancorati tra le colonne esistenti.
        arch_steps = 5
        for i in range(arch_steps):
            t = i / (arch_steps - 1)
            x = x1 + (x2 - x1) * t
            y = y1 + (y2 - y1) * t
            crown = math.sin(math.pi * t)
            z = min(zmax1, zmax2) - 0.30 + crown * 0.42
            if abs(x2 - x1) >= abs(y2 - y1):
                morphs.append(box(x - 0.16, y - 0.08, z, 0.32, 0.16, 0.18))
            else:
                morphs.append(box(x - 0.08, y - 0.16, z, 0.16, 0.32, 0.18))
            morph_codes.append(code("LOG-ARC", midx)); midx += 1
    return beams, beam_codes, morphs, morph_codes


def build_green_site(rows, column_rows):
    ext = model_extents(rows)
    x_min, x_max = ext["xMin"], ext["xMax"]
    y_min, y_max = ext["yMin"], ext["yMax"]
    slabs = []
    slab_codes = []
    beams = []
    beam_codes = []
    morphs = []
    morph_codes = []

    def add_slab(prefix, pts, level, thickness):
        idx = len(slab_codes) + 1
        slabs.append({"level": level, "thickness": thickness, "polygonCoordinates": [coord(x, y) for x, y in pts]})
        slab_codes.append(code(prefix, idx))
        closed = pts + [pts[0]]
        for p1, p2 in zip(closed, closed[1:]):
            beams.append(beam(p1[0], p1[1], p2[0], p2[1], level + thickness + 0.03, 0.055, 0.04))
            beam_codes.append(code(f"{prefix}-BD", len(beam_codes) + 1))

    if column_rows:
        cx1 = min(r["xMin"] for r in column_rows) - 1.4
        cx2 = max(r["xMax"] for r in column_rows) + 1.4
        cy1 = min(r["yMin"] for r in column_rows) - 1.0
        cy2 = max(r["yMax"] for r in column_rows) + 1.0
        add_slab("CRT", [(cx1, cy1), (cx2, cy1), (cx2, cy2), (cx1, cy2)], 0.015, 0.06)

    width = max(6.0, x_max - x_min)
    length = max(12.0, y_max - y_min)
    garden_x1 = x_min + width * 0.18
    garden_x2 = x_max - width * 0.18
    garden_y1 = y_min + length * 0.11
    garden_y2 = y_min + length * 0.45
    add_slab("GRN", [(garden_x1, garden_y1), (garden_x2, garden_y1), (garden_x2, garden_y2), (garden_x1, garden_y2)], 0.02, 0.055)
    add_slab("PAV", [(x_min + 0.3, y_min + 0.3), (x_max - 0.3, y_min + 0.3), (x_max - 0.3, y_min + 2.2), (x_min + 0.3, y_min + 2.2)], 0.0, 0.07)

    # Alberi, pozzo e sedute come masse computabili/proxy.
    tree_points = [
        (garden_x1 + (garden_x2 - garden_x1) * 0.18, garden_y1 + (garden_y2 - garden_y1) * 0.25, 1.1),
        (garden_x1 + (garden_x2 - garden_x1) * 0.42, garden_y1 + (garden_y2 - garden_y1) * 0.70, 1.35),
        (garden_x1 + (garden_x2 - garden_x1) * 0.73, garden_y1 + (garden_y2 - garden_y1) * 0.37, 1.25),
    ]
    if column_rows:
        tree_points.append(((cx1 + cx2) / 2.0, cy1 + 0.65 * (cy2 - cy1), 1.0))
    for x, y, scale in tree_points:
        morphs.append(box(x - 0.12, y - 0.12, 0.0, 0.24, 0.24, 1.9 * scale))
        morph_codes.append(code("ARB-FUS", len(morph_codes) + 1))
        morphs.append(box(x - 0.78 * scale, y - 0.78 * scale, 1.45 * scale, 1.56 * scale, 1.56 * scale, 1.10 * scale))
        morph_codes.append(code("ARB-CHI", len(morph_codes) + 1))

    well_x = (garden_x1 + garden_x2) / 2.0
    well_y = garden_y1 + (garden_y2 - garden_y1) * 0.48
    morphs.extend([
        box(well_x - 0.45, well_y - 0.45, 0.02, 0.90, 0.90, 0.16),
        box(well_x - 0.34, well_y - 0.34, 0.18, 0.68, 0.68, 0.62),
        box(well_x - 0.48, well_y - 0.09, 0.88, 0.96, 0.18, 0.16),
    ])
    morph_codes.extend([code("ARR-POZ", 1), code("ARR-POZ", 2), code("ARR-POZ", 3)])
    for i, y in enumerate((garden_y1 + 1.4, garden_y2 - 1.4), start=1):
        morphs.append(box(garden_x2 - 2.4, y - 0.22, 0.12, 1.85, 0.44, 0.20))
        morph_codes.append(code("ARR-SED", i))
    return slabs, slab_codes, beams, beam_codes, morphs, morph_codes


def build_chimneys_and_asset_proxies(roof_rows):
    morphs = []
    codes = []
    idx = 1
    for roof in sorted(roof_rows, key=lambda r: bbox_area(r), reverse=True)[:8]:
        sx = roof["xMax"] - roof["xMin"]
        sy = roof["yMax"] - roof["yMin"]
        if sx < 3.0 or sy < 3.0:
            continue
        x = roof["xMin"] + sx * 0.58
        y = roof["yMin"] + sy * 0.42
        z = roof["zMax"] + 0.02
        morphs.append(box(x - 0.18, y - 0.18, z, 0.36, 0.36, 1.05))
        codes.append(code("PRX-CAM", idx)); idx += 1
        morphs.append(box(x - 0.25, y - 0.25, z + 1.05, 0.50, 0.50, 0.12))
        codes.append(code("PRX-CAM", idx)); idx += 1
    return morphs, codes


def build_geo_markers(ext):
    x0 = ext["xMax"] + 2.0
    y0 = ext["yMax"] + 2.0
    return [
        beam(x0, y0, x0, y0 + 8.0, 0.20, 0.10, 0.06),
        beam(x0 - 1.2, y0 + 6.5, x0, y0 + 8.0, 0.20, 0.06, 0.04),
        beam(x0 + 1.2, y0 + 6.5, x0, y0 + 8.0, 0.20, 0.06, 0.04),
    ], [code("GEO", 1), code("GEO", 2), code("GEO", 3)]


def write_csv(path, rows, fieldnames):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def write_geo_report(ext, base_counts):
    OUT_GEO.write_text(
        "\n".join(
            [
                "GEOREFERENZIAZIONE / ALLINEAMENTO V03 - VIA BERRA",
                "=" * 52,
                f"Indirizzo riferimento: {SITE_WGS84['address']}",
                f"Latitudine Google Earth: {SITE_WGS84['latitude']}",
                f"Longitudine Google Earth: {SITE_WGS84['longitude']}",
                "",
                SITE_WGS84["note"],
                "",
                "Estensione modello locale letta dal PLN:",
                f"X {ext['xMin']:.2f} .. {ext['xMax']:.2f}",
                f"Y {ext['yMin']:.2f} .. {ext['yMax']:.2f}",
                f"Z {ext['zMin']:.2f} .. {ext['zMax']:.2f}",
                "",
                "Conteggio base usato per l'allineamento:",
                *(f"- {typ}: {count}" for typ, count in sorted(base_counts.items())),
                "",
                "Nota operativa: per non deformare le falde V02 corrette manualmente, non e' stata applicata nessuna rototraslazione globale. Gli elementi V03 sono derivati da bounding box e posizioni reali degli elementi presenti nel file.",
            ]
        ),
        encoding="utf-8",
    )


def write_control(rows, moved_count, created_summary):
    counts = Counter(row["type"] for row in rows)
    layer_counts = Counter(row["layer"] for row in rows)
    lines = [
        "BERRA V03 BIM REFINE - CONTROLLO",
        "=" * 38,
        f"Elementi precedenti spostati in stand-by: {moved_count}",
        "",
        "Conteggio tipi dopo V03:",
        *(f"- {typ}: {count}" for typ, count in sorted(counts.items())),
        "",
        "Layer principali dopo V03:",
        *(f"- {layer}: {count}" for layer, count in sorted(layer_counts.items(), key=lambda item: (-item[1], item[0]))[:24]),
        "",
        "Creazioni V03:",
        *(f"- {name}: {value}" for name, value in created_summary.items()),
    ]
    OUT_CONTROL.write_text("\n".join(lines), encoding="utf-8")


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Rifinisce il modello Berra V03 basandosi sugli elementi del PLN V02.")
        print("Uso: py 43_tapir_bim_v03_refine_berra.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types

    standby = create_or_get_layer(commands, types, STANDBY_LAYER, 169, hidden=True)
    layer_ids = {key: create_or_get_layer(commands, types, *value) for key, value in LAYERS.items()}
    layer_names = {key: value[0] for key, value in LAYERS.items()}

    rows_before_move = get_model(commands, types)
    standby_result = move_previous(commands, types, standby, rows_before_move)
    all_rows_after_move = get_model(commands, types)
    rows = base_rows(all_rows_after_move)
    ext = model_extents(rows)
    base_counts = Counter(row["type"] for row in rows)

    mapping = []
    computo = []
    collect_existing_quantities(rows, mapping, computo)

    roof_rows = [row for row in rows if row["type"] == "Roof"]
    window_rows = [row for row in rows if row["type"] == "Window"]
    door_rows = [row for row in rows if row["type"] == "Door"]
    column_rows = [row for row in rows if row["type"] == "Column"]
    use_standby_columns = False
    if not column_rows:
        column_rows = [row for row in all_rows_after_move if row["type"] == "Column" and row["layer"] == STANDBY_LAYER]
        use_standby_columns = bool(column_rows)

    roof_beams, roof_codes = build_roof_structures(roof_rows)
    roof_result = create_beams(commands, types, layer_ids["roof"], layer_names["roof"], roof_beams, roof_codes, "Struttura copertura", mapping, computo)

    opening_morphs, opening_codes = build_opening_decors(window_rows, door_rows)
    opening_result = create_morphs(commands, types, layer_ids["openings"], layer_names["openings"], opening_morphs, opening_codes, "Finitura aperture", mapping, computo)

    loggia_beams, loggia_beam_codes, loggia_morphs, loggia_morph_codes = build_loggia_portals(column_rows, include_pillars=use_standby_columns)
    loggia_beam_result = create_beams(commands, types, layer_ids["loggia"], layer_names["loggia"], loggia_beams, loggia_beam_codes, "Loggiato e portali", mapping, computo)
    loggia_morph_result = create_morphs(commands, types, layer_ids["loggia"], layer_names["loggia"], loggia_morphs, loggia_morph_codes, "Conci arco loggiato", mapping, computo)

    slabs, slab_codes, green_beams, green_beam_codes, green_morphs, green_morph_codes = build_green_site(rows, column_rows)
    green_slab_result = create_slabs(commands, types, layer_ids["green"], layer_names["green"], slabs, slab_codes, "Verde/pavimentazioni", mapping, computo)
    green_beam_result = create_beams(commands, types, layer_ids["green"], layer_names["green"], green_beams, green_beam_codes, "Cordoli verde", mapping, computo)
    green_morph_result = create_morphs(commands, types, layer_ids["site"], layer_names["site"], green_morphs, green_morph_codes, "Arredi e verde", mapping, computo)

    proxy_morphs, proxy_codes = build_chimneys_and_asset_proxies(roof_rows)
    proxy_result = create_morphs(commands, types, layer_ids["proxy"], layer_names["proxy"], proxy_morphs, proxy_codes, "Proxy asset Blender", mapping, computo)

    geo_beams, geo_codes = build_geo_markers(ext)
    geo_result = create_beams(commands, types, layer_ids["geo"], layer_names["geo"], geo_beams, geo_codes, "Georeferenziazione", mapping, computo)

    write_csv(
        OUT_COMPUTO,
        computo,
        [
            "codice_id",
            "categoria",
            "descrizione",
            "quantita_primaria",
            "unita_primaria",
            "parametro_secondario",
            "quantita_secondaria",
            "unita_secondaria",
        ],
    )
    write_csv(OUT_MAPPING, mapping, ["guid", "codice_id", "categoria", "layer", "sorgente"])
    write_geo_report(ext, base_counts)

    created_summary = {
        "strutture_tetto_travi": roof_result["created"],
        "decori_aperture_morph": opening_result["created"],
        "loggiati_travi": loggia_beam_result["created"],
        "loggiati_conci_morph": loggia_morph_result["created"],
        "verde_solai": green_slab_result["created"],
        "verde_cordoli": green_beam_result["created"],
        "arredi_verde_morph": green_morph_result["created"],
        "proxy_blender_morph": proxy_result["created"],
        "geo_travi": geo_result["created"],
        "colonne_riferimento_standby_usate": len(column_rows) if use_standby_columns else 0,
    }

    final_rows = get_model(commands, types)
    write_control(final_rows, standby_result.get("movedCount", 0), created_summary)

    result = {
        "standby": standby_result,
        "layers": layer_ids,
        "baseCounts": dict(base_counts),
        "modelExtents": ext,
        "created": created_summary,
        "outputs": {
            "computo": str(OUT_COMPUTO),
            "mapping": str(OUT_MAPPING),
            "georef": str(OUT_GEO),
            "control": str(OUT_CONTROL),
        },
    }
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print("V03 completata.")
    print(f"Elementi precedenti spostati in stand-by: {standby_result.get('movedCount', 0)}")
    print(f"Base usata: {dict(base_counts)}")
    for name, value in created_summary.items():
        print(f"{name}: {value}")
    print(f"Computo: {OUT_COMPUTO}")
    print(f"Mappatura GUID/ID: {OUT_MAPPING}")
    print(f"Controllo: {OUT_CONTROL}")
    print("Nota: salva manualmente il PLN in Archicad dopo aver verificato la vista 3D.")


if __name__ == "__main__":
    main()
