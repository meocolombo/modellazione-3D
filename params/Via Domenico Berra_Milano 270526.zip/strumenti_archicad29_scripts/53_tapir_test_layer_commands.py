from __future__ import annotations

from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("berra_test_layer_commands.txt")
COMMANDS = [
    "SetLayerSettings",
    "SetLayers",
    "ModifyLayers",
    "UpdateLayers",
    "SetAttributes",
    "SetAttributesByType",
    "ModifyAttributes",
    "UpdateAttributes",
    "DeleteElements",
    "SetDetailsOfElements",
    "GetAttributesByType",
]


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    lines = []
    for name in COMMANDS:
        try:
            available = commands.IsAddOnCommandAvailable(types.AddOnCommandId("TapirCommand", name))
            lines.append(f"{name}: {'OK' if available else 'NO'}")
        except Exception as exc:
            lines.append(f"{name}: ERRORE {exc}")
    OUT_TXT.write_text("\n".join(lines), encoding="utf-8")
    print(OUT_TXT)


if __name__ == "__main__":
    main()
