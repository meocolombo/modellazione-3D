from __future__ import annotations

import csv
from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("report_proprieta_mappate.txt")
OUT_CSV = Path("report_proprieta_mappate.csv")


def get_attr(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def guid_of(element):
    element_id = get_attr(element, "elementId")
    return get_attr(element_id, "guid", str(element_id))


def short_repr(value, limit=180):
    text = repr(value)
    if len(text) > limit:
        return text[: limit - 3] + "..."
    return text


def unwrap_property_value(item):
    """Return a compact status/type/value tuple from Archicad property wrappers."""
    prop_value = get_attr(item, "propertyValue", item)
    value = get_attr(prop_value, "value", None)
    status = get_attr(prop_value, "status", None)

    if status is None:
        status = get_attr(prop_value, "propertyValueStatus", None)
    if status is None and isinstance(prop_value, dict):
        status = prop_value.get("type")

    value_type = type(value).__name__ if value is not None else type(prop_value).__name__
    readable_value = value if value is not None else prop_value

    return str(status or ""), value_type, short_repr(readable_value)


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    acc = conn.commands
    selected = acc.GetSelectedElements()
    if not selected:
        raise SystemExit("Nessun elemento selezionato.")

    property_names = acc.GetAllPropertyNames()
    property_ids = acc.GetPropertyIds(property_names)
    value_wrappers = acc.GetPropertyValuesOfElements(selected, property_ids)

    rows = []
    for element_index, element in enumerate(selected, start=1):
        wrapper = value_wrappers[element_index - 1]
        values = get_attr(wrapper, "propertyValues", [])

        for prop_index, prop_name in enumerate(property_names):
            prop_id = property_ids[prop_index]
            item = values[prop_index] if prop_index < len(values) else None
            status, value_type, value = unwrap_property_value(item)

            rows.append(
                {
                    "elemento": element_index,
                    "guid": guid_of(element),
                    "proprieta": str(prop_name),
                    "property_id": short_repr(prop_id, 120),
                    "stato": status,
                    "tipo_valore": value_type,
                    "valore": value,
                }
            )

    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["elemento", "guid", "proprieta", "property_id", "stato", "tipo_valore", "valore"],
            delimiter=";",
        )
        writer.writeheader()
        writer.writerows(rows)

    available_rows = [row for row in rows if "notAvailable" not in row["valore"] and "notAvailable" not in row["stato"]]
    with OUT_TXT.open("w", encoding="utf-8") as handle:
        handle.write("REPORT PROPRIETA MAPPATE - ARCHICAD 29\n")
        handle.write("=" * 46 + "\n\n")
        handle.write(f"Elementi selezionati: {len(selected)}\n")
        handle.write(f"Proprieta lette: {len(property_names)}\n")
        handle.write(f"Righe totali: {len(rows)}\n")
        handle.write(f"Righe con valore disponibile apparente: {len(available_rows)}\n\n")
        handle.write("Prime proprieta con valore disponibile:\n")
        for row in available_rows[:80]:
            handle.write(
                f"- elemento {row['elemento']} | {row['proprieta']} | "
                f"{row['tipo_valore']} | {row['valore']}\n"
            )

    print("Creati:")
    print(f"- {OUT_TXT}")
    print(f"- {OUT_CSV}")
    print(f"Righe totali: {len(rows)}")
    print(f"Righe con valore disponibile apparente: {len(available_rows)}")


if __name__ == "__main__":
    main()
