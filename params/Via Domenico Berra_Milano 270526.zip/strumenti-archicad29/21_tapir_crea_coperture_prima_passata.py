from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_coperture_prima_passata_result.json")
LAYER_NAME = "BERRA_AI_COPERTURE_01"


ROOFS = [
    {
        "nome": "ala_sud_est",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-20.40, -72.30), (-8.20, -72.30), (-8.20, -38.30), (-20.40, -38.30)],
    },
    {
        "nome": "ala_sud_ovest",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-40.00, -63.70), (-17.00, -63.70), (-17.00, -20.70), (-40.00, -20.70)],
    },
    {
        "nome": "corpo_centrale_ovest",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-48.80, -33.80), (-43.50, -33.80), (-43.50, -6.60), (-48.80, -6.60)],
    },
    {
        "nome": "corpo_centrale_sud",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-47.80, -17.00), (-8.00, -17.00), (-8.00, -6.60), (-47.80, -6.60)],
    },
    {
        "nome": "corpo_centrale_est",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-16.90, -39.60), (-7.70, -39.60), (-7.70, 14.40), (-16.90, 14.40)],
    },
    {
        "nome": "corpo_nord_ovest",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-39.20, 8.20), (-25.40, 8.20), (-25.40, 14.50), (-39.20, 14.50)],
    },
]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing

    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 97,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": layer_index}}
                for element in elements
            ]
        },
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Questo script crea la prima passata di coperture Berra nel modello Archicad.")
        print("Per confermare esegui:")
        print("py 21_tapir_crea_coperture_prima_passata.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    roofs_data = [
        {
            "level": roof["level"],
            "thickness": roof["thickness"],
            "polygonCoordinates": [coord(x, y) for x, y in roof["points"]],
            "eavesOverhang": roof["eavesOverhang"],
            "levels": [{"levelHeight": 0.0, "levelAngle": math.radians(roof["levelAngle"])}],
        }
        for roof in ROOFS
    ]

    create_result = tapir(commands, types, "CreateRoofs", {"roofsData": roofs_data})
    elements = create_result.get("elements", [])
    layer_result = set_elements_layer(commands, types, elements, layer_index)

    result = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "roofs": ROOFS,
        "createResult": create_result,
        "setLayerResult": layer_result,
    }
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Coperture richieste: {len(ROOFS)}")
    print(f"Elementi creati: {len(elements)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
