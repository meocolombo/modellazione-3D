from __future__ import annotations

import json
import sys
from pathlib import Path

from archicad import ACConnection


IN_JSON = Path("berra_coperture_prima_passata_result.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Questo script elimina le coperture della prima passata Berra.")
        print("Per confermare esegui:")
        print("py 22_tapir_elimina_coperture_prima_passata.py APPLICA")
        return

    if not IN_JSON.exists():
        raise SystemExit(f"File non trovato: {IN_JSON}")

    data = json.loads(IN_JSON.read_text(encoding="utf-8"))
    elements = data.get("createResult", {}).get("elements", [])
    if not elements:
        raise SystemExit("Nessuna copertura trovata nel JSON.")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    result = tapir(conn.commands, conn.types, "DeleteElements", {"elements": elements})
    print(f"Coperture richieste in eliminazione: {len(elements)}")
    print(f"Risultato: {result}")


if __name__ == "__main__":
    main()
