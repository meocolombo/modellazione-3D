from __future__ import annotations

import csv
from pathlib import Path


OUT_CSV = Path("berra_coperture_input.csv")


ROWS = [
    {
        "nome": "corpo_strada_demo",
        "attivo": "NO",
        "level": "6.30",
        "thickness": "0.18",
        "eavesOverhang": "0.35",
        "levelHeight": "0.00",
        "levelAngle": "30.00",
        "polygonCoordinates": "0,0 | 36,0 | 36,9 | 0,9",
        "note": "Esempio: sostituire con coordinate reali del corpo su via Berra",
    },
    {
        "nome": "ala_sinistra_demo",
        "attivo": "NO",
        "level": "6.30",
        "thickness": "0.18",
        "eavesOverhang": "0.35",
        "levelHeight": "0.00",
        "levelAngle": "30.00",
        "polygonCoordinates": "0,9 | 8,9 | 8,45 | 0,45",
        "note": "Esempio: ala lunga laterale",
    },
    {
        "nome": "corpo_basso_posteriore_demo",
        "attivo": "NO",
        "level": "3.30",
        "thickness": "0.16",
        "eavesOverhang": "0.30",
        "levelHeight": "0.00",
        "levelAngle": "25.00",
        "polygonCoordinates": "8,45 | 34,45 | 34,53 | 8,53",
        "note": "Esempio: corpo basso posteriore",
    },
]


def main():
    if OUT_CSV.exists():
        print(f"Il file esiste gia: {OUT_CSV}")
        print("Non lo sovrascrivo per non perdere eventuali modifiche.")
        return

    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "nome",
                "attivo",
                "level",
                "thickness",
                "eavesOverhang",
                "levelHeight",
                "levelAngle",
                "polygonCoordinates",
                "note",
            ],
            delimiter=";",
        )
        writer.writeheader()
        writer.writerows(ROWS)

    print(f"Creato: {OUT_CSV}")
    print("Compila polygonCoordinates e metti attivo=SI sulle coperture da creare.")


if __name__ == "__main__":
    main()
