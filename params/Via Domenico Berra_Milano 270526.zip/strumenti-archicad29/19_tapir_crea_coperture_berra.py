from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

from archicad import ACConnection


IN_CSV = Path("berra_coperture_input.csv")
OUT_JSON = Path("berra_coperture_create_result.json")
LAYER_NAME = "BERRA_AI_COPERTURE"


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def norm(text):
    return (text or "").strip().casefold()


def number(text):
    return float(str(text).strip().replace(",", "."))


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def parse_polygon(text):
    points = []
    for part in str(text).split("|"):
        part = part.strip()
        if not part:
            continue
        x_text, y_text = [item.strip() for item in part.split(",", 1)]
        points.append(coord(number(x_text), number(y_text)))
    if len(points) < 3:
        raise ValueError(f"Servono almeno 3 punti: {text!r}")
    return points


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if norm(layer.get("name")) == norm(layer_name):
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing

    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 96,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": layer_index}}
                for element in elements
            ]
        },
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Questo script crea coperture nel modello Archicad.")
        print("Per confermare esegui:")
        print("py 19_tapir_crea_coperture_berra.py APPLICA")
        return

    if not IN_CSV.exists():
        raise SystemExit(f"File non trovato: {IN_CSV}. Esegui prima 18_crea_template_coperture_berra.py")

    roofs_data = []
    active_names = []
    with IN_CSV.open("r", newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            if norm(row.get("attivo")) not in {"si", "sì", "yes", "true", "1"}:
                continue

            active_names.append(row.get("nome", ""))
            roofs_data.append(
                {
                    "level": number(row.get("level")),
                    "thickness": number(row.get("thickness") or "0.18"),
                    "polygonCoordinates": parse_polygon(row.get("polygonCoordinates", "")),
                    "eavesOverhang": number(row.get("eavesOverhang") or "0.0"),
                    "levels": [
                        {
                            "levelHeight": number(row.get("levelHeight") or "0.0"),
                            "levelAngle": number(row.get("levelAngle") or "30.0"),
                        }
                    ],
                }
            )

    if not roofs_data:
        raise SystemExit("Nessuna copertura attiva. Nel CSV imposta attivo=SI sulle righe da creare.")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    create_result = tapir(commands, types, "CreateRoofs", {"roofsData": roofs_data})
    elements = create_result.get("elements", [])
    layer_result = set_elements_layer(commands, types, elements, layer_index)

    result = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "activeNames": active_names,
        "createResult": create_result,
        "setLayerResult": layer_result,
    }
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Coperture richieste: {len(roofs_data)}")
    print(f"Elementi creati: {len(elements)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
