@echo off
cd /d "%~dp0"
py 18_crea_template_coperture_berra.py
pause
