@echo off
cd /d "%~dp0"
py 11_crea_template_modifica_proprieta.py
pause
