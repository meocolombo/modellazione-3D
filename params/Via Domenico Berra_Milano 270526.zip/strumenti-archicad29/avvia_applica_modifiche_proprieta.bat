@echo off
cd /d "%~dp0"
py 12_applica_modifiche_proprieta.py APPLICA
pause
