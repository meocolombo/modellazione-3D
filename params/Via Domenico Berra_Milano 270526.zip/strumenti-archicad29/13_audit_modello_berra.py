from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("audit_modello_berra.txt")
OUT_CSV = Path("audit_modello_berra_elementi.csv")


TARGET_PROPERTIES = [
    "General_Type",
    "General_ElementID",
    "General_HomeStoryName",
    "General_Height",
    "General_Width",
    "General_Thickness",
    "General_SurfaceArea",
    "General_NetVolume",
    "General_ElevationToProjectZero",
]


def get_attr(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def guid_of(element):
    element_id = get_attr(element, "elementId")
    return get_attr(element_id, "guid", str(element_id))


def prop_nonlocalized_name(prop_name):
    user_id = get_attr(prop_name, "nonLocalizedName")
    return str(user_id) if user_id else ""


def value_of(item):
    prop_value = get_attr(item, "propertyValue", item)
    value = get_attr(prop_value, "value", None)
    if value is not None:
        return value
    status = get_attr(prop_value, "status", "")
    if status:
        return status
    return ""


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    acc = conn.commands
    product = acc.GetProductInfo()
    elements = acc.GetAllElements()
    if not elements:
        raise SystemExit("Nessun elemento letto dal modello.")

    all_property_names = acc.GetAllPropertyNames()
    wanted_names = [p for p in all_property_names if prop_nonlocalized_name(p) in TARGET_PROPERTIES]
    wanted_ids = acc.GetPropertyIds(wanted_names)
    values_by_element = acc.GetPropertyValuesOfElements(elements, wanted_ids)

    rows = []
    for element, wrapper in zip(elements, values_by_element):
        values = get_attr(wrapper, "propertyValues", [])
        row = {"guid": guid_of(element)}
        for prop_name, item in zip(wanted_names, values):
            row[prop_nonlocalized_name(prop_name)] = value_of(item)
        rows.append(row)

    type_counter = Counter(str(row.get("General_Type", "") or "Non rilevato") for row in rows)
    story_counter = Counter(str(row.get("General_HomeStoryName", "") or "Non rilevato") for row in rows)

    fieldnames = ["guid"] + TARGET_PROPERTIES
    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    with OUT_TXT.open("w", encoding="utf-8") as handle:
        handle.write("AUDIT MODELLO BERRA - ARCHICAD\n")
        handle.write("=" * 36 + "\n\n")
        handle.write(f"Prodotto: {product}\n")
        handle.write(f"Elementi letti: {len(elements)}\n\n")
        handle.write("Elementi per tipo:\n")
        for key, count in type_counter.most_common():
            handle.write(f"- {key}: {count}\n")
        handle.write("\nElementi per piano:\n")
        for key, count in story_counter.most_common():
            handle.write(f"- {key}: {count}\n")
        handle.write("\nPrime righe elemento:\n")
        for row in rows[:30]:
            handle.write(
                f"- {row.get('General_Type', '')} | {row.get('General_ElementID', '')} | "
                f"piano {row.get('General_HomeStoryName', '')} | guid {row['guid']}\n"
            )

    print("Creati:")
    print(f"- {OUT_TXT}")
    print(f"- {OUT_CSV}")
    print(f"Elementi letti: {len(elements)}")


if __name__ == "__main__":
    main()
