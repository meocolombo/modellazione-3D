from archicad import ACConnection


KEYWORDS = (
    "Element",
    "Property",
    "Classification",
    "Attribute",
    "Layer",
    "Zone",
    "Wall",
    "Story",
    "Selected",
)


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands
    command_names = [name for name in dir(acc) if not name.startswith("_")]
    filtered = [
        name
        for name in command_names
        if any(keyword.lower() in name.lower() for keyword in KEYWORDS)
    ]

    print(f"Comandi totali disponibili: {len(command_names)}")
    print(f"Comandi filtrati utili: {len(filtered)}")
    print()

    for name in sorted(filtered):
        print(name)

    with open("archicad29_comandi_api.txt", "w", encoding="utf-8") as report:
        report.write("Comandi Archicad API disponibili\n")
        report.write("================================\n\n")
        for name in sorted(command_names):
            report.write(f"{name}\n")

    print()
    print("Report completo salvato in archicad29_comandi_api.txt")


if __name__ == "__main__":
    main()
