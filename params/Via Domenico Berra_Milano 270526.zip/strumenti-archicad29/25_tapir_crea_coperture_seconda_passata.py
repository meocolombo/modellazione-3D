from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_coperture_seconda_passata_result.json")
LAYER_NAME = "BERRA_AI_COPERTURE_02"


ROOFS = [
    {
        "nome": "corpo_lungo_ovest",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 28.0,
        "points": [(-50.80, -72.40), (-41.10, -72.40), (-41.10, 33.10), (-50.80, 33.10)],
    },
    {
        "nome": "corpo_nord_centrale",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-34.60, 13.00), (-22.10, 13.00), (-22.10, 33.00), (-34.60, 33.00)],
    },
    {
        "nome": "corpo_nord_est",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 30.0,
        "points": [(-23.40, 7.80), (-9.00, 7.80), (-9.00, 14.50), (-23.40, 14.50)],
    },
    {
        "nome": "corpo_est_corto",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 28.0,
        "points": [(-10.20, -13.80), (-7.70, -13.80), (-7.70, 14.60), (-10.20, 14.60)],
    },
    {
        "nome": "corpo_ovest_corte",
        "level": 6.30,
        "thickness": 0.18,
        "eavesOverhang": 0.35,
        "levelAngle": 28.0,
        "points": [(-39.40, -8.20), (-35.70, -8.20), (-35.70, 6.30), (-39.40, 6.30)],
    },
    {
        "nome": "corpo_basso_sud_ovest",
        "level": 3.30,
        "thickness": 0.16,
        "eavesOverhang": 0.30,
        "levelAngle": 24.0,
        "points": [(-41.60, -63.80), (-17.00, -63.80), (-17.00, -21.00), (-41.60, -21.00)],
    },
]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {"name": LAYER_NAME, "isHidden": False, "isLocked": False, "isWireframe": False, "intersectionGroupNr": 99}
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {"elementsWithDetails": [{"elementId": e["elementId"], "details": {"layerIndex": layer_index}} for e in elements]},
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Questo script crea la seconda passata di coperture Berra.")
        print("Uso: py 25_tapir_crea_coperture_seconda_passata.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    try:
        tapir(commands, types, "ApplyFavoritesToElementDefaults", {"favorites": ["Falda Spiovente - Tegole"]})
    except Exception:
        pass

    roofs_data = [
        {
            "level": roof["level"],
            "thickness": roof["thickness"],
            "polygonCoordinates": [coord(x, y) for x, y in roof["points"]],
            "eavesOverhang": roof["eavesOverhang"],
            "levels": [{"levelHeight": 0.0, "levelAngle": math.radians(roof["levelAngle"])}],
        }
        for roof in ROOFS
    ]

    create_result = tapir(commands, types, "CreateRoofs", {"roofsData": roofs_data})
    elements = create_result.get("elements", [])
    layer_result = set_elements_layer(commands, types, elements, layer_index)

    result = {"layer": {"name": LAYER_NAME, "index": layer_index}, "roofs": ROOFS, "createResult": create_result, "setLayerResult": layer_result}
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Coperture richieste: {len(ROOFS)}")
    print(f"Elementi creati: {len(elements)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
