from __future__ import annotations

import json
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("tapir_pilota_elementi_creati.json")
TEST_LAYER_NAME = "BERRA_AI_TEST"


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_test_layer(commands, types):
    existing = find_layer_index(commands, types, TEST_LAYER_NAME)
    if existing is not None:
        return existing

    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {
                    "name": TEST_LAYER_NAME,
                    "isHidden": False,
                    "isLocked": False,
                    "isWireframe": False,
                    "intersectionGroupNr": 95,
                }
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, TEST_LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {TEST_LAYER_NAME}")
    return created


def element_id_list(response):
    return response.get("elements", [])


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {
            "elementsWithDetails": [
                {"elementId": element["elementId"], "details": {"layerIndex": layer_index}}
                for element in elements
            ]
        },
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Questo script modifica il modello creando geometria di prova.")
        print("Per confermare esegui:")
        print("py 16_tapir_pilota_geometria.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_test_layer(commands, types)

    # Rettangolo pilota lontano dal rilievo: 10 x 8 m, quota 0, muri 3 m.
    # Se interferisce con il modello, spostarlo modificando base_x/base_y.
    base_x = 200.0
    base_y = 200.0
    p1 = coord(base_x, base_y)
    p2 = coord(base_x + 10.0, base_y)
    p3 = coord(base_x + 10.0, base_y + 8.0)
    p4 = coord(base_x, base_y + 8.0)

    walls_payload = {
        "wallsData": [
            {"begCoordinate": p1, "endCoordinate": p2, "zCoordinate": 0.0, "height": 3.0, "thickness": 0.30},
            {"begCoordinate": p2, "endCoordinate": p3, "zCoordinate": 0.0, "height": 3.0, "thickness": 0.30},
            {"begCoordinate": p3, "endCoordinate": p4, "zCoordinate": 0.0, "height": 3.0, "thickness": 0.30},
            {"begCoordinate": p4, "endCoordinate": p1, "zCoordinate": 0.0, "height": 3.0, "thickness": 0.30},
        ]
    }
    slab_payload = {
        "slabsData": [
            {
                "level": 0.0,
                "thickness": 0.25,
                "polygonCoordinates": [p1, p2, p3, p4],
            }
        ]
    }
    roof_payload = {
        "roofsData": [
            {
                "level": 3.0,
                "thickness": 0.18,
                "polygonCoordinates": [p1, p2, p3, p4],
                "eavesOverhang": 0.35,
                "levels": [{"levelHeight": 0.0, "levelAngle": 30.0}],
            }
        ]
    }

    walls = tapir(commands, types, "CreateWalls", walls_payload)
    slabs = tapir(commands, types, "CreateSlabs", slab_payload)
    roofs = tapir(commands, types, "CreateRoofs", roof_payload)

    created_elements = element_id_list(walls) + element_id_list(slabs) + element_id_list(roofs)
    layer_result = set_elements_layer(commands, types, created_elements, layer_index)

    result = {
        "layer": {"name": TEST_LAYER_NAME, "index": layer_index},
        "walls": walls,
        "slabs": slabs,
        "roofs": roofs,
        "setLayerResult": layer_result,
    }
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Creati elementi pilota: {len(created_elements)}")
    print(f"Layer: {TEST_LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
