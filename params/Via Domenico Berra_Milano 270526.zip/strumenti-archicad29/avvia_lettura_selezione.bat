@echo off
cd /d "%~dp0"
python 02_leggi_selezione.py
pause
