@echo off
cd /d "%~dp0"
py 16_tapir_pilota_geometria.py APPLICA
pause
