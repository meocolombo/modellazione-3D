@echo off
cd /d "%~dp0"
py 19_tapir_crea_coperture_berra.py APPLICA
pause
