@echo off
cd /d "%~dp0"
py 08_report_proprieta_selezione.py
pause
