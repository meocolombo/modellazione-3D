@echo off
cd /d "%~dp0"
py 06_diagnosi_modello.py
pause
