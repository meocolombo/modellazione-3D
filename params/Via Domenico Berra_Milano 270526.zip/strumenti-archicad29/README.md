# Strumenti Archicad 29 per MC_A

Kit iniziale per collegare Archicad 29 a script Python tramite Archicad JSON Interface.

## Requisiti

- Archicad 29 installato e aperto.
- Un file PLN aperto in Archicad.
- Python 3 installato su Windows.
- Connessione Python/JSON attiva in Archicad.

## Installazione

Aprire PowerShell in questa cartella ed eseguire:

```powershell
python -m pip install -r requirements.txt
```

## Primo test

Con Archicad 29 aperto:

```powershell
python .\01_test_connessione.py
```

Se la connessione funziona, lo script stampa informazioni base del prodotto.

## Lettura selezione

Selezionare alcuni elementi in Archicad e poi eseguire:

```powershell
python .\02_leggi_selezione.py
```

Lo script prova a leggere gli elementi selezionati e produce un piccolo report testuale.

## Obiettivo

Partire in sicurezza, solo lettura:

- verifica connessione;
- lettura elementi selezionati;
- report di controllo;
- esportazione dati per relazioni, capitolati, computi e liste elaborati.

Le funzioni di modifica del modello andranno aggiunte solo dopo conferma, una alla volta.
