from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_capriate_arcarecci_result.json")
LAYER_NAME = "BERRA_AI_CAPRIATE_01"


# Rettangoli coerenti con le coperture generate. Le travi sono semplificate:
# colmo centrale, due arcarecci laterali e catene trasversali a passo regolare.
ROOF_BLOCKS = [
    ("ala_sud_est", -20.40, -8.20, -72.30, -38.30, 6.30, 30.0),
    ("ala_sud_ovest", -40.00, -17.00, -63.70, -20.70, 6.30, 30.0),
    ("corpo_centrale_ovest", -48.80, -43.50, -33.80, -6.60, 6.30, 30.0),
    ("corpo_centrale_sud", -47.80, -8.00, -17.00, -6.60, 6.30, 30.0),
    ("corpo_centrale_est", -16.90, -7.70, -39.60, 14.40, 6.30, 30.0),
    ("corpo_nord_ovest", -39.20, -25.40, 8.20, 14.50, 6.30, 30.0),
    ("corpo_lungo_ovest", -50.80, -41.10, -72.40, 33.10, 6.30, 28.0),
    ("corpo_nord_centrale", -34.60, -22.10, 13.00, 33.00, 6.30, 30.0),
    ("corpo_nord_est", -23.40, -9.00, 7.80, 14.50, 6.30, 30.0),
    ("corpo_est_corto", -10.20, -7.70, -13.80, 14.60, 6.30, 28.0),
    ("corpo_ovest_corte", -39.40, -35.70, -8.20, 6.30, 6.30, 28.0),
    ("corpo_basso_sud_ovest", -41.60, -17.00, -63.80, -21.00, 3.30, 24.0),
]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {"name": LAYER_NAME, "isHidden": False, "isLocked": False, "isWireframe": False, "intersectionGroupNr": 100}
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {"elementsWithDetails": [{"elementId": e["elementId"], "details": {"layerIndex": layer_index}} for e in elements]},
    )


def add_beam(beams, x1, y1, x2, y2, z, width=0.16, height=0.16):
    beams.append(
        {
            "begCoordinate": coord(x1, y1),
            "endCoordinate": coord(x2, y2),
            "zCoordinate": float(z),
            "width": width,
            "height": height,
        }
    )


def build_beams():
    beams = []
    for _name, x1, x2, y1, y2, level, angle_deg in ROOF_BLOCKS:
        width_x = abs(x2 - x1)
        width_y = abs(y2 - y1)
        ridge_raise = min(width_x, width_y) * 0.5 * math.tan(math.radians(angle_deg))
        ridge_z = level + 0.25 + ridge_raise
        eave_z = level + 0.20

        if width_y >= width_x:
            xm = (x1 + x2) / 2.0
            add_beam(beams, xm, y1, xm, y2, ridge_z, 0.18, 0.18)
            add_beam(beams, x1 + 0.35, y1, x1 + 0.35, y2, eave_z, 0.12, 0.12)
            add_beam(beams, x2 - 0.35, y1, x2 - 0.35, y2, eave_z, 0.12, 0.12)
            step = 5.0
            count = max(2, int(width_y // step))
            for i in range(count + 1):
                y = y1 + width_y * i / count
                add_beam(beams, x1 + 0.25, y, x2 - 0.25, y, eave_z, 0.14, 0.14)
        else:
            ym = (y1 + y2) / 2.0
            add_beam(beams, x1, ym, x2, ym, ridge_z, 0.18, 0.18)
            add_beam(beams, x1, y1 + 0.35, x2, y1 + 0.35, eave_z, 0.12, 0.12)
            add_beam(beams, x1, y2 - 0.35, x2, y2 - 0.35, eave_z, 0.12, 0.12)
            step = 5.0
            count = max(2, int(width_x // step))
            for i in range(count + 1):
                x = x1 + width_x * i / count
                add_beam(beams, x, y1 + 0.25, x, y2 - 0.25, eave_z, 0.14, 0.14)
    return beams


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Crea capriate/arcarecci semplificati per le coperture Berra.")
        print("Uso: py 26_tapir_crea_capriate_arcarecci.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    try:
        tapir(commands, types, "ApplyFavoritesToElementDefaults", {"favorites": ["Trave generica"]})
    except Exception:
        pass

    beams_data = build_beams()
    result = tapir(commands, types, "CreateBeams", {"beamsData": beams_data})
    elements = result.get("elements", [])
    layer_result = set_elements_layer(commands, types, elements, layer_index)

    output = {"layer": {"name": LAYER_NAME, "index": layer_index}, "beamCount": len(beams_data), "createResult": result, "setLayerResult": layer_result}
    OUT_JSON.write_text(json.dumps(output, indent=2), encoding="utf-8")

    print(f"Travi/capriate richieste: {len(beams_data)}")
    print(f"Elementi creati: {len(elements)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
