from archicad import ACConnection


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands

    try:
        elements = acc.GetAllElements()
    except Exception as exc:
        print("Non riesco a leggere gli elementi del modello.")
        print(f"Dettaglio: {exc}")
        return

    print(f"Elementi letti dal modello: {len(elements)}")
    print("Primi 20 elementi:")
    for index, element in enumerate(elements[:20], start=1):
        print(f"{index}. {element}")


if __name__ == "__main__":
    main()
