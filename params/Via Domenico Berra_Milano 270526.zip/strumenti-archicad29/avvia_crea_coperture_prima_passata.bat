@echo off
cd /d "%~dp0"
py 21_tapir_crea_coperture_prima_passata.py APPLICA
pause
