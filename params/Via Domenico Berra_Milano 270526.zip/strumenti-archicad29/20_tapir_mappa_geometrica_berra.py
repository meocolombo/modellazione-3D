from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("berra_mappa_geometrica.txt")
OUT_CSV = Path("berra_mappa_geometrica.csv")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def layer_names(commands, types):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    return {int(item["index"]): item["name"] for item in result.get("attributes", [])}


def bbox_value(item):
    return item.get("boundingBox3D", {})


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    commands = conn.commands
    types = conn.types
    layers = layer_names(commands, types)

    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    boxes = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}).get("boundingBoxes3D", [])

    rows = []
    for element, detail, box_item in zip(elements, details, boxes):
        element_id = element.get("elementId", {})
        box = bbox_value(box_item)
        layer_index = detail.get("layerIndex", "")
        row = {
            "guid": element_id.get("guid", ""),
            "type": detail.get("type", ""),
            "id": detail.get("id", ""),
            "floorIndex": detail.get("floorIndex", ""),
            "layerIndex": layer_index,
            "layerName": layers.get(int(layer_index), "") if str(layer_index).strip() else "",
            "xMin": box.get("xMin", ""),
            "xMax": box.get("xMax", ""),
            "yMin": box.get("yMin", ""),
            "yMax": box.get("yMax", ""),
            "zMin": box.get("zMin", ""),
            "zMax": box.get("zMax", ""),
        }
        type_details = detail.get("details", {})
        if "begCoordinate" in type_details:
            row["begX"] = type_details["begCoordinate"].get("x", "")
            row["begY"] = type_details["begCoordinate"].get("y", "")
        else:
            row["begX"] = ""
            row["begY"] = ""
        if "endCoordinate" in type_details:
            row["endX"] = type_details["endCoordinate"].get("x", "")
            row["endY"] = type_details["endCoordinate"].get("y", "")
        else:
            row["endX"] = ""
            row["endY"] = ""
        row["height"] = type_details.get("height", "")
        row["thickness"] = type_details.get("thickness", "")
        rows.append(row)

    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        fieldnames = [
            "guid", "type", "id", "floorIndex", "layerIndex", "layerName",
            "xMin", "xMax", "yMin", "yMax", "zMin", "zMax",
            "begX", "begY", "endX", "endY", "height", "thickness",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    by_type = Counter(row["type"] for row in rows)
    by_layer = Counter(row["layerName"] or f"layer {row['layerIndex']}" for row in rows)
    extents_by_type = defaultdict(lambda: [1e9, -1e9, 1e9, -1e9, 1e9, -1e9])
    for row in rows:
        if row["xMin"] == "":
            continue
        ext = extents_by_type[row["type"]]
        ext[0] = min(ext[0], float(row["xMin"]))
        ext[1] = max(ext[1], float(row["xMax"]))
        ext[2] = min(ext[2], float(row["yMin"]))
        ext[3] = max(ext[3], float(row["yMax"]))
        ext[4] = min(ext[4], float(row["zMin"]))
        ext[5] = max(ext[5], float(row["zMax"]))

    with OUT_TXT.open("w", encoding="utf-8") as handle:
        handle.write("BERRA - MAPPA GEOMETRICA TAPIR\n")
        handle.write("=" * 34 + "\n\n")
        handle.write(f"Elementi letti: {len(rows)}\n\n")
        handle.write("Elementi per tipo:\n")
        for item, count in by_type.most_common():
            handle.write(f"- {item}: {count}\n")
        handle.write("\nLayer principali:\n")
        for item, count in by_layer.most_common(20):
            handle.write(f"- {item}: {count}\n")
        handle.write("\nEstensioni per tipo:\n")
        for item, ext in sorted(extents_by_type.items()):
            handle.write(
                f"- {item}: X {ext[0]:.2f}..{ext[1]:.2f}, "
                f"Y {ext[2]:.2f}..{ext[3]:.2f}, Z {ext[4]:.2f}..{ext[5]:.2f}\n"
            )

    print("Creati:")
    print(f"- {OUT_TXT}")
    print(f"- {OUT_CSV}")
    print(f"Elementi letti: {len(rows)}")


if __name__ == "__main__":
    main()
