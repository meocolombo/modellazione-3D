from __future__ import annotations

import json
import sys
from pathlib import Path

from archicad import ACConnection


IN_JSON = Path("tapir_pilota_elementi_creati.json")


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Questo script elimina gli elementi pilota creati dal test Tapir.")
        print("Per confermare esegui:")
        print("py 17_tapir_elimina_pilota.py APPLICA")
        return

    if not IN_JSON.exists():
        raise SystemExit(f"File non trovato: {IN_JSON}")

    data = json.loads(IN_JSON.read_text(encoding="utf-8"))
    elements = []
    for section in ("walls", "slabs", "roofs"):
        elements.extend(data.get(section, {}).get("elements", []))

    if not elements:
        raise SystemExit("Nessun elemento pilota trovato nel JSON.")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    result = tapir(conn.commands, conn.types, "DeleteElements", {"elements": elements})
    print(f"Elementi richiesti in eliminazione: {len(elements)}")
    print(f"Risultato: {result}")


if __name__ == "__main__":
    main()
