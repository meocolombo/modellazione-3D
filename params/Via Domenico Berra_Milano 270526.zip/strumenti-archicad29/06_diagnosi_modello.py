from archicad import ACConnection
import csv


def call(acc, name, *args):
    if not hasattr(acc, name):
        return None, f"Comando non disponibile: {name}"
    try:
        return getattr(acc, name)(*args), None
    except Exception as exc:
        return None, str(exc)


def get_guid(item):
    element_id = getattr(item, "elementId", None)
    if element_id is not None:
        guid = getattr(element_id, "guid", None)
        if guid:
            return guid

    if isinstance(item, dict):
        return item.get("elementId", {}).get("guid", "")

    return str(item)


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands

    product_info, err = call(acc, "GetProductInfo")
    all_elements, err_all = call(acc, "GetAllElements")
    selected_elements, err_sel = call(acc, "GetSelectedElements")

    commands = [name for name in dir(acc) if not name.startswith("_")]
    useful_commands = [
        name for name in commands
        if any(token in name.lower() for token in (
            "element", "property", "classification", "attribute", "layer", "story", "zone", "type"
        ))
    ]

    lines = []
    lines.append("Diagnosi modello Archicad")
    lines.append("========================")
    lines.append("")
    lines.append(f"Product info: {product_info if err is None else 'Errore: ' + err}")
    lines.append(f"Elementi totali letti: {len(all_elements) if all_elements is not None else 'Errore: ' + err_all}")
    lines.append(f"Elementi selezionati: {len(selected_elements) if selected_elements is not None else 'Errore: ' + err_sel}")
    lines.append(f"Comandi API disponibili: {len(commands)}")
    lines.append(f"Comandi API utili filtrati: {len(useful_commands)}")
    lines.append("")
    lines.append("Comandi utili disponibili:")
    for name in sorted(useful_commands):
        lines.append(f"- {name}")

    if all_elements:
        sample = all_elements[:20]
        lines.append("")
        lines.append("Primi 20 GUID:")
        for i, item in enumerate(sample, start=1):
            lines.append(f"{i}. {get_guid(item)}")

        with open("diagnosi_modello_elementi.csv", "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=["numero", "guid"])
            writer.writeheader()
            for i, item in enumerate(all_elements, start=1):
                writer.writerow({"numero": i, "guid": get_guid(item)})

    with open("diagnosi_modello_archicad.txt", "w", encoding="utf-8") as report:
        report.write("\n".join(lines))

    print("\n".join(lines[:12]))
    print("")
    print("Creati:")
    print("- diagnosi_modello_archicad.txt")
    if all_elements:
        print("- diagnosi_modello_elementi.csv")


if __name__ == "__main__":
    main()
