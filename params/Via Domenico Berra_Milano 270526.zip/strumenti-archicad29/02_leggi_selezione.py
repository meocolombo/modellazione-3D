from archicad import ACConnection


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        print("Apri Archicad 29 e riprova.")
        return

    acc = conn.commands
    print("Connessione Archicad riuscita.")

    try:
        selection = acc.GetSelectedElements()
    except Exception as exc:
        print("Non riesco a leggere la selezione.")
        print(f"Dettaglio: {exc}")
        return

    if not selection:
        print("Nessun elemento selezionato in Archicad.")
        return

    print(f"Elementi selezionati: {len(selection)}")
    for index, element in enumerate(selection, start=1):
        print(f"{index}. {element}")


if __name__ == "__main__":
    main()
