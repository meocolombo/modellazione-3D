# BERRA 10 - Fase 01 Coperture e Volumi Principali

## Obiettivo

Portare il modello Archicad del complesso di Via Domenico Berra 10 a una lettura coerente con le viste aeree e con la tavola tetto/capriate:

- complesso a corti interne;
- corpi edilizi continui lungo via Domenico Berra;
- corpi bassi laterali e posteriori;
- coperture in laterizio a falde;
- loggiati/portici riconoscibili sulla corte;
- camini, abbaini e lucernari principali.

## Base di lavoro

File consigliato:

`Z:\268_Via Berra Milano\3d e piante via berra\268_BERRA_10_270526_01.pln`

Backup presente:

`Z:\268_Via Berra Milano\3d e piante via berra\268_BERRA_10_BACKUP_PRIMA_AI.pln`

Materiali di riferimento:

- `costruzione tetto\TETTO E CAPRIATE BERRA.jpg`
- `costruzione tetto\TETTO_01.jpg`
- `costruzione tetto\TETTO_02.jpg`
- `costruzione tetto\TETTO_03.pdf`
- immagini aeree Google fornite;
- foto sopralluogo in `foto sopralluogo 170625`;
- materiali Lumion in `MATERIALI_LUMION_BERRA`.

## Stato rilevato dal modello aperto

Audit del modello:

- elementi totali: 318;
- muri: 171;
- solai: 35;
- finestre: 23;
- porte: 4;
- oggetti: 66;
- forme: 18;
- falde: 1.

La presenza di una sola falda indica che la copertura e la volumetria superiore sono la priorita.

## Sequenza consigliata

### 1. Organizzazione preliminare

- Salvare una copia di lavoro con data: `268_BERRA_10_060626_FASE01_COPERTURE.pln`.
- Creare o verificare i layer:
  - `BERRA_Rilievo_Muri`
  - `BERRA_Rilievo_Tetti`
  - `BERRA_Rilievo_Loggiati`
  - `BERRA_Rilievo_Serramenti`
  - `BERRA_Rilievo_Esterni`
  - `BERRA_Riferimenti_2D`
- Inserire la tavola tetto come riferimento 2D su un piano dedicato.

### 2. Perimetro e corti

- Verificare il perimetro principale lungo via Domenico Berra.
- Controllare le due corti interne:
  - corte principale centrale;
  - corte/giardino piu ampia verso il retro.
- Separare i corpi edilizi in blocchi logici, anche se restano contigui:
  - corpo su strada;
  - ala sinistra;
  - ala destra;
  - corpo trasversale centrale;
  - corpo basso posteriore;
  - corpi minori laterali.

### 3. Coperture

Modellare prima le grandi falde, poi gli elementi secondari.

Priorita:

- falda principale sul corpo strada;
- falde dei lati lunghi delle corti;
- coperture dei corpi bassi laterali;
- raccordi a padiglione sugli angoli;
- colmi e compluvi evidenti dalla tavola;
- sporti di gronda coerenti;
- abbaini e lucernari principali;
- camini visibili nelle viste aeree.

Controlli:

- nessuna copertura piana dove dalle viste risulta tetto in coppi;
- colmi orientati secondo la tavola;
- le corti devono rimanere aperte;
- le falde non devono invadere loggiati e portici;
- evitare un'unica copertura continua se nella tavola sono presenti corpi distinti.

### 4. Portici e loggiati

Dopo le coperture:

- modellare il loggiato principale affacciato sulla corte;
- distinguere pieni, archi e pilastri;
- usare aperture/archi semplificati ma regolari;
- verificare proporzione con le foto di facciata.

### 5. Facciate

Completare solo dopo aver stabilizzato volumi e tetti:

- serramenti ritmati sui prospetti;
- aperture ad arco e nicchie decorative sul corpo storico;
- cornici chiare intorno alle aperture principali;
- texture muratura storica e intonaco;
- basamenti e recinzioni su strada.

### 6. Esterni

Ultima fase:

- corti verdi;
- alberature principali;
- vialetti interni;
- recinzioni e cancelli;
- contesto urbano essenziale.

## Criterio di completamento Fase 01

La fase 01 e completa quando:

- il modello mostra tutte le coperture principali;
- le due corti risultano leggibili;
- i corpi edilizi sono separabili visivamente;
- il numero di falde nel modello e coerente con la tavola;
- la vista 3D generale ricorda chiaramente le immagini aeree fornite.

## Verifica da eseguire

Dopo la modellazione, lanciare:

`py 13_audit_modello_berra.py`

Obiettivo minimo atteso:

- aumento significativo delle falde rispetto al valore attuale `1`;
- nessuna perdita di muri, solai, finestre gia presenti;
- eventuali nuovi elementi riconoscibili per ID/layer.
