from __future__ import annotations

import csv
import sys
from pathlib import Path

from archicad import ACConnection


IN_CSV = Path("modifiche_proprieta.csv")


def get_attr(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def localized_parts(prop_name):
    user_id = get_attr(prop_name, "localizedName")
    if not user_id:
        return None
    if len(user_id) >= 2:
        return str(user_id[0]), str(user_id[1])
    if len(user_id) == 1:
        return "", str(user_id[0])
    return None


def normalize(text):
    return (text or "").strip().casefold()


def parse_bool(value):
    text = normalize(value)
    if text in {"si", "sì", "yes", "true", "1", "vero"}:
        return True
    if text in {"no", "false", "0", "falso"}:
        return False
    raise ValueError(f"Valore booleano non riconosciuto: {value!r}")


def make_property_value(types, value_type, raw_value):
    value_type = normalize(value_type)
    raw_value = (raw_value or "").strip()

    if value_type == "string":
        return types.NormalStringPropertyValue(raw_value)
    if value_type == "number":
        return types.NormalNumberPropertyValue(float(raw_value.replace(",", ".")))
    if value_type == "integer":
        return types.NormalIntegerPropertyValue(int(raw_value))
    if value_type == "boolean":
        return types.NormalBooleanPropertyValue(parse_bool(raw_value))
    if value_type == "length":
        return types.NormalLengthPropertyValue(float(raw_value.replace(",", ".")))

    raise ValueError(f"Tipo non gestito automaticamente: {value_type!r}")


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        raise SystemExit(
            "Questo script modifica il modello. Per confermare esegui:\n"
            "py 12_applica_modifiche_proprieta.py APPLICA"
        )

    if not IN_CSV.exists():
        raise SystemExit(f"File non trovato: {IN_CSV}. Esegui prima 11_crea_template_modifica_proprieta.py")

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    acc = conn.commands
    types = conn.types
    selected = acc.GetSelectedElements()
    if not selected:
        raise SystemExit("Nessun elemento selezionato.")

    property_names = acc.GetAllPropertyNames()
    property_ids = acc.GetPropertyIds(property_names)
    property_map = {}
    for prop_name, prop_id in zip(property_names, property_ids):
        parts = localized_parts(prop_name)
        if parts:
            property_map[(normalize(parts[0]), normalize(parts[1]))] = prop_id

    changes = []
    with IN_CSV.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            if normalize(row.get("applica")) != "si":
                continue

            key = (normalize(row.get("gruppo")), normalize(row.get("proprieta")))
            prop_id = property_map.get(key)
            if not prop_id:
                print(f"Saltata, proprieta non trovata: {row.get('gruppo')} / {row.get('proprieta')}")
                continue

            prop_value = make_property_value(types, row.get("tipo"), row.get("nuovo_valore"))
            for element in selected:
                changes.append(types.ElementPropertyValue(element.elementId, prop_id, prop_value))

    if not changes:
        raise SystemExit("Nessuna modifica da applicare. Nel CSV imposta applica=SI sulle righe desiderate.")

    results = acc.SetPropertyValuesOfElements(changes)
    ok_count = 0
    for result in results:
        success = get_attr(result, "success", None)
        if success is True or "success" in repr(result).lower():
            ok_count += 1

    print(f"Modifiche richieste: {len(changes)}")
    print(f"Risultati OK apparenti: {ok_count}")
    print("Risultati Archicad:")
    for result in results:
        print(f"- {result}")


if __name__ == "__main__":
    main()
