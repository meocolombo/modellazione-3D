from __future__ import annotations

import math
import sys

from archicad import ACConnection


LAYER_NAME = "BERRA_AI_TEST_ROOF_VALID"


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [{"name": LAYER_NAME, "isHidden": False, "isLocked": False, "intersectionGroupNr": 98}],
            "overwriteExisting": False,
        },
    )
    return find_layer_index(commands, types, LAYER_NAME)


def set_elements_layer(commands, types, elements, layer_index):
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {"elementsWithDetails": [{"elementId": e["elementId"], "details": {"layerIndex": layer_index}} for e in elements]},
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Crea un tetto test con pendenza in radianti.")
        print("Uso: py 24_tapir_test_roof_radians.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    p1 = coord(120, 120)
    p2 = coord(130, 120)
    p3 = coord(130, 128)
    p4 = coord(120, 128)
    result = tapir(
        commands,
        types,
        "CreateRoofs",
        {
            "roofsData": [
                {
                    "level": 3.0,
                    "thickness": 0.18,
                    "polygonCoordinates": [p1, p2, p3, p4],
                    "eavesOverhang": 0.35,
                    "levels": [{"levelHeight": 0.0, "levelAngle": math.radians(30.0)}],
                }
            ]
        },
    )
    elements = result.get("elements", [])
    set_elements_layer(commands, types, elements, layer_index)
    bbox = tapir(commands, types, "Get3DBoundingBoxes", {"elements": elements}) if elements else {}
    print(f"Creati: {len(elements)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"CreateRoofs: {result}")
    print(f"Bounding box: {bbox}")


if __name__ == "__main__":
    main()
