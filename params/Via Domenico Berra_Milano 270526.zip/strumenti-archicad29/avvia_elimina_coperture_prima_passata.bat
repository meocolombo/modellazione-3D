@echo off
cd /d "%~dp0"
py 22_tapir_elimina_coperture_prima_passata.py APPLICA
pause
