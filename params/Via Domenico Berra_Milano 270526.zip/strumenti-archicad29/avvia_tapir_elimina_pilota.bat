@echo off
cd /d "%~dp0"
py 17_tapir_elimina_pilota.py APPLICA
pause
