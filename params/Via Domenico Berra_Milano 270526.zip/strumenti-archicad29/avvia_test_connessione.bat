@echo off
cd /d "%~dp0"
python 01_test_connessione.py
pause
