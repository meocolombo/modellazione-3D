@echo off
cd /d "%~dp0"
py 15_tapir_contesto_berra.py
pause
