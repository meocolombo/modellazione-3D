@echo off
cd /d "%~dp0"
py 05_report_selezione_base.py
pause
