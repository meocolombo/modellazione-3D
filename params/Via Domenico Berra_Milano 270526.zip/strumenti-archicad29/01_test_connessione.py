from archicad import ACConnection


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        print("Apri Archicad 29, verifica che il file PLN sia aperto e che la connessione Python/JSON sia attiva.")
        return

    acc = conn.commands
    print("Connessione Archicad riuscita.")

    try:
        product_info = acc.GetProductInfo()
        print("Informazioni prodotto:")
        print(product_info)
    except Exception as exc:
        print("Connessione attiva, ma GetProductInfo non ha risposto come previsto.")
        print(f"Dettaglio: {exc}")


if __name__ == "__main__":
    main()
