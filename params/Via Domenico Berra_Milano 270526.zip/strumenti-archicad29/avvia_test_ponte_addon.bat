@echo off
cd /d "%~dp0"
py 14_test_ponte_addon.py
pause
