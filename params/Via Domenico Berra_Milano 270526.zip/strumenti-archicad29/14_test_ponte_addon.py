from __future__ import annotations

from archicad import ACConnection


COMMANDS_TO_TEST = [
    ("TapirCommand", "GetAddOnVersion"),
    ("TapirCommand", "CreateWalls"),
    ("TapirCommand", "CreateRoofs"),
    ("TapirCommand", "CreateWindows"),
    ("TapirCommand", "CreateDoors"),
    ("TapirCommand", "CreateBeams"),
    ("TapirCommand", "CreateSlabs"),
    ("TapirCommand", "CreateMorphs"),
    ("TapirCommand", "CreateObjects"),
    ("TapirCommand", "CreateColumns"),
    ("TapirCommand", "CreateMeshes"),
    ("TapirCommand", "ModifyWalls"),
    ("TapirCommand", "ModifyRoofs"),
    ("TapirCommand", "ModifySlabs"),
    ("TapirCommand", "MoveElements"),
    ("AdditionalJSONCommands", "GetAddOnVersion"),
    ("AdditionalJSONCommands", "CreateObjects"),
]


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    acc = conn.commands
    act = conn.types

    print("Test ponte/add-on Archicad")
    print("=" * 34)
    print(f"Prodotto: {acc.GetProductInfo()}")
    print()

    for namespace, command in COMMANDS_TO_TEST:
        command_id = act.AddOnCommandId(namespace, command)
        try:
            available = acc.IsAddOnCommandAvailable(command_id)
            print(f"{namespace}.{command}: {'OK' if available else 'NO'}")
        except Exception as exc:
            print(f"{namespace}.{command}: ERRORE {exc}")

    print()
    print("Se TapirCommand.GetAddOnVersion e OK, possiamo usare Tapir.")
    print("Per Berra ci interessano soprattutto: CreateWalls, CreateRoofs, CreateWindows, CreateDoors.")


if __name__ == "__main__":
    main()
