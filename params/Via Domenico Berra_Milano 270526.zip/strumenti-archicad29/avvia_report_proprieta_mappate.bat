@echo off
cd /d "%~dp0"
py 10_report_proprieta_mappate.py
pause
