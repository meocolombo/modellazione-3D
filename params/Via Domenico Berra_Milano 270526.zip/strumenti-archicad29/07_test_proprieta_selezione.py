from archicad import ACConnection


PROPERTY_COMMANDS = (
    "GetPropertyValuesOfElements",
    "GetAllPropertyNames",
    "GetAllPropertyIds",
    "GetPropertyIds",
    "GetPropertyDefinitions",
    "GetPropertyValuesDictionary",
    "GetClassificationsOfElements",
    "GetElementsByType",
)


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands

    try:
        selection = acc.GetSelectedElements()
    except Exception as exc:
        print(f"Errore lettura selezione: {exc}")
        return

    print(f"Elementi selezionati: {len(selection) if selection else 0}")
    print("")

    for name in PROPERTY_COMMANDS:
        if hasattr(acc, name):
            print(f"OK  {name}")
        else:
            print(f"NO  {name}")

    print("")
    print("Questo script verifica solo quali comandi proprieta sono esposti.")
    print("Il prossimo passo usera i comandi OK per estrarre layer, tipo e proprieta.")


if __name__ == "__main__":
    main()
