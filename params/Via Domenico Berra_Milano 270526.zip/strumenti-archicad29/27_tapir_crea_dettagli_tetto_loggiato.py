from __future__ import annotations

import json
import sys
from pathlib import Path

from archicad import ACConnection


OUT_JSON = Path("berra_dettagli_tetto_loggiato_result.json")
LAYER_NAME = "BERRA_AI_DETTAGLI_01"


CHIMNEYS = [
    (-15.0, -61.0, 8.2), (-12.0, -49.0, 8.1), (-18.5, -29.5, 8.5),
    (-45.0, -22.0, 7.4), (-45.0, -2.0, 7.5), (-44.0, 19.0, 7.6),
    (-30.0, 18.0, 7.8), (-27.5, 29.5, 7.9), (-13.0, 10.5, 7.5),
    (-36.0, -49.0, 8.0), (-28.0, -12.0, 7.7), (-20.0, -10.0, 7.7),
]

SKYLIGHTS = [
    (-13.5, -55.0, 7.4), (-13.5, -44.0, 7.4), (-30.0, -35.0, 7.5),
    (-30.0, -25.0, 7.5), (-45.5, -12.0, 7.3), (-45.5, 8.0, 7.3),
    (-29.0, 23.0, 7.4), (-16.0, 3.0, 7.3),
]

# Colonne semplificate del loggiato/corte. Coordinate stimate dal modello aperto.
COLUMNS = []
for y in [13.8, 16.6, 19.4, 22.2, 25.0, 27.8, 30.6]:
    COLUMNS.append((-33.0, y, 0.0, 3.2))
    COLUMNS.append((-33.0, y, 3.3, 2.9))
for x in [-31.5, -28.8, -26.1, -23.4, -20.7]:
    COLUMNS.append((x, 13.7, 0.0, 3.2))


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def point3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def size3(x, y, z):
    return {"x": float(x), "y": float(y), "z": float(z)}


def coord(x, y):
    return {"x": float(x), "y": float(y)}


def find_layer_index(commands, types, layer_name):
    result = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"})
    for layer in result.get("attributes", []):
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            return int(layer.get("index"))
    return None


def create_or_get_layer(commands, types):
    existing = find_layer_index(commands, types, LAYER_NAME)
    if existing is not None:
        return existing
    tapir(
        commands,
        types,
        "CreateLayers",
        {
            "layerDataArray": [
                {"name": LAYER_NAME, "isHidden": False, "isLocked": False, "isWireframe": False, "intersectionGroupNr": 101}
            ],
            "overwriteExisting": False,
        },
    )
    created = find_layer_index(commands, types, LAYER_NAME)
    if created is None:
        raise RuntimeError(f"Layer non trovato dopo la creazione: {LAYER_NAME}")
    return created


def set_elements_layer(commands, types, elements, layer_index):
    if not elements:
        return None
    return tapir(
        commands,
        types,
        "SetDetailsOfElements",
        {"elementsWithDetails": [{"elementId": e["elementId"], "details": {"layerIndex": layer_index}} for e in elements]},
    )


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "APPLICA":
        print("Crea dettagli tetto/loggiato per Berra.")
        print("Uso: py 27_tapir_crea_dettagli_tetto_loggiato.py APPLICA")
        return

    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita.")
    commands = conn.commands
    types = conn.types
    layer_index = create_or_get_layer(commands, types)

    morphs_data = []
    for x, y, z in CHIMNEYS:
        morphs_data.append({"basePoint": point3(x - 0.22, y - 0.22, z), "size": size3(0.44, 0.44, 1.25)})
    for x, y, z in SKYLIGHTS:
        morphs_data.append({"basePoint": point3(x - 0.50, y - 0.30, z), "size": size3(1.00, 0.60, 0.16)})

    columns_data = [
        {"coordinates": point3(x, y, z), "height": h, "width": 0.28, "depth": 0.28}
        for x, y, z, h in COLUMNS
    ]

    beams_data = []
    # Architravi/linee di imposta loggiato, piano terra e primo piano.
    for z in [3.05, 6.05]:
        beams_data.append({"begCoordinate": coord(-33.0, 13.6), "endCoordinate": coord(-33.0, 30.8), "zCoordinate": z, "width": 0.20, "height": 0.20})
    beams_data.append({"begCoordinate": coord(-31.8, 13.7), "endCoordinate": coord(-20.4, 13.7), "zCoordinate": 3.05, "width": 0.20, "height": 0.20})

    morph_result = tapir(commands, types, "CreateMorphs", {"morphsData": morphs_data})
    column_result = tapir(commands, types, "CreateColumns", {"columnsData": columns_data})
    beam_result = tapir(commands, types, "CreateBeams", {"beamsData": beams_data})

    all_elements = morph_result.get("elements", []) + column_result.get("elements", []) + beam_result.get("elements", [])
    layer_result = set_elements_layer(commands, types, all_elements, layer_index)

    result = {
        "layer": {"name": LAYER_NAME, "index": layer_index},
        "morphs": morph_result,
        "columns": column_result,
        "beams": beam_result,
        "setLayerResult": layer_result,
    }
    OUT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Morph dettagli tetto richiesti: {len(morphs_data)}")
    print(f"Colonne richieste: {len(columns_data)}")
    print(f"Travi loggiato richieste: {len(beams_data)}")
    print(f"Elementi creati totali: {len(all_elements)}")
    print(f"Layer: {LAYER_NAME} index {layer_index}")
    print(f"Report: {OUT_JSON}")


if __name__ == "__main__":
    main()
