from archicad import ACConnection
import csv


def extract_guid(item):
    data = getattr(item, "elementId", None)
    if data is not None:
        guid = getattr(data, "guid", None)
        if guid:
            return guid

    if isinstance(item, dict):
        return item.get("elementId", {}).get("guid", "")

    return str(item)


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands

    try:
        selection = acc.GetSelectedElements()
    except Exception as exc:
        print("Non riesco a leggere la selezione.")
        print(f"Dettaglio: {exc}")
        return

    if not selection:
        print("Nessun elemento selezionato in Archicad.")
        return

    rows = []
    for index, item in enumerate(selection, start=1):
        guid = extract_guid(item)
        rows.append({"numero": index, "guid": guid})

    with open("report_selezione_archicad.csv", "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["numero", "guid"])
        writer.writeheader()
        writer.writerows(rows)

    with open("report_selezione_archicad.txt", "w", encoding="utf-8") as textfile:
        textfile.write("Report selezione Archicad\n")
        textfile.write("=========================\n\n")
        textfile.write(f"Elementi selezionati: {len(rows)}\n\n")
        for row in rows:
            textfile.write(f"{row['numero']}. {row['guid']}\n")

    print(f"Elementi selezionati: {len(rows)}")
    print("Creati:")
    print("- report_selezione_archicad.csv")
    print("- report_selezione_archicad.txt")


if __name__ == "__main__":
    main()
