from archicad import ACConnection


MODIFY_KEYWORDS = (
    "Set",
    "Create",
    "Change",
    "Update",
    "Delete",
    "Add",
    "Modify",
)


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands
    command_names = [name for name in dir(acc) if not name.startswith("_")]
    modify_commands = [
        name
        for name in command_names
        if any(name.lower().startswith(keyword.lower()) for keyword in MODIFY_KEYWORDS)
    ]

    print("Comandi potenzialmente di modifica disponibili")
    print("=============================================")
    print("")
    print("Questo script NON modifica il modello.")
    print("")

    for name in sorted(modify_commands):
        print(name)

    with open("comandi_potenziale_modifica.txt", "w", encoding="utf-8") as report:
        report.write("Comandi potenzialmente di modifica disponibili\n")
        report.write("=============================================\n\n")
        report.write("Questo report elenca solo i comandi. Nessuna modifica e stata eseguita.\n\n")
        for name in sorted(modify_commands):
            report.write(f"{name}\n")

    print("")
    print("Creato: comandi_potenziale_modifica.txt")


if __name__ == "__main__":
    main()
