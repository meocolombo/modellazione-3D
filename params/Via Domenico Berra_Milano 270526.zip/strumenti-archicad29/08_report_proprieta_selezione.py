from archicad import ACConnection
import csv


MAX_PROPERTIES = 80


def guid_of(item):
    element_id = getattr(item, "elementId", None)
    if element_id is not None:
        guid = getattr(element_id, "guid", None)
        if guid:
            return guid

    if isinstance(item, dict):
        return item.get("elementId", {}).get("guid", "")

    return str(item)


def write_text(path, lines):
    with open(path, "w", encoding="utf-8") as file:
        file.write("\n".join(lines))


def main():
    conn = ACConnection.connect()
    if conn is None:
        print("Connessione non riuscita.")
        return

    acc = conn.commands

    try:
        selected = acc.GetSelectedElements()
    except Exception as exc:
        print(f"Errore lettura selezione: {exc}")
        return

    if not selected:
        print("Nessun elemento selezionato.")
        return

    lines = []
    lines.append("Report proprieta selezione Archicad")
    lines.append("====================================")
    lines.append("")
    lines.append(f"Elementi selezionati: {len(selected)}")
    lines.append("")

    for index, element in enumerate(selected, start=1):
        lines.append(f"{index}. GUID: {guid_of(element)}")

    property_names = []
    property_ids = []
    property_values = None

    try:
        property_names = acc.GetAllPropertyNames()
        lines.append("")
        lines.append(f"Proprieta disponibili nel progetto: {len(property_names)}")
    except Exception as exc:
        lines.append("")
        lines.append(f"GetAllPropertyNames non riuscito: {exc}")

    if property_names:
        probe_names = property_names[:MAX_PROPERTIES]
        try:
            property_ids = acc.GetPropertyIds(probe_names)
            lines.append(f"Property ID risolti per le prime {len(probe_names)} proprieta: {len(property_ids)}")
        except Exception as exc:
            lines.append(f"GetPropertyIds non riuscito: {exc}")

    if property_ids:
        try:
            property_values = acc.GetPropertyValuesOfElements(selected, property_ids)
            lines.append("GetPropertyValuesOfElements riuscito.")
        except Exception as exc:
            lines.append(f"GetPropertyValuesOfElements non riuscito: {exc}")

    try:
        classifications = acc.GetClassificationsOfElements(selected)
        lines.append("")
        lines.append("Classificazioni:")
        lines.append(repr(classifications))
    except Exception as exc:
        lines.append("")
        lines.append(f"GetClassificationsOfElements non riuscito: {exc}")

    if property_values is not None:
        lines.append("")
        lines.append("Valori proprieta grezzi:")
        lines.append(repr(property_values))

    write_text("report_proprieta_selezione.txt", lines)

    with open("report_proprieta_selezione_guid.csv", "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["numero", "guid"])
        writer.writeheader()
        for index, element in enumerate(selected, start=1):
            writer.writerow({"numero": index, "guid": guid_of(element)})

    print(f"Elementi selezionati: {len(selected)}")
    print("Creati:")
    print("- report_proprieta_selezione.txt")
    print("- report_proprieta_selezione_guid.csv")
    if property_names:
        print(f"Proprieta disponibili lette: {len(property_names)}")
    if property_values is not None:
        print("Valori proprieta letti: si")


if __name__ == "__main__":
    main()
