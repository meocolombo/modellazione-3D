from __future__ import annotations

import csv
from pathlib import Path

from archicad import ACConnection


OUT_TXT = Path("tapir_contesto_berra.txt")
OUT_ATTR_CSV = Path("tapir_attributi_berra.csv")


ATTRIBUTE_TYPES = ["Layer", "BuildingMaterial", "Composite", "Profile", "Surface"]


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    commands = conn.commands
    types = conn.types

    version = tapir(commands, types, "GetAddOnVersion")
    stories = tapir(commands, types, "GetStories")

    rows = []
    attributes_by_type = {}
    for attribute_type in ATTRIBUTE_TYPES:
        result = tapir(commands, types, "GetAttributesByType", {"attributeType": attribute_type})
        attributes = result.get("attributes", [])
        attributes_by_type[attribute_type] = attributes
        for attr in attributes:
            rows.append(
                {
                    "tipo": attribute_type,
                    "index": attr.get("index", ""),
                    "nome": attr.get("name", ""),
                    "guid": attr.get("attributeId", {}).get("guid", ""),
                }
            )

    with OUT_ATTR_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["tipo", "index", "nome", "guid"], delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    with OUT_TXT.open("w", encoding="utf-8") as handle:
        handle.write("TAPIR CONTESTO BERRA\n")
        handle.write("=" * 24 + "\n\n")
        handle.write(f"Tapir: {version}\n")
        handle.write(f"Archicad: {commands.GetProductInfo()}\n\n")
        handle.write("Piani:\n")
        for story in stories.get("stories", []):
            handle.write(
                f"- index {story.get('index')} | quota {story.get('level')} | "
                f"nome {story.get('name')!r}\n"
            )
        handle.write("\nAttributi letti:\n")
        for attribute_type in ATTRIBUTE_TYPES:
            handle.write(f"- {attribute_type}: {len(attributes_by_type[attribute_type])}\n")
        handle.write("\nLayer BERRA presenti:\n")
        berra_layers = [
            attr for attr in attributes_by_type["Layer"]
            if "berra" in str(attr.get("name", "")).lower()
        ]
        if berra_layers:
            for attr in berra_layers:
                handle.write(f"- index {attr.get('index')} | {attr.get('name')}\n")
        else:
            handle.write("- Nessun layer con nome BERRA trovato.\n")

    print("Creati:")
    print(f"- {OUT_TXT}")
    print(f"- {OUT_ATTR_CSV}")
    print(f"Tapir: {version}")


if __name__ == "__main__":
    main()
