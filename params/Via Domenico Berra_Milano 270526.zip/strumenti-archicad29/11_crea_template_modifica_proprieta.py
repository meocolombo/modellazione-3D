from __future__ import annotations

import csv
from pathlib import Path

from archicad import ACConnection


OUT_CSV = Path("modifiche_proprieta.csv")


def get_attr(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def localized_parts(prop_name):
    user_id = get_attr(prop_name, "localizedName")
    if not user_id:
        return None
    if len(user_id) >= 2:
        return str(user_id[0]), str(user_id[1])
    if len(user_id) == 1:
        return "", str(user_id[0])
    return None


def value_type_from_item(item):
    prop_value = get_attr(item, "propertyValue", item)
    value = get_attr(prop_value, "value", None)
    if value is not None:
        return get_attr(prop_value, "type", type(value).__name__)
    return get_attr(prop_value, "type", "")


def status_from_item(item):
    prop_value = get_attr(item, "propertyValue", item)
    return get_attr(prop_value, "status", "")


def main():
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    acc = conn.commands
    selected = acc.GetSelectedElements()
    if not selected:
        raise SystemExit("Nessun elemento selezionato.")

    property_names = acc.GetAllPropertyNames()
    property_ids = acc.GetPropertyIds(property_names)
    values = acc.GetPropertyValuesOfElements([selected[0]], property_ids)[0].propertyValues

    rows = []
    supported_types = {"string", "number", "integer", "boolean", "length"}

    for index, prop_name in enumerate(property_names):
        parts = localized_parts(prop_name)
        if not parts:
            continue

        item = values[index]
        status = status_from_item(item)
        value_type = value_type_from_item(item)
        if status == "notAvailable":
            continue

        rows.append(
            {
                "gruppo": parts[0],
                "proprieta": parts[1],
                "tipo": value_type,
                "nuovo_valore": "",
                "applica": "NO",
                "note": "supportata" if value_type in supported_types else "tipo non automatico",
            }
        )

    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["gruppo", "proprieta", "tipo", "nuovo_valore", "applica", "note"],
            delimiter=";",
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"Creato: {OUT_CSV}")
    print("Compila solo le righe da modificare, imposta applica=SI, poi esegui:")
    print("py 12_applica_modifiche_proprieta.py APPLICA")


if __name__ == "__main__":
    main()
