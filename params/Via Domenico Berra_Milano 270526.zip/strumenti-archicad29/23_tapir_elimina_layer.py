from __future__ import annotations

import sys

from archicad import ACConnection


def tapir(commands, types, name, params=None):
    return commands.ExecuteAddOnCommand(types.AddOnCommandId("TapirCommand", name), params)


def main():
    if len(sys.argv) < 3 or sys.argv[1] != "APPLICA":
        print("Elimina tutti gli elementi su un layer indicato.")
        print("Uso:")
        print('py 23_tapir_elimina_layer.py APPLICA "NOME_LAYER"')
        return

    layer_name = sys.argv[2]
    conn = ACConnection.connect()
    if not conn:
        raise SystemExit("Connessione Archicad non riuscita. Apri Archicad e abilita Python Palette.")

    commands = conn.commands
    types = conn.types

    layers = tapir(commands, types, "GetAttributesByType", {"attributeType": "Layer"}).get("attributes", [])
    layer_index = None
    for layer in layers:
        if str(layer.get("name", "")).casefold() == layer_name.casefold():
            layer_index = int(layer.get("index"))
            break

    if layer_index is None:
        raise SystemExit(f"Layer non trovato: {layer_name}")

    elements = tapir(commands, types, "GetAllElements").get("elements", [])
    details = tapir(commands, types, "GetDetailsOfElements", {"elements": elements}).get("detailsOfElements", [])
    to_delete = [element for element, detail in zip(elements, details) if int(detail.get("layerIndex", -999)) == layer_index]

    if not to_delete:
        print(f"Nessun elemento da eliminare sul layer {layer_name} index {layer_index}.")
        return

    result = tapir(commands, types, "DeleteElements", {"elements": to_delete})
    print(f"Layer: {layer_name} index {layer_index}")
    print(f"Elementi richiesti in eliminazione: {len(to_delete)}")
    print(f"Risultato: {result}")


if __name__ == "__main__":
    main()
