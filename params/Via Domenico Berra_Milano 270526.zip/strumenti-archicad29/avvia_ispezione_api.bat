@echo off
cd /d "%~dp0"
py 04_ispeziona_api.py
pause
