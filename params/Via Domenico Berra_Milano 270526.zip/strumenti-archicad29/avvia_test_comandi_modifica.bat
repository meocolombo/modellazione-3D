@echo off
cd /d "%~dp0"
py 09_test_comandi_modifica.py
pause
